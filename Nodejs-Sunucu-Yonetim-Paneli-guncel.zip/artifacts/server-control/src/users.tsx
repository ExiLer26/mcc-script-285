import { useEffect, useState, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { KeyRound, LoaderCircle, Pencil, Plus, ShieldCheck, Trash2, UserPlus, X } from 'lucide-react';
import { customFetch, useGetServers } from '@workspace/api-client-react';
import type { Permission } from './access';

type PanelUser = {
  id: number; username: string; displayName: string; permissions: Permission[];
  allServers: boolean; serverIds: number[]; disabled: boolean; createdAt: string;
};

type Draft = {
  username: string; displayName: string; password: string; permissions: Permission[];
  allServers: boolean; serverIds: number[]; disabled: boolean;
};

const PERMISSION_GROUPS: { title: string; items: { key: Permission; label: string; hint: string }[] }[] = [
  { title: 'Power', items: [
    { key: 'power', label: 'Start, stop and restart', hint: 'Control whether the server is running.' },
    { key: 'kill', label: 'Force kill', hint: 'Immediately terminate the process.' },
  ] },
  { title: 'Terminal', items: [
    { key: 'console_view', label: 'See the terminal', hint: 'Read the live console output.' },
    { key: 'console_send', label: 'Send commands and clear', hint: 'Type into the console and clear its log.' },
  ] },
  { title: 'Files', items: [
    { key: 'files_view', label: 'See and download files', hint: 'Browse the server folder, open and download files.' },
    { key: 'files_edit', label: 'Change files', hint: 'Upload, edit, rename, delete, unzip, chmod and download from a URL.' },
  ] },
  { title: 'Server settings', items: [
    { key: 'schedules', label: 'Scheduled tasks', hint: 'Create, run and delete scheduled tasks. Tasks send commands, so this also allows sending commands.' },
    { key: 'startup', label: 'Auto-start & Crash-start', hint: 'Change the startup behaviour and delays.' },
    { key: 'settings', label: 'Edit the process definition', hint: 'Change the name, start command, port and the terminal settings.' },
  ] },
  { title: 'Scripts page', items: [
    { key: 'scripts', label: 'Open the Scripts page and run scripts', hint: 'Adds the Scripts menu. Scripts can only be run on the servers this user can access.' },
    { key: 'scripts_edit', label: 'Create, edit, delete and import scripts', hint: 'Scripts can run commands, download files and change the start command.' },
  ] },
];

const PRESETS: { label: string; permissions: Permission[] }[] = [
  { label: 'Viewer', permissions: ['console_view', 'files_view'] },
  { label: 'Operator', permissions: ['power', 'console_view', 'console_send'] },
  { label: 'Full control', permissions: ['power', 'kill', 'console_view', 'console_send', 'files_view', 'files_edit', 'schedules', 'startup', 'settings', 'scripts', 'scripts_edit'] },
];

function errorMessage(error: unknown, fallback: string): string {
  const data = (error as { data?: { error?: unknown } } | null)?.data;
  if (data && typeof data.error === 'string') return data.error;
  return error instanceof Error && error.message ? error.message : fallback;
}

const usersKey = ['panel-users'] as const;
const fieldClass = 'h-11 w-full rounded-lg border bg-card px-3 text-sm outline-none focus:border-primary';

export default function UsersPanel() {
  const queryClient = useQueryClient();
  const usersQuery = useQuery({ queryKey: usersKey, queryFn: () => customFetch<PanelUser[]>('/api/users') });
  const serversQuery = useGetServers();
  const [dialog, setDialog] = useState<{ user: PanelUser | null } | null>(null);
  const [error, setError] = useState('');
  const users = usersQuery.data ?? [];
  const servers = serversQuery.data ?? [];

  const remove = useMutation({
    mutationFn: (user: PanelUser) => customFetch(`/api/users/${user.id}`, { method: 'DELETE' }),
    onSuccess: () => { setError(''); void queryClient.invalidateQueries({ queryKey: usersKey }); },
    onError: (err) => setError(errorMessage(err, 'Could not delete the user.')),
  });

  const summary = (user: PanelUser) => {
    const count = user.permissions.length;
    const scope = user.allServers ? 'all servers' : `${user.serverIds.filter((id) => servers.some((server) => server.id === id)).length} server(s)`;
    return `${count} permission${count === 1 ? '' : 's'} · ${scope}`;
  };

  return <section className="overflow-hidden rounded-xl border bg-card shadow-[0_2px_10px_hsl(218_36%_18%/.035)]" data-testid="panel-new-user">
    <div className="flex flex-wrap items-start justify-between gap-3 border-b px-5 py-4 sm:px-6">
      <div className="flex min-w-0 items-center gap-3"><span className="grid size-9 shrink-0 place-items-center rounded-lg bg-teal-50 text-primary"><UserPlus className="size-5" /></span><div className="min-w-0"><h3 className="font-bold">New User</h3><p className="mt-1 text-xs leading-5 text-muted-foreground">Create accounts for other people. They only see the <strong>Servers</strong> menu (plus Scripts if you allow it), only the servers and actions you allow.</p></div></div>
      <button onClick={() => { setError(''); setDialog({ user: null }); }} className="inline-flex h-10 items-center gap-2 rounded-lg bg-primary px-4 text-sm font-bold text-primary-foreground hover:opacity-90" data-testid="button-new-user"><Plus className="size-4" />New user</button>
    </div>
    <div className="p-5 sm:p-6">
      {error && <p className="mb-4 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700" role="alert" data-testid="text-users-error">{error}</p>}
      {usersQuery.isLoading ? <div className="space-y-3"><div className="skeleton h-16 rounded-lg" /><div className="skeleton h-16 rounded-lg" /></div>
        : usersQuery.isError ? <p className="text-sm text-muted-foreground">{errorMessage(usersQuery.error, 'Users could not be loaded.')} <button onClick={() => usersQuery.refetch()} className="font-bold text-primary hover:underline">Try again</button></p>
          : users.length === 0 ? <div className="rounded-lg border border-dashed px-4 py-8 text-center" data-testid="empty-users"><ShieldCheck className="mx-auto size-7 text-muted-foreground" /><p className="mt-2 text-sm font-semibold">No extra users yet</p><p className="mt-1 text-xs text-muted-foreground">Only you (the administrator) can sign in right now.</p></div>
            : <ul className="divide-y rounded-lg border">{users.map((user) => <li key={user.id} className="flex flex-wrap items-center gap-3 px-4 py-3.5" data-testid={`user-row-${user.id}`}>
              <span className="grid size-9 shrink-0 place-items-center rounded-full bg-muted text-xs font-bold">{user.displayName.slice(0, 2).toUpperCase()}</span>
              <div className="min-w-0 flex-1 basis-40"><p className="flex flex-wrap items-center gap-2 text-sm font-bold"><span className="truncate">{user.displayName}</span>{user.disabled && <span className="rounded-full bg-red-50 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-red-700">Disabled</span>}</p><p className="truncate text-xs text-muted-foreground">@{user.username} · {summary(user)}</p></div>
              <div className="flex gap-1.5">
                <button onClick={() => { setError(''); setDialog({ user }); }} className="grid size-9 place-items-center rounded-lg border hover:bg-muted" aria-label={`Edit ${user.username}`} title="Edit" data-testid={`button-edit-user-${user.id}`}><Pencil className="size-4" /></button>
                <button onClick={() => { if (window.confirm(`Delete the user "${user.username}"? They will be signed out immediately.`)) remove.mutate(user); }} disabled={remove.isPending} className="grid size-9 place-items-center rounded-lg border text-red-700 hover:bg-red-50 disabled:opacity-50" aria-label={`Delete ${user.username}`} title="Delete" data-testid={`button-delete-user-${user.id}`}><Trash2 className="size-4" /></button>
              </div>
            </li>)}</ul>}
    </div>
    {dialog && <UserDialog user={dialog.user} servers={servers.map((server) => ({ id: server.id, name: server.name }))} onClose={() => setDialog(null)} onSaved={() => { setDialog(null); void queryClient.invalidateQueries({ queryKey: usersKey }); }} />}
  </section>;
}

function Dialog({ title, onClose, children, footer, closeDisabled }: { title: string; onClose: () => void; children: ReactNode; footer: ReactNode; closeDisabled: boolean }) {
  useEffect(() => {
    const previous = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = previous; };
  }, []);
  return createPortal(
    <div className="fixed inset-0 z-[80] grid place-items-center bg-sidebar/45 p-3 backdrop-blur-sm sm:p-6" role="dialog" aria-modal="true" aria-label={title} onMouseDown={(event) => { if (event.target === event.currentTarget && !closeDisabled) onClose(); }} data-testid="dialog-user">
      <div className="flex max-h-[94dvh] w-full max-w-2xl flex-col overflow-hidden rounded-2xl border bg-card shadow-2xl">
        <div className="flex items-center justify-between border-b px-5 py-4 sm:px-6"><h3 className="text-lg font-bold">{title}</h3><button onClick={onClose} disabled={closeDisabled} className="grid size-9 place-items-center rounded-lg text-muted-foreground hover:bg-muted" aria-label="Close"><X className="size-5" /></button></div>
        <div className="overflow-y-auto px-5 py-5 sm:px-6">{children}</div>
        <div className="border-t px-5 py-4 sm:px-6">{footer}</div>
      </div>
    </div>,
    document.body,
  );
}

function UserDialog({ user, servers, onClose, onSaved }: { user: PanelUser | null; servers: { id: number; name: string }[]; onClose: () => void; onSaved: () => void }) {
  const editing = Boolean(user);
  const [draft, setDraft] = useState<Draft>({
    username: user?.username ?? '', displayName: user?.displayName ?? '', password: '',
    permissions: user?.permissions ?? ['console_view'], allServers: user?.allServers ?? false,
    serverIds: user?.serverIds ?? [], disabled: user?.disabled ?? false,
  });
  const [error, setError] = useState('');

  const save = useMutation({
    mutationFn: (body: Draft) => customFetch(editing ? `/api/users/${user?.id}` : '/api/users', { method: editing ? 'PUT' : 'POST', body: JSON.stringify(body) }),
    onSuccess: onSaved,
    onError: (err) => setError(errorMessage(err, 'Could not save the user.')),
  });

  const has = (permission: Permission) => draft.permissions.includes(permission);
  const toggle = (permission: Permission) => setDraft((current) => {
    const next = new Set(current.permissions);
    if (next.has(permission)) {
      next.delete(permission);
      if (permission === 'console_view') { next.delete('console_send'); next.delete('schedules'); }
      if (permission === 'console_send') next.delete('schedules');
      if (permission === 'files_view') next.delete('files_edit');
      if (permission === 'scripts') next.delete('scripts_edit');
    } else {
      next.add(permission);
      if (permission === 'schedules') { next.add('console_send'); next.add('console_view'); }
      if (permission === 'console_send') next.add('console_view');
      if (permission === 'files_edit') next.add('files_view');
      if (permission === 'scripts_edit') next.add('scripts');
    }
    return { ...current, permissions: [...next] };
  });
  const toggleServer = (id: number) => setDraft((current) => ({ ...current, serverIds: current.serverIds.includes(id) ? current.serverIds.filter((item) => item !== id) : [...current.serverIds, id] }));

  const submit = () => {
    setError('');
    if (!editing && !/^[a-z0-9._-]{3,32}$/.test(draft.username.trim().toLowerCase())) return setError('The username must be 3-32 characters: lowercase letters, numbers, dot, dash or underscore.');
    if (!draft.displayName.trim()) return setError('Enter a display name.');
    if (!editing && draft.password.length < 8) return setError('The password must be at least 8 characters.');
    if (editing && draft.password && draft.password.length < 8) return setError('The new password must be at least 8 characters.');
    if (!draft.allServers && !draft.serverIds.length) return setError('Choose at least one server, or allow all servers.');
    save.mutate({ ...draft, username: draft.username.trim().toLowerCase(), displayName: draft.displayName.trim() });
  };

  return <Dialog title={editing ? `Edit ${user?.username}` : 'New user'} onClose={onClose} closeDisabled={save.isPending}
    footer={<div className="flex flex-col-reverse gap-3 sm:flex-row sm:justify-end"><button onClick={onClose} disabled={save.isPending} className="h-11 rounded-lg border px-5 text-sm font-bold hover:bg-muted" data-testid="button-user-cancel">Cancel</button><button onClick={submit} disabled={save.isPending} className="inline-flex h-11 items-center justify-center gap-2 rounded-lg bg-primary px-6 text-sm font-bold text-primary-foreground hover:opacity-90 disabled:opacity-60" data-testid="button-user-save">{save.isPending && <LoaderCircle className="size-4 animate-spin" />}{editing ? 'Save changes' : 'Create user'}</button></div>}>
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <label className="block space-y-1.5"><span className="text-xs font-bold uppercase tracking-[.1em] text-muted-foreground">Display name</span><input value={draft.displayName} onChange={(event) => setDraft({ ...draft, displayName: event.target.value })} maxLength={60} className={fieldClass} data-testid="input-user-display-name" /></label>
        <label className="block space-y-1.5"><span className="text-xs font-bold uppercase tracking-[.1em] text-muted-foreground">Username</span><input value={draft.username} onChange={(event) => setDraft({ ...draft, username: event.target.value.toLowerCase() })} disabled={editing} maxLength={32} autoCapitalize="off" autoComplete="off" spellCheck={false} className={`${fieldClass} mono disabled:opacity-60`} data-testid="input-user-username" /></label>
        <label className="block space-y-1.5 sm:col-span-2"><span className="text-xs font-bold uppercase tracking-[.1em] text-muted-foreground">{editing ? 'New password (leave empty to keep the current one)' : 'Password'}</span><div className="relative"><KeyRound className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" /><input type="password" value={draft.password} onChange={(event) => setDraft({ ...draft, password: event.target.value })} autoComplete="new-password" className={`${fieldClass} pl-9`} placeholder="At least 8 characters" data-testid="input-user-password" /></div></label>
      </div>

      <section className="space-y-3">
        <div><h4 className="font-bold">Servers</h4><p className="text-xs text-muted-foreground">Which servers this user can see and open.</p></div>
        <label className="flex items-center gap-2 text-sm font-semibold"><input type="checkbox" checked={draft.allServers} onChange={(event) => setDraft({ ...draft, allServers: event.target.checked })} className="size-4" data-testid="checkbox-user-all-servers" />All servers (including ones created later)</label>
        {!draft.allServers && (servers.length ? <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-2">{servers.map((server) => <label key={server.id} className="flex items-center gap-2 rounded-lg border px-3 py-2.5 text-sm"><input type="checkbox" checked={draft.serverIds.includes(server.id)} onChange={() => toggleServer(server.id)} className="size-4" data-testid={`checkbox-user-server-${server.id}`} /><span className="truncate">{server.name}</span></label>)}</div> : <p className="rounded-lg border border-dashed px-3 py-4 text-center text-xs text-muted-foreground">You have no servers yet. Create one first, or allow all servers.</p>)}
      </section>

      <section className="space-y-4">
        <div className="flex flex-wrap items-start justify-between gap-2"><div><h4 className="font-bold">Permissions</h4><p className="text-xs text-muted-foreground">What this user can do on those servers.</p></div>
          <div className="flex flex-wrap gap-1.5">{PRESETS.map((preset) => <button key={preset.label} type="button" onClick={() => setDraft({ ...draft, permissions: preset.permissions })} className="h-8 rounded-lg border px-3 text-xs font-bold hover:bg-muted" data-testid={`button-preset-${preset.label.toLowerCase().replace(/\s+/g, '-')}`}>{preset.label}</button>)}<button type="button" onClick={() => setDraft({ ...draft, permissions: [] })} className="h-8 rounded-lg border px-3 text-xs font-bold text-muted-foreground hover:bg-muted">None</button></div></div>
        {PERMISSION_GROUPS.map((group) => <div key={group.title} className="space-y-1.5"><p className="text-[11px] font-bold uppercase tracking-[.1em] text-muted-foreground">{group.title}</p>{group.items.map((item) => <label key={item.key} className="flex items-start gap-3 rounded-lg border px-3 py-2.5"><input type="checkbox" checked={has(item.key)} onChange={() => toggle(item.key)} className="mt-0.5 size-4" data-testid={`checkbox-permission-${item.key}`} /><span className="min-w-0"><span className="block text-sm font-semibold">{item.label}</span><span className="block text-xs text-muted-foreground">{item.hint}</span></span></label>)}</div>)}
        <p className="rounded-lg border border-amber-200 bg-amber-50 px-3 py-2.5 text-xs text-amber-800">Changing files, editing the process definition (start command), scheduled tasks and managing scripts can make the server run commands on this machine. Only give them to people you trust.</p>
        <p className="rounded-lg bg-muted/50 px-3 py-2.5 text-xs text-muted-foreground">Users never see Overview, Console or Settings, and cannot create or delete servers. The Scripts menu only appears if you allow it above.</p>
      </section>

      {editing && <label className="flex items-start gap-3 rounded-lg border border-red-200 bg-red-50/60 px-3 py-3"><input type="checkbox" checked={draft.disabled} onChange={(event) => setDraft({ ...draft, disabled: event.target.checked })} className="mt-0.5 size-4" data-testid="checkbox-user-disabled" /><span><span className="block text-sm font-semibold text-red-800">Disable this account</span><span className="block text-xs text-red-700/80">The user is signed out and cannot sign in until you enable it again.</span></span></label>}

      {error && <p className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700" role="alert" data-testid="text-user-error">{error}</p>}
    </div>
  </Dialog>;
}
