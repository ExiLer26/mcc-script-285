import { useEffect, useRef, useState, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { CalendarClock, Clock3, LoaderCircle, Pencil, Play, Plus, Repeat, Terminal as TerminalIcon, Trash2, X } from 'lucide-react';
import { customFetch, type ManagedServer } from '@workspace/api-client-react';

type ScheduleType = 'interval' | 'periodic' | 'specific';
type IntervalConfig = { hours: number; minutes: number; seconds: number };
type PeriodicConfig = { days: number[]; time: string; utcOffsetMinutes: number };
type SpecificConfig = { runAt: string };

type ScheduleTask = {
  id: number;
  serverId: number;
  name: string;
  type: ScheduleType;
  config: IntervalConfig & PeriodicConfig & SpecificConfig;
  command: string;
  enabled: boolean;
  nextRunAt: string | null;
  lastRunAt: string | null;
  lastStatus: string | null;
  runCount: number;
  createdAt: string;
};

const TYPE_LABELS: Record<ScheduleType, string> = {
  interval: 'Interval-based task',
  periodic: 'Periodic task',
  specific: 'Specific-time task',
};

const DAY_OPTIONS = [
  { value: 1, label: 'Mon' }, { value: 2, label: 'Tue' }, { value: 3, label: 'Wed' }, { value: 4, label: 'Thu' },
  { value: 5, label: 'Fri' }, { value: 6, label: 'Sat' }, { value: 0, label: 'Sun' },
];

const queryKey = (serverId: number) => ['server-schedules', serverId] as const;

function errorMessage(error: unknown, fallback: string): string {
  const data = (error as { data?: { error?: unknown } } | null)?.data;
  if (data && typeof data.error === 'string') return data.error;
  return error instanceof Error && error.message ? error.message : fallback;
}

const pad = (value: number) => String(value).padStart(2, '0');

function formatCountdown(ms: number): string {
  const total = Math.max(0, Math.ceil(ms / 1000));
  const days = Math.floor(total / 86400);
  const hours = Math.floor((total % 86400) / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  const seconds = total % 60;
  return `${days > 0 ? `${days}d ` : ''}${pad(hours)}:${pad(minutes)}:${pad(seconds)}`;
}

function describeTask(task: ScheduleTask): string {
  if (task.type === 'interval') {
    const { hours, minutes, seconds } = task.config;
    return `Every ${hours}h ${minutes}m ${seconds}s`;
  }
  if (task.type === 'periodic') {
    const days = task.config.days ?? [];
    const label = days.length === 7 ? 'Every day' : DAY_OPTIONS.filter((day) => days.includes(day.value)).map((day) => day.label).join(', ');
    return `${label} at ${task.config.time}`;
  }
  return `Once on ${new Date(task.config.runAt).toLocaleString()}`;
}

function toLocalInputValue(date: Date): string {
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
}

const inputClass = 'h-11 w-full rounded-xl border border-slate-600 bg-[#121920] px-4 text-sm text-white outline-none focus:border-blue-500';

/* ------------------------------------------------------------------ */

export function SchedulePanel({ server }: { server: ManagedServer }) {
  const queryClient = useQueryClient();
  const tasksQuery = useQuery({
    queryKey: queryKey(server.id),
    queryFn: () => customFetch<ScheduleTask[]>(`/api/servers/${server.id}/schedules`),
    refetchInterval: 10_000,
  });
  const [dialog, setDialog] = useState<{ task: ScheduleTask | null } | null>(null);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');
  const [now, setNow] = useState(() => Date.now());
  const lastRefetch = useRef(0);

  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  const tasks = tasksQuery.data ?? [];

  // Refresh shortly after a countdown reaches zero so the next run time updates.
  useEffect(() => {
    const overdue = tasks.some((task) => task.enabled && task.nextRunAt && new Date(task.nextRunAt).getTime() <= now - 1500);
    if (overdue && now - lastRefetch.current > 3000) {
      lastRefetch.current = now;
      void tasksQuery.refetch();
    }
  }, [now, tasks, tasksQuery]);

  const refresh = () => queryClient.invalidateQueries({ queryKey: queryKey(server.id) });
  const toggle = useMutation({
    mutationFn: (task: ScheduleTask) => customFetch(`/api/servers/${server.id}/schedules/${task.id}`, { method: 'PATCH', body: JSON.stringify({ enabled: !task.enabled }) }),
    onSuccess: () => { setError(''); void refresh(); },
    onError: (err) => setError(errorMessage(err, 'Could not update the task.')),
  });
  const runNow = useMutation({
    mutationFn: (task: ScheduleTask) => customFetch<ScheduleTask>(`/api/servers/${server.id}/schedules/${task.id}/run`, { method: 'POST' }),
    onSuccess: (task) => { setError(''); setNotice(`${task.name}: ${task.lastStatus ?? 'done'}`); void refresh(); },
    onError: (err) => setError(errorMessage(err, 'Could not run the task.')),
  });
  const remove = useMutation({
    mutationFn: (task: ScheduleTask) => customFetch(`/api/servers/${server.id}/schedules/${task.id}`, { method: 'DELETE' }),
    onSuccess: () => { setError(''); void refresh(); },
    onError: (err) => setError(errorMessage(err, 'Could not delete the task.')),
  });

  return <div className="max-w-3xl space-y-4" data-testid="panel-server-schedule">
    <div className="flex flex-wrap items-start justify-between gap-3">
      <div className="min-w-0 flex-1 basis-60"><h4 className="font-bold">Scheduled tasks</h4><p className="mt-1 text-xs leading-5 text-muted-foreground">Send a command to this process automatically. The countdown keeps running even when the process is stopped; commands are skipped while it is offline.</p></div>
      <button onClick={() => { setNotice(''); setDialog({ task: null }); }} className="inline-flex h-10 items-center gap-2 rounded-lg bg-primary px-4 text-sm font-bold text-primary-foreground hover:opacity-90" data-testid="button-add-schedule"><Plus className="size-4" />New task</button>
    </div>

    {notice && <p className="rounded-lg border border-teal-200 bg-teal-50 px-4 py-3 text-sm text-teal-800" data-testid="text-schedule-notice">{notice}</p>}
    {error && <p className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700" role="alert" data-testid="text-schedule-error">{error}</p>}

    {tasksQuery.isLoading ? <div className="space-y-3"><div className="skeleton h-28 rounded-xl" /><div className="skeleton h-28 rounded-xl" /></div>
      : tasksQuery.isError ? <p className="rounded-lg border bg-muted/30 px-4 py-6 text-sm text-muted-foreground">{errorMessage(tasksQuery.error, 'Tasks could not be loaded.')} <button onClick={() => tasksQuery.refetch()} className="font-bold text-primary hover:underline">Try again</button></p>
        : tasks.length === 0 ? <div className="grid place-items-center rounded-xl border border-dashed bg-muted/20 px-6 py-12 text-center" data-testid="empty-schedules"><div><CalendarClock className="mx-auto size-8 text-muted-foreground" /><p className="mt-3 font-semibold">No scheduled tasks yet</p><p className="mt-1 text-sm text-muted-foreground">Create one, for example “every 1 hour send /skyblock”.</p></div></div>
          : <ul className="space-y-3">{tasks.map((task) => {
            const remaining = task.enabled && task.nextRunAt ? new Date(task.nextRunAt).getTime() - now : null;
            const TypeIcon = task.type === 'interval' ? Repeat : task.type === 'periodic' ? CalendarClock : Clock3;
            return <li key={task.id} className="rounded-xl border bg-card p-4 sm:p-5" data-testid={`schedule-task-${task.id}`}>
              <div className="flex items-start gap-3">
                <span className="grid size-10 shrink-0 place-items-center rounded-lg bg-teal-50 text-primary"><TypeIcon className="size-5" /></span>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2"><h5 className="break-words font-bold">{task.name}</h5><span className="rounded-full bg-muted px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-muted-foreground">{TYPE_LABELS[task.type]}</span></div>
                  <p className="mt-1 text-xs text-muted-foreground">{describeTask(task)}</p>
                </div>
                <button type="button" role="switch" aria-checked={task.enabled} aria-label={`Toggle ${task.name}`} disabled={toggle.isPending} onClick={() => toggle.mutate(task)} className={`relative h-7 w-12 shrink-0 rounded-full transition ${task.enabled ? 'bg-primary' : 'bg-muted-foreground/35'} disabled:opacity-50`} data-testid={`switch-schedule-${task.id}`}><span className={`absolute left-1 top-1 size-5 rounded-full bg-card shadow-sm transition-transform ${task.enabled ? 'translate-x-5' : 'translate-x-0'}`} /></button>
              </div>
              <div className="mt-3 flex items-center gap-2 rounded-lg bg-[#121920] px-3 py-2 font-mono text-xs text-teal-200"><TerminalIcon className="size-3.5 shrink-0 text-slate-500" /><span className="min-w-0 break-all">{task.command}</span></div>
              <div className="mt-3 flex flex-wrap items-end justify-between gap-3">
                <div>
                  <p className="text-[11px] font-bold uppercase tracking-[.1em] text-muted-foreground">{remaining !== null ? 'Next run in' : task.enabled ? 'Next run' : 'Paused'}</p>
                  <p className="mono text-xl font-bold tabular-nums" data-testid={`countdown-${task.id}`}>{remaining !== null ? formatCountdown(remaining) : '—'}</p>
                  <p className="mt-1 text-[11px] text-muted-foreground">{task.lastRunAt ? `Last run ${new Date(task.lastRunAt).toLocaleString()} · ${task.lastStatus ?? ''}` : task.lastStatus ?? 'Has not run yet'} · {task.runCount} run{task.runCount === 1 ? '' : 's'}</p>
                </div>
                <div className="flex gap-1">
                  <button onClick={() => runNow.mutate(task)} disabled={runNow.isPending} className="inline-flex h-9 items-center gap-1.5 rounded-lg border px-3 text-xs font-semibold hover:bg-muted disabled:opacity-50" title="Send the command now" data-testid={`button-run-schedule-${task.id}`}>{runNow.isPending && runNow.variables?.id === task.id ? <LoaderCircle className="size-3.5 animate-spin" /> : <Play className="size-3.5" />}Run now</button>
                  <button onClick={() => { setNotice(''); setDialog({ task }); }} className="grid size-9 place-items-center rounded-lg border hover:bg-muted" aria-label={`Edit ${task.name}`} title="Edit" data-testid={`button-edit-schedule-${task.id}`}><Pencil className="size-4" /></button>
                  <button onClick={() => { if (window.confirm(`Delete the task "${task.name}"?`)) remove.mutate(task); }} disabled={remove.isPending} className="grid size-9 place-items-center rounded-lg border text-red-700 hover:bg-red-50 disabled:opacity-50" aria-label={`Delete ${task.name}`} title="Delete" data-testid={`button-delete-schedule-${task.id}`}><Trash2 className="size-4" /></button>
                </div>
              </div>
            </li>;
          })}</ul>}

    {dialog && <ScheduleDialog serverId={server.id} task={dialog.task} onClose={() => setDialog(null)} onSaved={() => { setDialog(null); void refresh(); }} />}
  </div>;
}

/* ------------------------------------------------------------------ */

function Field({ label, children }: { label: string; children: ReactNode }) {
  return <label className="block space-y-1.5"><span className="text-xs font-bold uppercase tracking-wider text-slate-400">{label}</span>{children}</label>;
}

function ScheduleDialog({ serverId, task, onClose, onSaved }: { serverId: number; task: ScheduleTask | null; onClose: () => void; onSaved: () => void }) {
  const [name, setName] = useState(task?.name ?? '');
  const [type, setType] = useState<ScheduleType>(task?.type ?? 'interval');
  const [hours, setHours] = useState(String(task?.type === 'interval' ? task.config.hours : 1));
  const [minutes, setMinutes] = useState(String(task?.type === 'interval' ? task.config.minutes : 0));
  const [seconds, setSeconds] = useState(String(task?.type === 'interval' ? task.config.seconds : 0));
  const [days, setDays] = useState<number[]>(task?.type === 'periodic' ? task.config.days : [0, 1, 2, 3, 4, 5, 6]);
  const [time, setTime] = useState(task?.type === 'periodic' ? task.config.time : '12:00:00');
  const [runAt, setRunAt] = useState(task?.type === 'specific' ? toLocalInputValue(new Date(task.config.runAt)) : toLocalInputValue(new Date(Date.now() + 3600_000)));
  const [command, setCommand] = useState(task?.command ?? '');
  const [payloadAdded, setPayloadAdded] = useState(Boolean(task));
  const [payloadMenu, setPayloadMenu] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => { if (event.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    const previous = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => { window.removeEventListener('keydown', onKey); document.body.style.overflow = previous; };
  }, [onClose]);

  const save = useMutation({
    mutationFn: (body: unknown) => customFetch(task ? `/api/servers/${serverId}/schedules/${task.id}` : `/api/servers/${serverId}/schedules`, { method: task ? 'PUT' : 'POST', body: JSON.stringify(body) }),
    onSuccess: onSaved,
    onError: (err) => setError(errorMessage(err, 'Could not save the task.')),
  });

  const submit = () => {
    setError('');
    if (!name.trim()) return setError('Enter a task name.');
    if (!payloadAdded || !command.trim()) return setError('Add a “Send command” configuration and type the command.');
    let config: unknown;
    if (type === 'interval') {
      const h = Number(hours); const m = Number(minutes); const s = Number(seconds);
      if (![h, m, s].every(Number.isInteger) || h < 0 || m < 0 || s < 0 || m > 59 || s > 59) return setError('Use whole numbers: minutes and seconds between 0 and 59.');
      if (h * 3600 + m * 60 + s < 1) return setError('The interval must be at least 1 second.');
      config = { hours: h, minutes: m, seconds: s };
    } else if (type === 'periodic') {
      if (!days.length) return setError('Choose at least one day.');
      config = { days, time: time.length === 5 ? `${time}:00` : time, utcOffsetMinutes: -new Date().getTimezoneOffset() };
    } else {
      const date = new Date(runAt);
      if (Number.isNaN(date.getTime())) return setError('Choose a valid date and time.');
      if (date.getTime() <= Date.now()) return setError('Choose a time in the future.');
      config = { runAt: date.toISOString() };
    }
    save.mutate({ name: name.trim(), taskType: type, config, command: command.trim() });
  };

  const toggleDay = (day: number) => setDays((current) => (current.includes(day) ? current.filter((item) => item !== day) : [...current, day]));

  return createPortal(
    <div className="fixed inset-0 z-[70] grid place-items-center bg-black/60 p-3 backdrop-blur-sm sm:p-6" role="dialog" aria-modal="true" aria-label={task ? 'Edit task' : 'New task'} onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }} data-testid="dialog-schedule">
      <div className="flex max-h-[92dvh] w-full max-w-xl flex-col overflow-hidden rounded-2xl border border-slate-700 bg-[#1e1e1e] text-slate-100 shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-700/70 px-6 py-4"><h2 className="text-xl font-bold">{task ? 'Edit task' : 'New scheduled task'}</h2><button onClick={onClose} className="grid size-9 place-items-center rounded-lg text-slate-400 hover:bg-white/10 hover:text-white" aria-label="Close"><X className="size-5" /></button></div>
        <div className="space-y-5 overflow-y-auto px-6 py-6">
          <Field label="Task name"><input value={name} onChange={(event) => setName(event.target.value)} maxLength={60} placeholder="e.g. skyblock reminder" className={inputClass} data-testid="input-schedule-name" /></Field>
          <Field label="Task type">
            <select value={type} onChange={(event) => setType(event.target.value as ScheduleType)} className={inputClass} data-testid="select-schedule-type">
              <option value="interval">Interval-based task</option>
              <option value="periodic">Periodic task (days and time)</option>
              <option value="specific">Specific-time task (one time)</option>
            </select>
          </Field>

          {type === 'interval' && <div className="space-y-2">
            <div className="grid grid-cols-3 gap-3">
              <Field label="Hours"><input type="number" min={0} max={8760} value={hours} onChange={(event) => setHours(event.target.value)} className={inputClass} data-testid="input-schedule-hours" /></Field>
              <Field label="Minutes"><input type="number" min={0} max={59} value={minutes} onChange={(event) => setMinutes(event.target.value)} className={inputClass} data-testid="input-schedule-minutes" /></Field>
              <Field label="Seconds"><input type="number" min={0} max={59} value={seconds} onChange={(event) => setSeconds(event.target.value)} className={inputClass} data-testid="input-schedule-seconds" /></Field>
            </div>
            <p className="text-xs text-slate-400">The countdown starts now. When it reaches zero the command is sent and the countdown starts again.</p>
          </div>}

          {type === 'periodic' && <div className="space-y-4">
            <Field label="Days of the week">
              <div className="flex flex-wrap gap-2">{DAY_OPTIONS.map((day) => <button type="button" key={day.value} onClick={() => toggleDay(day.value)} aria-pressed={days.includes(day.value)} className={`h-10 min-w-12 rounded-lg border px-3 text-sm font-semibold transition ${days.includes(day.value) ? 'border-blue-500 bg-blue-600 text-white' : 'border-slate-600 text-slate-300 hover:bg-white/5'}`} data-testid={`button-schedule-day-${day.value}`}>{day.label}</button>)}</div>
            </Field>
            <Field label="Time of day"><input type="time" step={1} value={time} onChange={(event) => setTime(event.target.value)} className={inputClass} data-testid="input-schedule-time" /></Field>
            <p className="text-xs text-slate-400">Uses your browser’s current time zone.</p>
          </div>}

          {type === 'specific' && <div className="space-y-2">
            <Field label="Run at"><input type="datetime-local" step={1} value={runAt} onChange={(event) => setRunAt(event.target.value)} className={inputClass} data-testid="input-schedule-run-at" /></Field>
            <p className="text-xs text-slate-400">Runs once, then the task is switched off.</p>
          </div>}

          <div className="space-y-3 border-t border-slate-700/60 pt-5">
            <div className="flex items-center justify-between gap-3"><div><h3 className="text-lg font-bold">Task payload</h3><p className="text-xs text-slate-400">What happens when the task runs.</p></div>
              {!payloadAdded && <div className="relative"><button type="button" onClick={() => setPayloadMenu((open) => !open)} className="inline-flex h-10 items-center gap-2 rounded-lg border border-slate-600 px-4 text-sm font-semibold hover:bg-white/5" data-testid="button-add-payload"><Plus className="size-4" />Add configuration</button>
                {payloadMenu && <div className="absolute right-0 top-11 z-10 w-52 overflow-hidden rounded-lg border border-slate-600 bg-[#262626] shadow-xl"><button type="button" onClick={() => { setPayloadAdded(true); setPayloadMenu(false); }} className="flex w-full items-center gap-2 px-4 py-3 text-left text-sm hover:bg-white/10" data-testid="button-payload-send-command"><TerminalIcon className="size-4 text-teal-300" />Send command</button></div>}</div>}
            </div>
            {payloadAdded && <div className="space-y-2 rounded-xl border border-slate-700 bg-[#121920] p-4">
              <div className="flex items-center justify-between"><span className="inline-flex items-center gap-2 text-sm font-bold"><TerminalIcon className="size-4 text-teal-300" />Send command</span><button type="button" onClick={() => { setPayloadAdded(false); setCommand(''); }} className="text-xs font-semibold text-slate-400 hover:text-red-300" data-testid="button-remove-payload">Remove</button></div>
              <input value={command} onChange={(event) => setCommand(event.target.value)} maxLength={500} placeholder="/skyblock" autoCapitalize="off" autoCorrect="off" spellCheck={false} className={`${inputClass} font-mono`} data-testid="input-schedule-command" />
              <p className="text-xs text-slate-400">Typed into the terminal exactly like a manual command (it uses your Terminal Settings line ending and encoding).</p>
            </div>}
          </div>

          {error && <p className="rounded-lg bg-red-500/10 px-3 py-2 text-sm text-red-300" role="alert" data-testid="text-schedule-dialog-error">{error}</p>}
        </div>
        <div className="flex justify-end gap-3 border-t border-slate-700/70 px-6 py-4">
          <button onClick={onClose} className="h-11 rounded-xl border border-slate-600 px-5 text-sm font-semibold text-slate-200 hover:bg-white/5" data-testid="button-schedule-cancel">Cancel</button>
          <button onClick={submit} disabled={save.isPending} className="inline-flex h-11 items-center gap-2 rounded-xl bg-blue-600 px-6 text-sm font-bold text-white hover:bg-blue-500 disabled:opacity-60" data-testid="button-schedule-save">{save.isPending && <LoaderCircle className="size-4 animate-spin" />}Save</button>
        </div>
      </div>
    </div>,
    document.body,
  );
}
