import { lazy, Suspense, useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider, useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Link, Redirect, Route, Switch, Router as WouterRouter, useLocation, useParams } from 'wouter';
import { createPortal } from 'react-dom';
import { TerminalPanel } from './terminal';
import { SchedulePanel } from './schedule';
import ScriptsPage from './scripts';
import ConsolePage from './console';
import UsersPanel from './users';
import { useAccess } from './access';

// The code editor is loaded on demand so the rest of the panel stays light.
const CodeEditorDialog = lazy(() => import('./code-editor').then((module) => ({ default: module.CodeEditorDialog })));
import {
  Activity as ActivityIcon, AlertTriangle, Archive, ArrowLeft, CheckCircle2, ChevronRight, CircleHelp,
  Clock3, Cpu, Download, File as FileIcon, FileCode2, Folder, FolderOpen, Gauge, HardDrive, KeyRound,
  LayoutDashboard, LoaderCircle, LogOut, Menu, Play, Plus, RefreshCw,
  RotateCw, Save, Scissors, Search, Server, Settings, ShieldCheck, Square, Terminal, Trash2, UserCircle,
  Upload, X, Zap, ScrollText, SquareTerminal, Link2, FileArchive, Lock, MoreVertical, Pencil,
} from 'lucide-react';
import {
  ActivityKind, customFetch, downloadServerFile, downloadServerFileArchive, getGetCurrentAdminQueryKey, getGetDashboardQueryKey, getGetServerLogsQueryKey,
  getGetServerQueryKey, getGetServersQueryKey, getGetSetupStatusQueryKey, getGetServerFileContentQueryKey,
  getListServerFilesQueryKey, useCreateInitialAdmin,
  useCreateServer, useDeleteServer, useGetCurrentAdmin, useGetDashboard, useGetServer,
  useGetServerLogs, useGetServers, useGetSetupStatus, useKillServer, useLogin, useLogout, useRestartServer,
  useStartServer, useStopServer, useUpdateServer,
  useListServerFiles, useGetServerFileContent, useUploadServerFile, useCreateServerDirectory, useCreateServerFile,
  useSaveServerFileContent, useMoveServerFile, useDeleteServerFile,
  useDownloadServerFileFromUrl, useExtractServerZipArchive, useSetServerFilePermissions, type Admin, type ManagedServer, type ServerFileEntry,
} from '@workspace/api-client-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';

const queryClient = new QueryClient();

function formatDuration(seconds = 0) {
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  if (d) return `${d}d ${h}h`;
  if (h) return `${h}h ${m}m`;
  return `${m}m`;
}

function formatTime(value?: string | null) {
  if (!value) return '—';
  const date = new Date(value);
  return date.toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

function statusMeta(status: ManagedServer['status']) {
  return {
    online: { label: 'Online', tone: 'text-teal-700 bg-teal-50 border-teal-200', dot: 'bg-teal-500' },
    offline: { label: 'Offline', tone: 'text-slate-600 bg-slate-100 border-slate-200', dot: 'bg-slate-400' },
    starting: { label: 'Starting', tone: 'text-amber-700 bg-amber-50 border-amber-200', dot: 'bg-amber-500 animate-pulse' },
    stopping: { label: 'Stopping', tone: 'text-amber-700 bg-amber-50 border-amber-200', dot: 'bg-amber-500 animate-pulse' },
    failed: { label: 'Failed', tone: 'text-red-700 bg-red-50 border-red-200', dot: 'bg-red-500' },
  }[status];
}

function ErrorNotice({ onRetry }: { onRetry: () => void }) {
  return (
    <div className="rounded-xl border border-red-200 bg-red-50 p-5 text-red-800" data-testid="state-error">
      <div className="flex items-start gap-3">
        <AlertTriangle className="mt-0.5 size-5 shrink-0" />
        <div className="flex-1">
          <p className="font-semibold">Could not reach the control plane</p>
          <p className="mt-1 text-sm text-red-700/80">The API may be restarting. Your configuration is safe.</p>
        </div>
        <button onClick={onRetry} className="rounded-lg border border-red-200 bg-red-100 px-3 py-1.5 text-xs font-bold hover:bg-red-200" data-testid="button-retry">Retry</button>
      </div>
    </div>
  );
}

function LoadingState({ label = 'Reading control plane' }: { label?: string }) {
  return (
    <div className="space-y-5" data-testid="state-loading">
      <div className="flex items-center gap-3 text-sm text-muted-foreground"><LoaderCircle className="size-4 animate-spin text-primary" /> {label}</div>
      <div className="grid grid-cols-1 gap-4 md:grid-cols-3"><div className="skeleton h-28 rounded-xl" /><div className="skeleton h-28 rounded-xl" /><div className="skeleton h-28 rounded-xl" /></div>
      <div className="skeleton h-72 rounded-xl" />
    </div>
  );
}

function StatusBadge({ status }: { status: ManagedServer['status'] }) {
  const meta = statusMeta(status);
  return <span className={`inline-flex items-center gap-2 rounded-full border px-2.5 py-1 text-[11px] font-bold uppercase tracking-[.08em] ${meta.tone}`} data-testid={`status-server-${status}`}><span className={`status-dot ${meta.dot}`} />{meta.label}</span>;
}

function ServerMark({ name, size = 'md' }: { name: string; size?: 'sm' | 'md' | 'lg' }) {
  const sizeClass = size === 'lg' ? 'size-14 text-xl' : size === 'sm' ? 'size-9 text-xs' : 'size-11 text-sm';
  return <div className={`${sizeClass} grid shrink-0 place-items-center rounded-xl bg-[#dfe9e5] font-bold text-primary`} aria-hidden="true">{name.slice(0, 2).toUpperCase()}</div>;
}

function MetricCard({ label, value, note, icon: Icon, accent = 'primary' }: { label: string; value: string | number; note: string; icon: typeof Server; accent?: 'primary' | 'amber' | 'red' }) {
  const colors = { primary: 'text-primary bg-teal-50', amber: 'text-amber-700 bg-amber-50', red: 'text-red-700 bg-red-50' }[accent];
  return <div className="rounded-xl border bg-card p-5 shadow-[0_2px_10px_hsl(218_36%_18%/.035)]" data-testid={`metric-${label.toLowerCase().replaceAll(' ', '-')}`}>
    <div className="flex items-start justify-between"><p className="text-xs font-bold uppercase tracking-[.12em] text-muted-foreground">{label}</p><span className={`grid size-9 place-items-center rounded-lg ${colors}`}><Icon className="size-4" /></span></div>
    <p className="mt-4 text-3xl font-bold tracking-tight">{value}</p><p className="mt-1 text-xs text-muted-foreground">{note}</p>
  </div>;
}

function TextField({ label, value, onChange, placeholder, type = 'text', required = false, hint, name }: { label: string; value: string; onChange: (value: string) => void; placeholder?: string; type?: string; required?: boolean; hint?: string; name: string }) {
  const autoComplete = type === 'password' ? (name.includes('confirm') ? 'new-password' : name.includes('setup') ? 'new-password' : 'current-password') : name.includes('username') ? 'username' : undefined;
  return <label className="block space-y-2"><span className="flex justify-between text-xs font-bold uppercase tracking-[.1em] text-muted-foreground"><span>{label}{required && <b className="ml-1 text-accent">*</b>}</span>{hint && <span className="normal-case tracking-normal text-[11px] font-medium">{hint}</span>}</span><input autoComplete={autoComplete} data-testid={`input-${name}`} required={required} type={type} value={value} onChange={(event) => onChange(event.target.value)} placeholder={placeholder} className="h-11 w-full rounded-lg border bg-background px-3.5 text-sm outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/15 placeholder:text-muted-foreground/60" /></label>;
}

function TextAreaField({ label, value, onChange, placeholder, name }: { label: string; value: string; onChange: (value: string) => void; placeholder?: string; name: string }) {
  return <label className="block space-y-2"><span className="text-xs font-bold uppercase tracking-[.1em] text-muted-foreground">{label}</span><textarea data-testid={`input-${name}`} value={value} onChange={(event) => onChange(event.target.value)} placeholder={placeholder} rows={3} className="w-full resize-y rounded-lg border bg-background px-3.5 py-3 text-sm outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/15 placeholder:text-muted-foreground/60" /></label>;
}

function Button({ children, onClick, type = 'button', variant = 'primary', disabled = false, className = '', testId }: { children: ReactNode; onClick?: () => void; type?: 'button' | 'submit'; variant?: 'primary' | 'secondary' | 'ghost' | 'danger'; disabled?: boolean; className?: string; testId?: string }) {
  const variants = { primary: 'bg-primary text-primary-foreground hover:brightness-95 shadow-sm', secondary: 'border bg-card text-foreground hover:bg-muted', ghost: 'text-muted-foreground hover:bg-muted hover:text-foreground', danger: 'border border-red-200 bg-red-50 text-red-700 hover:bg-red-100' };
  return <button type={type} onClick={onClick} disabled={disabled} data-testid={testId} className={`inline-flex h-10 items-center justify-center gap-2 rounded-lg px-3.5 text-sm font-bold transition disabled:pointer-events-none disabled:opacity-50 ${variants[variant]} ${className}`}>{children}</button>;
}

function AuthBrand({ eyebrow, title, body }: { eyebrow: string; title: ReactNode; body: string }) {
  return <div className="relative hidden min-h-[100dvh] overflow-hidden bg-sidebar p-10 text-sidebar-foreground lg:flex lg:w-[46%] lg:flex-col lg:justify-between">
    <div className="absolute inset-0 grid-texture opacity-[.08]" /><div className="relative">
      <Link href="/" className="flex items-center gap-3" data-testid="link-brand"><span className="grid size-10 place-items-center rounded-xl bg-sidebar-primary text-sidebar-primary-foreground"><Zap className="size-5" /></span><span className="font-bold tracking-tight">node<span className="text-sidebar-primary">watch</span></span></Link>
      <div className="mt-28 max-w-md"><p className="mono text-xs uppercase tracking-[.2em] text-sidebar-primary">{eyebrow}</p><h1 className="mt-5 text-5xl font-bold leading-[1.02] tracking-[-.05em]">{title}</h1><p className="mt-6 max-w-sm text-base leading-7 text-sidebar-foreground/65">{body}</p></div>
    </div>
    <div className="relative flex items-center gap-2 text-xs text-sidebar-foreground/45"><span className="status-dot bg-sidebar-primary" /> Control plane ready for your next deployment</div>
  </div>;
}

function LoginScreen() {
  const [, setLocation] = useLocation();
  const login = useLogin();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const submit = (event: FormEvent) => {
    event.preventDefault(); setError('');
    if (!username.trim() || !password) return setError('Enter your username and password.');
    login.mutate({ data: { username: username.trim(), password } }, { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getGetCurrentAdminQueryKey() }); setLocation('/dashboard'); }, onError: () => setError('That sign-in did not work. Check your credentials and try again.') });
  };
  return <div className="flex min-h-[100dvh] bg-background"><AuthBrand eyebrow="Operator access" title={<>Keep the important<br /><span className="text-sidebar-primary">processes moving.</span></>} body="A focused control room for Node.js services. See what is healthy, understand what changed, and act before your users notice." /><main className="flex flex-1 items-center justify-center p-6 sm:p-10"><div className="w-full max-w-[390px] animate-rise">
    <div className="mb-10 lg:hidden"><Link href="/" className="flex items-center gap-3 font-bold" data-testid="link-brand-mobile"><span className="grid size-10 place-items-center rounded-xl bg-primary text-primary-foreground"><Zap className="size-5" /></span>node<span className="text-primary">watch</span></Link></div>
    <div className="mb-9"><p className="mono text-[11px] uppercase tracking-[.18em] text-primary">Welcome back</p><h2 className="mt-3 text-3xl font-bold tracking-tight">Sign in to your panel</h2><p className="mt-2 text-sm text-muted-foreground">Your processes are waiting for you.</p></div>
    <form onSubmit={submit} className="space-y-5"><TextField name="username" label="Username" value={username} onChange={setUsername} placeholder="operator" required /><TextField name="password" label="Password" type="password" value={password} onChange={setPassword} placeholder="••••••••" required />{error && <p className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700" data-testid="text-login-error">{error}</p>}<Button type="submit" disabled={login.isPending} className="mt-2 w-full" testId="button-login">{login.isPending ? <LoaderCircle className="size-4 animate-spin" /> : <KeyRound className="size-4" />}Sign in</Button></form>
    <p className="mt-9 text-center text-xs text-muted-foreground">Restricted to administrators · Session protected</p>
  </div></main></div>;
}

function SetupScreen() {
  const setup = useCreateInitialAdmin();
  const [, setLocation] = useLocation();
  const [displayName, setDisplayName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState('');
  const submit = (event: FormEvent) => {
    event.preventDefault(); setError('');
    if (displayName.trim().length < 2) return setError('Display name must be at least 2 characters.');
    if (username.trim().length < 3) return setError('Username must be at least 3 characters.');
    if (password.length < 8) return setError('Password must be at least 8 characters.');
    if (password !== confirm) return setError('Passwords do not match.');
    setup.mutate({ data: { displayName: displayName.trim(), username: username.trim(), password } }, { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getGetSetupStatusQueryKey() }); setLocation('/dashboard'); }, onError: () => setError('Could not create the administrator. The setup may already be complete.') });
  };
  return <div className="flex min-h-[100dvh] bg-background"><AuthBrand eyebrow="First run" title={<>Set the tone for<br /><span className="text-sidebar-primary">your control room.</span></>} body="Create the administrator account for this nodewatch instance. You will be the only person with access until you share the panel." /><main className="flex flex-1 items-center justify-center p-6 sm:p-10"><div className="w-full max-w-[430px] animate-rise">
    <div className="mb-9 lg:hidden"><Link href="/" className="flex items-center gap-3 font-bold" data-testid="link-brand-mobile"><span className="grid size-10 place-items-center rounded-xl bg-primary text-primary-foreground"><Zap className="size-5" /></span>node<span className="text-primary">watch</span></Link></div>
    <div className="mb-8"><p className="mono text-[11px] uppercase tracking-[.18em] text-primary">Initialize instance</p><h2 className="mt-3 text-3xl font-bold tracking-tight">Create your admin</h2><p className="mt-2 text-sm leading-6 text-muted-foreground">This takes less than a minute. Choose credentials you will remember.</p></div>
    <form onSubmit={submit} className="space-y-4"><TextField name="display-name" label="Display name" value={displayName} onChange={setDisplayName} placeholder="Alex Morgan" required /><TextField name="setup-username" label="Username" value={username} onChange={setUsername} placeholder="alex" required /><TextField name="setup-password" label="Password" type="password" value={password} onChange={setPassword} placeholder="At least 8 characters" required /><TextField name="confirm-password" label="Confirm password" type="password" value={confirm} onChange={setConfirm} placeholder="Repeat your password" required />{error && <p className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700" data-testid="text-setup-error">{error}</p>}<Button type="submit" disabled={setup.isPending} className="mt-2 w-full" testId="button-create-admin">{setup.isPending ? <LoaderCircle className="size-4 animate-spin" /> : <ShieldCheck className="size-4" />}Create administrator</Button></form>
  </div></main></div>;
}

function Sidebar({ admin, mobileOpen, onClose }: { admin: Admin; mobileOpen: boolean; onClose: () => void }) {
  const [location, setLocation] = useLocation();
  const { isAdmin, can } = useAccess();
  const logout = useLogout();
  const allNav = [{ href: '/dashboard', label: 'Overview', icon: LayoutDashboard }, { href: '/servers', label: 'Servers', icon: Server }, { href: '/scripts', label: 'Scripts', icon: ScrollText }, { href: '/console', label: 'Console', icon: SquareTerminal }, { href: '/settings', label: 'Settings', icon: Settings }];
  const nav = isAdmin ? allNav : allNav.filter((item) => item.href === '/servers' || (item.href === '/scripts' && can('scripts')));
  const signOut = () => logout.mutate(undefined, { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getGetCurrentAdminQueryKey() }); queryClient.removeQueries({ queryKey: ['auth-access'] }); setLocation('/'); } });
  return <><div className={`fixed inset-0 z-30 bg-sidebar/35 backdrop-blur-sm transition-opacity lg:hidden ${mobileOpen ? 'opacity-100' : 'pointer-events-none opacity-0'}`} onClick={onClose} /><aside className={`fixed inset-y-0 left-0 z-40 flex w-[258px] flex-col bg-sidebar text-sidebar-foreground shadow-2xl transition-transform duration-300 lg:translate-x-0 ${mobileOpen ? 'translate-x-0' : '-translate-x-full'}`}>
    <div className="flex h-[76px] items-center justify-between border-b border-sidebar-border px-6"><Link href={isAdmin ? '/dashboard' : '/servers'} className="flex items-center gap-3 font-bold tracking-tight" onClick={onClose} data-testid="link-sidebar-brand"><span className="grid size-9 place-items-center rounded-lg bg-sidebar-primary text-sidebar-primary-foreground"><Zap className="size-4" /></span>node<span className="text-sidebar-primary">watch</span></Link><button className="lg:hidden" onClick={onClose} aria-label="Close menu" data-testid="button-close-menu"><X className="size-5" /></button></div>
    <div className="flex-1 px-3 py-6"><p className="px-3 pb-3 text-[10px] font-bold uppercase tracking-[.18em] text-sidebar-foreground/35">Operations</p>{nav.map(({ href, label, icon: Icon }) => <Link href={href} key={href} onClick={onClose} data-testid={`link-nav-${label.toLowerCase()}`} className={`mb-1 flex h-11 items-center gap-3 rounded-lg px-3 text-sm font-semibold transition ${location === href || (href === '/servers' && location.startsWith('/servers/')) ? 'bg-sidebar-accent text-sidebar-accent-foreground' : 'text-sidebar-foreground/60 hover:bg-sidebar-accent/70 hover:text-sidebar-foreground'}`}><Icon className="size-[17px]" />{label}{href === '/servers' && <ChevronRight className="ml-auto size-3 opacity-50" />}</Link>)}</div>
    <div className="border-t border-sidebar-border p-3"><div className="flex items-center gap-3 rounded-lg bg-sidebar-accent/55 p-3"><span className="grid size-9 place-items-center rounded-full bg-sidebar-primary/20 text-xs font-bold text-sidebar-primary">{admin.displayName.slice(0, 2).toUpperCase()}</span><div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold">{admin.displayName}</p><p className="truncate text-xs text-sidebar-foreground/45">@{admin.username}</p></div><button onClick={signOut} disabled={logout.isPending} className="text-sidebar-foreground/45 hover:text-sidebar-primary" aria-label="Sign out" data-testid="button-logout"><LogOut className="size-4" /></button></div><p className="mono px-3 pt-3 text-[9px] uppercase tracking-[.14em] text-sidebar-foreground/30">Local control plane · v1.0</p></div>
  </aside></>;
}

function AppShell({ admin, children }: { admin: Admin; children: ReactNode }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [location] = useLocation();
  const title = location === '/dashboard' || location === '/' ? 'Overview' : location === '/servers' ? 'Servers' : location === '/scripts' ? 'Scripts' : location === '/console' ? 'Console' : location === '/settings' ? 'Settings' : 'Server detail';
  return <div className="min-h-[100dvh] overflow-x-clip bg-background"><Sidebar admin={admin} mobileOpen={mobileOpen} onClose={() => setMobileOpen(false)} /><div className="min-w-0 lg:pl-[258px]"><header className="sticky top-0 z-20 flex h-[76px] items-center justify-between border-b bg-background/90 px-5 backdrop-blur-md sm:px-8"><div className="flex items-center gap-3"><button onClick={() => setMobileOpen(true)} className="grid size-9 place-items-center rounded-lg border bg-card lg:hidden" aria-label="Open menu" data-testid="button-open-menu"><Menu className="size-4" /></button><div><p className="mono text-[10px] uppercase tracking-[.18em] text-muted-foreground">Nodewatch / {title}</p><h1 className="mt-0.5 text-lg font-bold tracking-tight">{title}</h1></div></div><div className="flex items-center gap-3"><span className="hidden items-center gap-2 text-xs font-medium text-muted-foreground sm:flex"><span className="status-dot bg-primary animate-pulse-line" />Control plane connected</span><span className="grid size-9 place-items-center rounded-full border bg-card text-xs font-bold text-primary">{admin.displayName.slice(0, 2).toUpperCase()}</span></div></header><main className="mx-auto min-w-0 max-w-[1440px] p-4 sm:p-8">{children}</main></div></div>;
}

function EmptyServers({ onAdd, canAdd = true }: { onAdd: () => void; canAdd?: boolean }) {
  return <div className="grid min-h-[300px] place-items-center rounded-xl border border-dashed bg-card p-8 text-center" data-testid="empty-servers"><div><span className="mx-auto grid size-14 place-items-center rounded-2xl bg-teal-50 text-primary"><Server className="size-6" /></span><h3 className="mt-5 text-lg font-bold">{canAdd ? 'No processes configured' : 'No servers available'}</h3><p className="mx-auto mt-2 max-w-sm text-sm leading-6 text-muted-foreground">{canAdd ? 'Add the first Node.js service to begin watching health, logs, and lifecycle actions.' : 'No server has been shared with your account yet. Ask an administrator for access.'}</p>{canAdd && <Button onClick={onAdd} className="mt-5" testId="button-empty-add-server"><Plus className="size-4" />Add a server</Button>}</div></div>;
}

function ServerRow({ server, onAction }: { server: ManagedServer; onAction: (action: 'start' | 'stop' | 'restart' | 'kill', server: ManagedServer) => void }) {
  const { can } = useAccess();
  const canPower = can('power');
  const canKill = can('kill');
  return <div className="group grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 border-b px-4 py-4 last:border-b-0 sm:grid-cols-[1.4fr_1fr_.8fr_auto] sm:px-6" data-testid={`row-server-${server.id}`}><Link href={`/servers/${server.id}`} className="flex min-w-0 items-center gap-3" data-testid={`link-server-${server.id}`}><ServerMark name={server.name} size="sm" /><div className="min-w-0"><p className="truncate text-sm font-bold">{server.name}</p><p className="truncate text-xs text-muted-foreground">{server.directory}</p></div></Link><div className="hidden min-w-0 sm:block"><p className="mono truncate text-[11px] text-muted-foreground">{server.command}</p><p className="mt-1 text-xs text-muted-foreground">{server.port ? `Port ${server.port}` : 'No port assigned'}</p></div><div className="hidden sm:block">{server.status === 'online' ? <p className="text-sm font-semibold">{formatDuration(server.uptimeSeconds)}</p> : <p className="text-sm text-muted-foreground">—</p>}<p className="text-[11px] text-muted-foreground">uptime</p></div><div className="flex flex-col items-end gap-2 sm:flex-row sm:items-center"><StatusBadge status={server.status} /><div className="hidden gap-1 max-sm:flex sm:pl-2 sm:group-hover:flex">{server.status === 'online' ? <>{canPower && <button onClick={() => onAction('stop', server)} className="grid size-8 place-items-center rounded-lg border text-muted-foreground hover:bg-muted" aria-label={`Stop ${server.name}`} data-testid={`button-stop-${server.id}`}><Square className="size-3.5" /></button>}{canKill && <button onClick={() => onAction('kill', server)} className="grid size-8 place-items-center rounded-lg border border-red-200 text-red-700 hover:bg-red-50" aria-label={`Kill ${server.name}`} data-testid={`button-kill-${server.id}`}><X className="size-3.5" /></button>}</> : canPower ? <button onClick={() => onAction('start', server)} className="grid size-8 place-items-center rounded-lg border text-primary hover:bg-teal-50" aria-label={`Start ${server.name}`} data-testid={`button-start-${server.id}`}><Play className="size-3.5 fill-current" /></button> : null}{canPower && <button onClick={() => onAction('restart', server)} className="grid size-8 place-items-center rounded-lg border text-muted-foreground hover:bg-muted" aria-label={`Restart ${server.name}`} data-testid={`button-restart-${server.id}`}><RotateCw className="size-3.5" /></button>}</div></div></div>;
}

function DashboardPage() {
  const dashboard = useGetDashboard();
  const [, setLocation] = useLocation();
  const start = useStartServer();
  const stop = useStopServer();
  const restart = useRestartServer();
  const kill = useKillServer();
  const invalidate = () => { queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() }); queryClient.invalidateQueries({ queryKey: getGetServersQueryKey() }); };
  const action = (kind: 'start' | 'stop' | 'restart' | 'kill', server: ManagedServer) => {
    const mutation = kind === 'start' ? start : kind === 'stop' ? stop : kind === 'kill' ? kill : restart;
    mutation.mutate({ id: server.id }, { onSuccess: invalidate, onError: invalidate });
  };
  if (dashboard.isLoading) return <LoadingState />;
  if (dashboard.isError || !dashboard.data) return <ErrorNotice onRetry={() => dashboard.refetch()} />;
  const data = dashboard.data;
  return <div className="space-y-7 animate-rise"><div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end"><div><p className="text-sm text-muted-foreground">A quiet control room is a good one.</p><h2 className="mt-1 text-2xl font-bold tracking-tight">Good to see you, operator.</h2></div><Button variant="secondary" onClick={() => dashboard.refetch()} disabled={dashboard.isFetching} testId="button-refresh-dashboard"><RefreshCw className={`size-4 ${dashboard.isFetching ? 'animate-spin' : ''}`} />Refresh view</Button></div>
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-3"><MetricCard label="Online now" value={data.onlineServers} note={`${data.totalServers} total configured`} icon={CheckCircle2} /><MetricCard label="Needs attention" value={data.failedServers} note={data.failedServers ? 'Review failed processes' : 'All systems look clear'} icon={AlertTriangle} accent={data.failedServers ? 'red' : 'primary'} /><MetricCard label="System memory" value={`${Math.round(data.system.memoryPercent)}%`} note={`${data.system.memoryUsedMb} / ${data.system.memoryTotalMb} MB`} icon={HardDrive} accent={data.system.memoryPercent > 85 ? 'amber' : 'primary'} /></div>
    <div className="grid grid-cols-1 gap-6 xl:grid-cols-[1.45fr_.85fr]"><section className="overflow-hidden rounded-xl border bg-card shadow-[0_2px_10px_hsl(218_36%_18%/.035)]"><div className="flex items-center justify-between border-b px-5 py-4 sm:px-6"><div><h3 className="font-bold">Process health</h3><p className="mt-1 text-xs text-muted-foreground">Live status across your configured services</p></div><Link href="/servers" className="text-xs font-bold text-primary hover:underline" data-testid="link-view-all-servers">View all <ChevronRight className="ml-1 inline size-3" /></Link></div>{data.servers.length ? data.servers.map((server) => <ServerRow key={server.id} server={server} onAction={action} />) : <div className="p-6"><EmptyServers onAdd={() => setLocation('/servers?create=1')} /></div>}</section>
      <section className="rounded-xl border bg-sidebar p-5 text-sidebar-foreground shadow-[0_2px_10px_hsl(218_36%_18%/.08)] sm:p-6"><div className="flex items-start justify-between"><div><p className="mono text-[10px] uppercase tracking-[.16em] text-sidebar-primary">Host telemetry</p><h3 className="mt-2 text-lg font-bold">System load</h3></div><Gauge className="size-5 text-sidebar-primary" /></div><div className="mt-7 space-y-6"><LoadBar label="CPU" value={data.system.cpuPercent} icon={Cpu} /><LoadBar label="Memory" value={data.system.memoryPercent} icon={HardDrive} /></div><div className="mt-8 border-t border-sidebar-border pt-4"><p className="text-xs text-sidebar-foreground/50">Host uptime</p><p className="mono mt-1 text-xl font-bold text-sidebar-primary">{formatDuration(data.system.uptimeSeconds)}</p></div></section></div>
    <ActivityFeed items={data.recentActivity} />
  </div>;
}

function LoadBar({ label, value, icon: Icon }: { label: string; value: number; icon: typeof Cpu }) {
  return <div><div className="mb-2 flex items-center justify-between"><span className="flex items-center gap-2 text-sm font-semibold"><Icon className="size-4 text-sidebar-foreground/45" />{label}</span><span className="mono text-xs text-sidebar-primary">{Math.round(value)}%</span></div><div className="h-2 overflow-hidden rounded-full bg-sidebar-accent"><div className="h-full rounded-full bg-sidebar-primary transition-all duration-700" style={{ width: `${Math.min(100, value)}%` }} /></div></div>;
}

function ActivityFeed({ items }: { items: { id: number; message: string; kind: string; createdAt: string }[] }) {
  const queryClient = useQueryClient();
  const [clearError, setClearError] = useState('');
  const clearAll = useMutation({
    mutationFn: () => customFetch('/api/activity', { method: 'DELETE' }),
    onSuccess: () => { setClearError(''); void queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() }); },
    onError: () => setClearError('Could not clear the activity. Try again.'),
  });
  const iconFor = (kind: string) => kind === ActivityKind.success ? <CheckCircle2 className="size-4 text-primary" /> : kind === ActivityKind.error ? <AlertTriangle className="size-4 text-red-600" /> : kind === ActivityKind.warning ? <AlertTriangle className="size-4 text-amber-600" /> : <ActivityIcon className="size-4 text-muted-foreground" />;
  return <section className="rounded-xl border bg-card shadow-[0_2px_10px_hsl(218_36%_18%/.035)]">
    <div className="flex items-start justify-between gap-3 border-b px-5 py-4 sm:px-6">
      <div className="min-w-0"><h3 className="font-bold">Recent activity</h3><p className="mt-1 text-xs text-muted-foreground">The latest events from your process manager</p></div>
      {items.length > 0 && <button onClick={() => { if (window.confirm('Delete all recent activity? This cannot be undone.')) clearAll.mutate(); }} disabled={clearAll.isPending} className="inline-flex h-9 shrink-0 items-center gap-1.5 rounded-lg border px-3 text-xs font-bold text-muted-foreground transition hover:bg-red-50 hover:text-red-700 disabled:opacity-50" title="Delete all recent activity" data-testid="button-clear-activity">{clearAll.isPending ? <LoaderCircle className="size-4 animate-spin" /> : <Trash2 className="size-4" />}Clear all</button>}
    </div>
    {clearError && <p className="border-b px-5 py-3 text-xs text-red-700 sm:px-6" role="alert" data-testid="text-clear-activity-error">{clearError}</p>}
    {items.length ? <div className="divide-y">{items.slice(0, 7).map((item) => <div className="flex items-center gap-3 px-5 py-3.5 sm:px-6" key={item.id} data-testid={`activity-${item.id}`}><span className="grid size-7 shrink-0 place-items-center rounded-full bg-muted">{iconFor(item.kind)}</span><p className="min-w-0 flex-1 break-words text-sm">{item.message}</p><time className="shrink-0 text-xs text-muted-foreground">{formatTime(item.createdAt)}</time></div>)}</div> : <div className="p-8 text-center text-sm text-muted-foreground" data-testid="empty-activity">No activity recorded yet.</div>}
  </section>;
}

function ServerForm({ initial, onDone, onCancel }: { initial?: ManagedServer; onDone: () => void; onCancel?: () => void }) {
  const create = useCreateServer();
  const update = useUpdateServer();
  const [name, setName] = useState(initial?.name ?? '');
  const [description, setDescription] = useState(initial?.description ?? '');
  const [command, setCommand] = useState(initial?.command ?? '');
  const [port, setPort] = useState(initial?.port ? String(initial.port) : '');
  const [folderMode, setFolderMode] = useState<'auto' | 'manual'>('auto');
  const [folderPath, setFolderPath] = useState('');
  const [error, setError] = useState('');
  const pending = create.isPending || update.isPending;
  const submit = (event: FormEvent) => {
    event.preventDefault(); setError('');
    if (name.trim().length < 2) return setError('Name must be at least 2 characters.');
    if (!command.trim()) return setError('Start command is required.');
    if (port && (!Number.isInteger(Number(port)) || Number(port) < 1 || Number(port) > 65535)) return setError('Port must be a whole number between 1 and 65535.');
    if (!initial && folderMode === 'manual' && !folderPath.trim().startsWith('/')) return setError('Enter the full folder path, starting with / (for example /home/me/my-server).');
    const data = { name: name.trim(), description: description.trim(), command: command.trim(), port: port ? Number(port) : null };
    const options = { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getGetServersQueryKey() }); queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() }); if (initial) queryClient.invalidateQueries({ queryKey: getGetServerQueryKey(initial.id) }); onDone(); }, onError: () => setError('Could not save this server. Check the values and try again.') };
    if (initial) update.mutate({ id: initial.id, data }, options); else { const body = folderMode === 'manual' ? { ...data, directoryMode: 'manual', directoryPath: folderPath.trim() } : data; create.mutate({ data: body }, options); }
  };
  return <form onSubmit={submit} className="space-y-5" data-testid={initial ? 'form-edit-server' : 'form-create-server'}><div className="grid grid-cols-1 gap-5 sm:grid-cols-2"><TextField name="server-name" label="Server name" value={name} onChange={setName} placeholder="Billing API" required /><TextField name="server-port" label="Port" value={port} onChange={setPort} placeholder="Optional · 3000" hint="1–65535" /><div className="sm:col-span-2"><TextAreaField name="server-description" label="Description" value={description} onChange={setDescription} placeholder="What does this process do?" /></div><div className="sm:col-span-2 space-y-3 rounded-lg border bg-muted/30 px-4 py-3" data-testid="text-server-folder-hint">{initial ? <p className="text-xs leading-5 text-muted-foreground">Server folder: <span className="mono text-foreground">{initial.directory}</span></p> : <>
          <div><p className="text-xs font-bold uppercase tracking-[.1em] text-muted-foreground">Server folder</p>
            <div className="mt-2 grid grid-cols-2 gap-2" role="radiogroup" aria-label="Server folder">
              <button type="button" role="radio" aria-checked={folderMode === 'auto'} onClick={() => setFolderMode('auto')} className={`rounded-lg border px-3 py-2.5 text-left text-sm font-semibold transition ${folderMode === 'auto' ? 'border-primary bg-card ring-1 ring-primary' : 'bg-card/50 hover:bg-card'}`} data-testid="radio-folder-auto">Automatic<span className="mt-0.5 block text-[11px] font-normal text-muted-foreground">Created for you</span></button>
              <button type="button" role="radio" aria-checked={folderMode === 'manual'} onClick={() => setFolderMode('manual')} className={`rounded-lg border px-3 py-2.5 text-left text-sm font-semibold transition ${folderMode === 'manual' ? 'border-primary bg-card ring-1 ring-primary' : 'bg-card/50 hover:bg-card'}`} data-testid="radio-folder-manual">Choose manually<span className="mt-0.5 block text-[11px] font-normal text-muted-foreground">Use your own path</span></button>
            </div></div>
          {folderMode === 'auto' ? <p className="text-xs leading-5 text-muted-foreground">A folder named after the server is created in <span className="mono text-foreground">servers/</span> and is deleted together with the server. Upload your files from the Files tab.</p>
            : <div className="space-y-2"><TextField name="server-folder-path" label="Folder path" value={folderPath} onChange={setFolderPath} placeholder="/home/me/my-server" hint="Full path. It is created if it does not exist yet." /><p className="text-xs leading-5 text-muted-foreground">Deleting the server never deletes a folder you chose manually; your files stay where they are.</p></div>}</>}</div><div className="sm:col-span-2"><TextField name="server-command" label="Start command" value={command} onChange={setCommand} placeholder="npm run start" required hint="Runs inside the server folder" /></div></div>{error && <p className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700" data-testid="text-server-form-error">{error}</p>}<div className="flex justify-end gap-3 border-t pt-5"><Button variant="secondary" onClick={onCancel} testId="button-cancel-server">Cancel</Button><Button type="submit" disabled={pending} testId="button-save-server">{pending ? <LoaderCircle className="size-4 animate-spin" /> : <Save className="size-4" />}{initial ? 'Save changes' : 'Add server'}</Button></div></form>;
}

function ServersPage() {
  const { isAdmin } = useAccess();
  const servers = useGetServers();
  const [, setLocation] = useLocation();
  const [showForm, setShowForm] = useState(false);
  const [query, setQuery] = useState('');
  const start = useStartServer(); const stop = useStopServer(); const restart = useRestartServer(); const kill = useKillServer();
  const filtered = useMemo(() => (servers.data ?? []).filter((server) => `${server.name} ${server.description} ${server.directory}`.toLowerCase().includes(query.toLowerCase())), [servers.data, query]);
  useEffect(() => { if (new URLSearchParams(window.location.search).get('create') === '1') setShowForm(true); }, []);
  const action = (kind: 'start' | 'stop' | 'restart' | 'kill', server: ManagedServer) => { const mutation = kind === 'start' ? start : kind === 'stop' ? stop : kind === 'kill' ? kill : restart; mutation.mutate({ id: server.id }, { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getGetServersQueryKey() }); queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() }); }, onError: () => { queryClient.invalidateQueries({ queryKey: getGetServersQueryKey() }); } }); };
  return <div className="space-y-7 animate-rise"><div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end"><div><p className="text-sm text-muted-foreground">Configure and control every managed process.</p><h2 className="mt-1 text-2xl font-bold tracking-tight">Your servers</h2></div>{isAdmin && <Button onClick={() => setShowForm(true)} testId="button-add-server"><Plus className="size-4" />Add server</Button>}</div>
    {showForm && isAdmin && <div className="rounded-xl border bg-card p-5 shadow-[0_2px_10px_hsl(218_36%_18%/.035)] sm:p-6"><div className="mb-6 flex items-start justify-between"><div><p className="mono text-[10px] uppercase tracking-[.16em] text-primary">New process</p><h3 className="mt-2 text-lg font-bold">Configure a server</h3><p className="mt-1 text-sm text-muted-foreground">The server folder is created automatically from the name you choose.</p></div><button onClick={() => setShowForm(false)} className="rounded-lg p-2 text-muted-foreground hover:bg-muted" aria-label="Close form" data-testid="button-close-server-form"><X className="size-4" /></button></div><ServerForm onDone={() => setShowForm(false)} onCancel={() => setShowForm(false)} /></div>}
    <div className="overflow-hidden rounded-xl border bg-card shadow-[0_2px_10px_hsl(218_36%_18%/.035)]"><div className="flex flex-col justify-between gap-3 border-b p-4 sm:flex-row sm:items-center sm:px-6"><div><h3 className="font-bold">Configured processes <span className="ml-1 text-muted-foreground">({servers.data?.length ?? 0})</span></h3></div><label className="relative block sm:w-64"><Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search servers" className="h-9 w-full rounded-lg border bg-background pl-9 pr-3 text-sm outline-none focus:border-primary" data-testid="input-search-servers" /></label></div>{servers.isLoading ? <div className="p-6"><LoadingState label="Loading configured servers" /></div> : servers.isError ? <div className="p-6"><ErrorNotice onRetry={() => servers.refetch()} /></div> : !servers.data?.length ? <div className="p-6"><EmptyServers onAdd={() => setShowForm(true)} canAdd={isAdmin} /></div> : filtered.length ? <div>{filtered.map((server) => <ServerRow key={server.id} server={server} onAction={action} />)}</div> : <div className="p-12 text-center text-sm text-muted-foreground" data-testid="empty-server-search">No servers match “{query}”.</div>}</div>
  </div>;
}

function ConfirmDelete({ server, onCancel, onConfirm, pending }: { server: ManagedServer; onCancel: () => void; onConfirm: () => void; pending: boolean }) {
  const folder = useQuery({ queryKey: ['folder-info', server.id], queryFn: () => customFetch<{ directory: string; managed: boolean }>(`/api/servers/${server.id}/folder-info`), staleTime: 0 });
  const keepsFolder = folder.data ? !folder.data.managed : false;
  return <div className="fixed inset-0 z-50 grid place-items-center bg-sidebar/45 p-5 backdrop-blur-sm" role="dialog" aria-modal="true" data-testid="dialog-delete-server"><div className="w-full max-w-md rounded-2xl border bg-card p-6 shadow-2xl"><span className="grid size-11 place-items-center rounded-xl bg-red-50 text-red-700"><Trash2 className="size-5" /></span><h2 className="mt-5 text-xl font-bold">Delete {server.name}?</h2><p className="mt-2 text-sm leading-6 text-muted-foreground" data-testid="text-delete-folder-info">{folder.isLoading ? 'Checking the server folder…' : keepsFolder ? <>This stops the process and removes its configuration. The folder <span className="mono text-xs">{server.directory}</span> was chosen manually, so it and your files are <strong>kept</strong>.</> : <>This stops the process, removes its configuration, and permanently deletes the folder <span className="mono text-xs">{server.directory}</span> with everything inside it.</>}</p><div className="mt-6 flex flex-col-reverse gap-3 sm:flex-row sm:justify-end"><Button variant="secondary" onClick={onCancel} testId="button-cancel-delete">Keep server</Button><Button variant="danger" onClick={onConfirm} disabled={pending || folder.isLoading} testId="button-confirm-delete">{pending && <LoaderCircle className="size-4 animate-spin" />}{keepsFolder ? 'Delete server' : 'Delete server and folder'}</Button></div></div></div>;
}

function ServerFiles({ server }: { server: ManagedServer }) {
  const { can } = useAccess();
  const canEdit = can('files_edit');
  const [path, setPath] = useState('');
  const params = useMemo(() => path ? { path } : {}, [path]);
  const listing = useListServerFiles(server.id, params, { query: { queryKey: getListServerFilesQueryKey(server.id, params) } });
  const [openPath, setOpenPath] = useState('');
  const [pendingUpload, setPendingUpload] = useState<File | null>(null);
  const fileParams = useMemo(() => ({ path: openPath }), [openPath]);
  const fileQuery = useGetServerFileContent(server.id, fileParams, { query: { enabled: !!openPath, queryKey: getGetServerFileContentQueryKey(server.id, fileParams) } });
  const upload = useUploadServerFile({ request: { headers: { 'X-File-Name': encodeURIComponent(pendingUpload?.name ?? '') } } });
  const createDirectory = useCreateServerDirectory();
  const createFile = useCreateServerFile();
  const saveFile = useSaveServerFileContent();
  const moveFile = useMoveServerFile();
  const deleteFile = useDeleteServerFile();
  const downloadFromUrl = useDownloadServerFileFromUrl();
  const extractZip = useExtractServerZipArchive();
  const setPermissions = useSetServerFilePermissions();
  const [urlOpen, setUrlOpen] = useState(false);
  const [downloadUrl, setDownloadUrl] = useState('');
  const [chmodTarget, setChmodTarget] = useState<ServerFileEntry | null>(null);
  const [chmodMode, setChmodMode] = useState('755');
  const [unzipPath, setUnzipPath] = useState('');
  const [renameTarget, setRenameTarget] = useState<ServerFileEntry | null>(null);
  const [renameValue, setRenameValue] = useState('');
  const [editorDirty, setEditorDirty] = useState(false);
  const [createKind, setCreateKind] = useState<'' | 'folder' | 'file'>('');
  const [newName, setNewName] = useState('');
  const [selectedPaths, setSelectedPaths] = useState<string[]>([]);
  const [cutPaths, setCutPaths] = useState<string[]>([]);
  const [deleteTargets, setDeleteTargets] = useState<ServerFileEntry[] | null>(null);
  const [batchDeletePending, setBatchDeletePending] = useState(false);
  const [batchMovePending, setBatchMovePending] = useState(false);
  const [archivePending, setArchivePending] = useState(false);
  const [operationError, setOperationError] = useState('');
  const [notice, setNotice] = useState('');
  const currentEntries = listing.data?.entries ?? [];
  const selectedEntries = currentEntries.filter((entry) => selectedPaths.includes(entry.path));
  const allVisibleSelected = currentEntries.length > 0 && currentEntries.every((entry) => selectedPaths.includes(entry.path));
  const selectedHasLink = selectedEntries.some((entry) => entry.kind === 'link');

  useEffect(() => {
    setSelectedPaths([]);
  }, [path]);

  const refreshFiles = () => {
    void queryClient.invalidateQueries({ queryKey: getListServerFilesQueryKey(server.id) });
  };
  const fileError = (error: unknown, fallback: string) => {
    setOperationError(error instanceof Error ? error.message : fallback);
  };
  const joinPath = (base: string, name: string) => base ? `${base.replace(/\/+$/, '')}/${name}` : name;
  const openTextFile = (filePath: string) => {
    if (filePath === openPath) return;
    if (editorDirty && !window.confirm('Discard the unsaved changes to this file?')) return;
    setOpenPath(filePath);
    setEditorDirty(false);
    setOperationError('');
  };
  const closeTextFile = () => {
    if (editorDirty && !window.confirm('Discard the unsaved changes to this file?')) return;
    setOpenPath('');
    setEditorDirty(false);
  };
  const downloadBlob = (blob: Blob, fileName: string) => {
    if (!(blob instanceof Blob)) throw new Error('The server did not return a downloadable file.');
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = fileName;
    anchor.style.display = 'none';
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  };
  const startDownload = async (entry: ServerFileEntry) => {
    setOperationError('');
    try {
      const blob = await downloadServerFile(server.id, { path: entry.path }, { responseType: 'blob' });
      downloadBlob(blob, entry.name);
    } catch (error) { fileError(error, 'Could not download this file.'); }
  };
  const toggleSelected = (entryPath: string) => {
    setSelectedPaths((current) => current.includes(entryPath)
      ? current.filter((itemPath) => itemPath !== entryPath)
      : [...current, entryPath]);
  };
  const toggleAllVisible = () => {
    setSelectedPaths(allVisibleSelected ? [] : currentEntries.map((entry) => entry.path));
  };
  const cutSelected = () => {
    if (!selectedEntries.length) return;
    if (selectedHasLink) {
      setOperationError('Symbolic links cannot be moved.');
      return;
    }
    setCutPaths(selectedEntries.map((entry) => entry.path));
    setSelectedPaths([]);
    setOperationError('');
    setNotice(`${selectedEntries.length} item(s) cut. Open a destination folder, then choose Paste here.`);
  };
  const downloadSelectedArchive = async () => {
    const paths = selectedEntries.map((entry) => entry.path);
    if (!paths.length) return;
    setArchivePending(true);
    setOperationError('');
    try {
      const blob = await downloadServerFileArchive(server.id, { paths }, { responseType: 'blob' });
      downloadBlob(blob, 'selected-files.zip');
      setNotice(`${paths.length} selected item(s) added to the ZIP archive.`);
    } catch (error) {
      fileError(error, 'Could not create the ZIP archive.');
    } finally {
      setArchivePending(false);
    }
  };
  const submitCreate = (event: FormEvent) => {
    event.preventDefault();
    if (!createKind || !newName.trim()) return;
    setOperationError('');
    const fullPath = joinPath(listing.data?.currentPath ?? path, newName.trim());
    const options = { onSuccess: () => { setNewName(''); setCreateKind(''); refreshFiles(); }, onError: (error: unknown) => fileError(error, 'Could not create this item.') };
    if (createKind === 'folder') createDirectory.mutate({ id: server.id, data: { path: fullPath } }, options);
    else createFile.mutate({ id: server.id, data: { path: fullPath, content: '' } }, options);
  };
  const submitUrlDownload = (event: FormEvent) => {
    event.preventDefault();
    const url = downloadUrl.trim();
    if (!url) return;
    setOperationError(''); setNotice('');
    downloadFromUrl.mutate({ id: server.id, data: { url, directory: listing.data?.currentPath ?? path } }, {
      onSuccess: (entry) => { setNotice(`${entry.name} downloaded.`); setDownloadUrl(''); setUrlOpen(false); refreshFiles(); },
      onError: (error) => fileError(error, 'Could not download this URL.'),
    });
  };
  const runUnzip = (entry: ServerFileEntry) => {
    setOperationError(''); setNotice(''); setUnzipPath(entry.path);
    extractZip.mutate({ id: server.id, data: { path: entry.path } }, {
      onSuccess: (result) => { setNotice(`Extracted ${result.extractedFiles} file(s) into ${result.directory}.`); refreshFiles(); },
      onError: (error) => fileError(error, 'Could not extract this archive.'),
      onSettled: () => setUnzipPath(''),
    });
  };
  const submitRename = (event: FormEvent) => {
    event.preventDefault();
    if (!renameTarget) return;
    const newName = renameValue.trim();
    if (!newName || newName === '.' || newName === '..' || /[\\/\0]/.test(newName)) { setOperationError('Enter a valid name without slashes.'); return; }
    if (newName === renameTarget.name) { setRenameTarget(null); return; }
    const parent = renameTarget.path.split('/').slice(0, -1).join('/');
    const destination = joinPath(parent, newName);
    const source = renameTarget.path;
    setOperationError(''); setNotice('');
    moveFile.mutate({ id: server.id, data: { source, destination } }, {
      onSuccess: (result) => {
        if (openPath === source || openPath.startsWith(`${source}/`)) setOpenPath(`${result.destinationPath}${openPath.slice(source.length)}`);
        setNotice(`Renamed to ${newName}.`); setRenameTarget(null); refreshFiles();
      },
      onError: (error) => fileError(error, 'Could not rename this item.'),
    });
  };
  const submitChmod = (event: FormEvent) => {
    event.preventDefault();
    if (!chmodTarget) return;
    if (!/^[0-7]{3,4}$/.test(chmodMode)) { setOperationError('Permission mode must be 3 or 4 octal digits, for example 755.'); return; }
    setOperationError(''); setNotice('');
    setPermissions.mutate({ id: server.id, data: { path: chmodTarget.path, mode: chmodMode } }, {
      onSuccess: () => { setNotice(`Permissions of ${chmodTarget.name} set to ${chmodMode}.`); setChmodTarget(null); refreshFiles(); },
      onError: (error) => fileError(error, 'Could not change permissions.'),
    });
  };
  const uploadSelected = () => {
    if (!pendingUpload) return;
    setOperationError('');
    upload.mutate({ id: server.id, data: pendingUpload, params: { directory: listing.data?.currentPath ?? path } }, {
      onSuccess: () => { setNotice(`${pendingUpload.name} uploaded.`); setPendingUpload(null); refreshFiles(); },
      onError: (error) => fileError(error, 'Could not upload this file.'),
    });
  };
  const pasteCut = async () => {
    if (!cutPaths.length) return;
    setBatchMovePending(true);
    setOperationError('');
    setNotice('');
    const destinationDirectory = listing.data?.currentPath ?? path;
    const remaining: string[] = [];
    let movedCount = 0;
    let alreadyThereCount = 0;
    for (const source of cutPaths) {
      const name = source.split('/').filter(Boolean).at(-1) ?? source;
      const destination = joinPath(destinationDirectory, name);
      if (destination === source) {
        alreadyThereCount += 1;
        continue;
      }
      try {
        const result = await moveFile.mutateAsync({ id: server.id, data: { source, destination } });
        if (openPath === source || openPath.startsWith(`${source}/`)) {
          setOpenPath(`${result.destinationPath}${openPath.slice(source.length)}`);
        }
        movedCount += 1;
      } catch {
        remaining.push(source);
      }
    }
    setCutPaths(remaining);
    setBatchMovePending(false);
    if (movedCount > 0) refreshFiles();
    if (remaining.length) {
      setOperationError(`${remaining.length} item(s) could not be moved. They remain in the cut list.`);
    }
    if (movedCount > 0 || alreadyThereCount > 0) {
      setNotice(`${movedCount} item(s) moved${alreadyThereCount ? `; ${alreadyThereCount} already in this folder` : ''}.`);
    }
  };
  const deleteConfirm = async () => {
    if (!deleteTargets?.length) return;
    setBatchDeletePending(true);
    setOperationError('');
    const failed: ServerFileEntry[] = [];
    let deletedCount = 0;
    for (const target of deleteTargets) {
      try {
        await deleteFile.mutateAsync({ id: server.id, data: { path: target.path } });
        deletedCount += 1;
        if (openPath === target.path || openPath.startsWith(`${target.path}/`)) {
          setOpenPath('');
          setEditorDirty(false);
        }
      } catch {
        failed.push(target);
      }
    }
    setBatchDeletePending(false);
    setDeleteTargets(failed.length ? failed : null);
    setSelectedPaths((current) => current.filter((itemPath) => failed.some((target) => target.path === itemPath)));
    if (deletedCount > 0) {
      refreshFiles();
      setNotice(`${deletedCount} item(s) deleted.`);
    }
    if (failed.length) {
      setOperationError(`${failed.length} item(s) could not be deleted. You can retry the remaining items.`);
    }
  };
  const saveOpenFile = async (content: string): Promise<void> => {
    if (!openPath) return;
    await saveFile.mutateAsync({ id: server.id, data: { path: openPath, content } });
    setEditorDirty(false);
    void queryClient.invalidateQueries({ queryKey: getGetServerFileContentQueryKey(server.id, fileParams) });
    refreshFiles();
    setNotice('File saved.');
  };

  return <div className="space-y-4" data-testid="server-file-manager">
    <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-start">
      <div><p className="text-sm text-muted-foreground">Files in this server's own folder only.</p><div className="mono mt-2 flex flex-wrap items-center gap-1 break-all text-xs" data-testid="text-file-current-path"><span className="text-muted-foreground">{server.directory}</span>{listing.data?.currentPath && <><span className="text-muted-foreground">/</span><span>{listing.data.currentPath}</span></>}</div></div>
      {canEdit && <div className="flex flex-wrap gap-2">
        <Button variant="secondary" onClick={() => setCreateKind('folder')} testId="button-create-folder"><Folder className="size-4" />New folder</Button>
        <Button variant="secondary" onClick={() => setCreateKind('file')} testId="button-create-file"><FileIcon className="size-4" />New text file</Button>
        <label className="inline-flex h-10 cursor-pointer items-center justify-center gap-2 rounded-lg border bg-card px-3.5 text-sm font-bold hover:bg-muted" data-testid="label-upload-file"><Upload className="size-4" />Choose upload<input type="file" className="sr-only" data-testid="input-upload-file" onChange={(event) => setPendingUpload(event.target.files?.[0] ?? null)} /></label>
        <Button variant="secondary" onClick={() => setUrlOpen((value) => !value)} testId="button-download-from-url"><Link2 className="size-4" />Download from URL</Button>
      </div>}
    </div>
    {pendingUpload && <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-primary/20 bg-primary/5 px-4 py-3" data-testid="upload-pending"><span className="min-w-0 truncate text-sm">{pendingUpload.name} <span className="text-muted-foreground">· {(pendingUpload.size / 1024).toFixed(1)} KB</span></span><div className="flex gap-2"><Button onClick={uploadSelected} disabled={upload.isPending} testId="button-confirm-upload">{upload.isPending ? <LoaderCircle className="size-4 animate-spin" /> : <Upload className="size-4" />}Upload</Button><Button variant="ghost" onClick={() => setPendingUpload(null)} testId="button-cancel-upload">Cancel</Button></div></div>}
    {urlOpen && <form onSubmit={submitUrlDownload} className="flex flex-col gap-3 rounded-lg border bg-muted/40 p-4 sm:flex-row sm:items-end" data-testid="form-download-url"><div className="min-w-0 flex-1"><TextField name="file-manager-download-url" label="File URL" value={downloadUrl} onChange={setDownloadUrl} placeholder="https://example.com/server.zip" hint="Saved into the folder you are viewing" required /></div><div className="flex gap-2"><Button type="submit" disabled={downloadFromUrl.isPending || !downloadUrl.trim()} testId="button-submit-download-url">{downloadFromUrl.isPending ? <LoaderCircle className="size-4 animate-spin" /> : <Download className="size-4" />}{downloadFromUrl.isPending ? 'Downloading…' : 'Download'}</Button><Button variant="secondary" onClick={() => { setUrlOpen(false); setDownloadUrl(''); }} disabled={downloadFromUrl.isPending} testId="button-cancel-download-url">Cancel</Button></div></form>}
    {renameTarget && <form onSubmit={submitRename} className="flex flex-col gap-3 rounded-lg border bg-muted/40 p-4 sm:flex-row sm:items-end" data-testid="form-rename"><div className="min-w-0 flex-1"><TextField name="file-manager-rename" label={`Rename · ${renameTarget.name}`} value={renameValue} onChange={setRenameValue} placeholder="new-name" required /></div><div className="flex gap-2"><Button type="submit" disabled={moveFile.isPending || !renameValue.trim()} testId="button-submit-rename">{moveFile.isPending ? <LoaderCircle className="size-4 animate-spin" /> : <Save className="size-4" />}Rename</Button><Button variant="secondary" onClick={() => setRenameTarget(null)} testId="button-cancel-rename">Cancel</Button></div></form>}
    {chmodTarget && <form onSubmit={submitChmod} className="flex flex-col gap-3 rounded-lg border bg-muted/40 p-4 sm:flex-row sm:items-end" data-testid="form-chmod"><div className="min-w-0 flex-1"><TextField name="file-manager-chmod-mode" label={`chmod · ${chmodTarget.name}`} value={chmodMode} onChange={setChmodMode} placeholder="755" hint="Octal, e.g. 755 (executable) or 644" required /></div><div className="flex flex-wrap gap-2">{['755', '644', '777'].map((preset) => <Button key={preset} variant="ghost" onClick={() => setChmodMode(preset)} testId={`button-chmod-preset-${preset}`}>{preset}</Button>)}<Button type="submit" disabled={setPermissions.isPending} testId="button-submit-chmod">{setPermissions.isPending ? <LoaderCircle className="size-4 animate-spin" /> : <Lock className="size-4" />}Apply</Button><Button variant="secondary" onClick={() => setChmodTarget(null)} testId="button-cancel-chmod">Cancel</Button></div></form>}
    {createKind && <form onSubmit={submitCreate} className="flex flex-col gap-3 rounded-lg border bg-muted/40 p-4 sm:flex-row sm:items-end" data-testid={`form-create-${createKind}`}><TextField name="file-manager-new-name" label={createKind === 'folder' ? 'Folder name' : 'File name'} value={newName} onChange={setNewName} placeholder={createKind === 'folder' ? 'config' : 'README.txt'} required /><div className="flex gap-2"><Button type="submit" disabled={createDirectory.isPending || createFile.isPending} testId="button-submit-create-item"><Save className="size-4" />Create</Button><Button variant="secondary" onClick={() => { setCreateKind(''); setNewName(''); }} testId="button-cancel-create-item">Cancel</Button></div></form>}
    {selectedEntries.length > 0 && <div className="flex flex-col gap-3 rounded-lg border border-primary/20 bg-primary/5 p-3 sm:flex-row sm:items-center sm:justify-between" data-testid="file-selection-toolbar">
      <div className="text-sm font-semibold">{selectedEntries.length} selected{selectedHasLink && <p className="mt-1 text-xs font-normal text-muted-foreground">Links cannot be moved or added to ZIP archives.</p>}</div>
      <div className="flex flex-wrap gap-2">
        {canEdit && <Button variant="secondary" onClick={cutSelected} disabled={selectedHasLink || batchMovePending} testId="button-cut-selected"><ScissorsIcon />Cut selected</Button>}
        {canEdit && <Button variant="secondary" onClick={() => setDeleteTargets([...selectedEntries])} disabled={batchDeletePending} testId="button-delete-selected"><Trash2 className="size-4" />Delete selected</Button>}
        <Button onClick={() => void downloadSelectedArchive()} disabled={selectedHasLink || archivePending} testId="button-archive-selected">{archivePending ? <LoaderCircle className="size-4 animate-spin" /> : <Archive className="size-4" />}Create ZIP</Button>
        <Button variant="ghost" onClick={() => setSelectedPaths([])} testId="button-clear-file-selection">Clear</Button>
      </div>
    </div>}
    {cutPaths.length > 0 && <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900" data-testid="file-cut-selection"><span className="truncate">Cut {cutPaths.length} item(s): <span className="mono text-xs">{cutPaths.slice(0, 3).map((itemPath) => itemPath.split('/').filter(Boolean).at(-1) ?? itemPath).join(', ')}{cutPaths.length > 3 ? '…' : ''}</span></span><div className="flex gap-2"><Button variant="secondary" onClick={() => void pasteCut()} disabled={batchMovePending || moveFile.isPending} testId="button-paste-file">{batchMovePending || moveFile.isPending ? <LoaderCircle className="size-4 animate-spin" /> : <FolderOpen className="size-4" />}Paste here</Button><Button variant="ghost" onClick={() => setCutPaths([])} disabled={batchMovePending} testId="button-cancel-cut">Cancel</Button></div></div>}
    {operationError && <p className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700" data-testid="text-file-error">{operationError}</p>}
    {notice && <p className="rounded-lg border border-teal-200 bg-teal-50 px-4 py-3 text-sm text-teal-800" data-testid="text-file-notice">{notice}</p>}
    <div className="overflow-hidden rounded-xl border bg-card">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b px-4 py-3 sm:px-5"><div className="flex min-w-0 items-center gap-2 text-sm"><FolderOpen className="size-4 shrink-0 text-primary" /><span className="truncate font-semibold">{server.directory}{listing.data?.currentPath ? `/${listing.data.currentPath}` : ''}</span></div><div className="flex items-center gap-1"><Button variant="ghost" onClick={toggleAllVisible} disabled={!currentEntries.length} testId="button-select-all-files">{allVisibleSelected ? 'Clear selection' : 'Select all'}</Button><Button variant="ghost" onClick={() => listing.refetch()} disabled={listing.isFetching} testId="button-refresh-files"><RefreshCw className={`size-4 ${listing.isFetching ? 'animate-spin' : ''}`} />Refresh</Button></div></div>
      {listing.isLoading ? <div className="space-y-3 p-5" data-testid="state-files-loading"><div className="skeleton h-10 rounded-lg" /><div className="skeleton h-10 rounded-lg" /><div className="skeleton h-10 rounded-lg" /></div>
        : listing.isError || !listing.data ? <div className="p-5"><ErrorNotice onRetry={() => listing.refetch()} /></div>
          : <><div className="flex items-center gap-2 border-b bg-muted/30 px-4 py-2.5 text-xs text-muted-foreground sm:px-5"><button onClick={() => setPath('')} disabled={!listing.data.currentPath} className="font-bold text-primary hover:underline disabled:text-muted-foreground disabled:no-underline" data-testid="button-file-root">Directory root</button>{listing.data.currentPath && <><ChevronRight className="size-3" /><span className="truncate mono" data-testid="text-file-breadcrumb">{listing.data.currentPath}</span></>}{listing.data.currentPath && listing.data.parentPath !== null && <button onClick={() => setPath(listing.data?.parentPath ?? '')} className="ml-auto font-semibold text-primary hover:underline" data-testid="button-file-parent">Up one level</button>}</div>
            {listing.data.entries.length ? <div className="divide-y">{listing.data.entries.map((entry) => <div key={entry.path} className={`group flex min-w-0 items-center gap-3 px-4 py-3 sm:px-5 ${selectedPaths.includes(entry.path) ? 'bg-primary/5' : cutPaths.includes(entry.path) ? 'bg-amber-50/70' : ''}`} data-testid={`row-file-${entry.name}`}>
              <input type="checkbox" checked={selectedPaths.includes(entry.path)} onChange={() => toggleSelected(entry.path)} aria-label={`Select ${entry.name}`} className="size-4 shrink-0 accent-primary" data-testid={`checkbox-select-file-${entry.name}`} />
              <span className={`grid size-9 shrink-0 place-items-center rounded-lg ${entry.kind === 'directory' ? 'bg-amber-50 text-amber-700' : entry.kind === 'link' ? 'bg-muted text-muted-foreground' : 'bg-teal-50 text-primary'}`}>{entry.kind === 'directory' ? <Folder className="size-4" /> : <FileIcon className="size-4" />}</span>
              <div className="min-w-0 flex-1">{entry.kind === 'directory' ? <button onClick={() => setPath(entry.path)} className="max-w-full truncate text-left text-sm font-bold hover:text-primary" data-testid={`button-open-folder-${entry.name}`}>{entry.name}</button> : entry.kind === 'file' ? <button onClick={() => openTextFile(entry.path)} className="max-w-full truncate text-left text-sm font-bold hover:text-primary" data-testid={`button-open-file-${entry.name}`}>{entry.name}</button> : <p className="truncate text-sm font-bold" data-testid={`text-file-name-${entry.name}`}>{entry.name}<span className="ml-2 text-[10px] font-semibold uppercase text-muted-foreground">Link</span></p>}<p className="mt-0.5 text-[11px] text-muted-foreground" data-testid={`text-file-meta-${entry.name}`}>{entry.kind === 'directory' ? 'Folder' : `${(entry.size / 1024).toFixed(1)} KB`} · {formatTime(entry.modifiedAt)} · <span className="mono">{entry.mode}</span></p></div>
              <DropdownMenu><DropdownMenuTrigger asChild><button className="grid size-9 shrink-0 place-items-center rounded-md text-muted-foreground hover:bg-muted hover:text-foreground" aria-label={`Actions for ${entry.name}`} data-testid={`button-actions-${entry.name}`}><MoreVertical className="size-5" /></button></DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  {entry.kind === 'file' && <DropdownMenuItem onSelect={() => void startDownload(entry)} data-testid={`button-download-${entry.name}`}><Download className="mr-2 size-4" />Download</DropdownMenuItem>}
                  {canEdit && entry.kind === 'file' && /\.zip$/i.test(entry.name) && <DropdownMenuItem disabled={extractZip.isPending} onSelect={() => runUnzip(entry)} data-testid={`button-unzip-${entry.name}`}><FileArchive className="mr-2 size-4" />Unzip here</DropdownMenuItem>}
                  {canEdit && entry.kind !== 'link' && <DropdownMenuItem onSelect={() => { setRenameTarget(entry); setRenameValue(entry.name); setChmodTarget(null); setOperationError(''); setNotice(''); }} data-testid={`button-rename-${entry.name}`}><Pencil className="mr-2 size-4" />Rename</DropdownMenuItem>}
                  {canEdit && entry.kind !== 'link' && <DropdownMenuItem onSelect={() => { setChmodTarget(entry); setChmodMode(entry.mode); setRenameTarget(null); setOperationError(''); setNotice(''); }} data-testid={`button-chmod-${entry.name}`}><Lock className="mr-2 size-4" />Permissions (chmod)</DropdownMenuItem>}
                  {canEdit && entry.kind !== 'link' && <DropdownMenuItem onSelect={() => { setCutPaths([entry.path]); setNotice(''); }} data-testid={`button-cut-${entry.name}`}><ScissorsIcon /><span className="ml-2">Cut</span></DropdownMenuItem>}
                  {canEdit && <DropdownMenuSeparator />}
                  {canEdit && <DropdownMenuItem onSelect={() => setDeleteTargets([entry])} className="text-red-700 focus:bg-red-50 focus:text-red-700" data-testid={`button-delete-file-${entry.name}`}><Trash2 className="mr-2 size-4" />Delete</DropdownMenuItem>}
                </DropdownMenuContent></DropdownMenu>
            </div>)}</div> : <div className="grid min-h-40 place-items-center p-7 text-center" data-testid="empty-server-files"><div><FolderOpen className="mx-auto size-7 text-primary/60" /><p className="mt-3 text-sm font-semibold">This directory is empty</p><p className="mt-1 text-xs text-muted-foreground">Create a folder or file, or upload files here.</p></div></div>}
            {listing.data.truncated && <p className="border-t bg-amber-50/70 px-5 py-3 text-xs text-amber-800" data-testid="text-files-truncated">Showing a partial listing. Refine the directory to see more entries.</p>}
          </>}
    </div>
    {openPath && <Suspense fallback={createPortal(<div className="fixed inset-0 z-[90] grid place-items-center bg-[#21252b] text-slate-300"><LoaderCircle className="size-6 animate-spin" /></div>, document.body)}><CodeEditorDialog key={openPath} readOnly={!canEdit} path={openPath} loading={fileQuery.isLoading} loadError={fileQuery.isError} onRetry={() => void fileQuery.refetch()} initialContent={fileQuery.data && fileQuery.data.path === openPath ? fileQuery.data.content : null} saving={saveFile.isPending} onSave={saveOpenFile} onDirtyChange={setEditorDirty} onClose={closeTextFile} /></Suspense>}
    {deleteTargets && createPortal(<div className="fixed inset-0 z-[100] grid place-items-center bg-sidebar/45 p-4 backdrop-blur-sm" role="dialog" aria-modal="true" aria-labelledby="file-delete-title" data-testid="dialog-delete-file"><div className="max-h-[calc(100dvh-2rem)] w-full max-w-lg overflow-y-auto rounded-2xl border bg-card p-6 shadow-2xl"><span className="grid size-11 place-items-center rounded-xl bg-red-50 text-red-700"><Trash2 className="size-5" /></span><h3 id="file-delete-title" className="mt-5 text-xl font-bold">{deleteTargets.length === 1 ? `Delete ${deleteTargets[0].name}?` : `Delete ${deleteTargets.length} items?`}</h3><p className="mt-2 text-sm leading-6 text-muted-foreground">This permanently deletes the selected {deleteTargets.some((entry) => entry.kind === 'directory') ? 'files and folders, including folder contents' : 'files'} from this process directory.</p>{deleteTargets.length > 1 && <ul className="mt-3 max-h-32 overflow-y-auto rounded-lg border bg-muted/30 p-3 text-sm">{deleteTargets.slice(0, 8).map((entry) => <li key={entry.path} className="truncate py-0.5">{entry.name}</li>)}{deleteTargets.length > 8 && <li className="pt-1 text-xs text-muted-foreground">and {deleteTargets.length - 8} more…</li>}</ul>}{operationError && <p className="mt-3 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">{operationError}</p>}<div className="mt-6 flex flex-wrap justify-end gap-3"><Button variant="secondary" onClick={() => { setDeleteTargets(null); setOperationError(''); }} disabled={batchDeletePending} testId="button-cancel-delete-file">Cancel</Button><Button variant="danger" onClick={() => void deleteConfirm()} disabled={batchDeletePending || deleteFile.isPending} testId="button-confirm-delete-file">{batchDeletePending || deleteFile.isPending ? <LoaderCircle className="size-4 animate-spin" /> : <Trash2 className="size-4" />}{deleteTargets.length === 1 ? 'Delete' : `Delete ${deleteTargets.length} items`}</Button></div></div></div>, document.body)}
  </div>;
}

function ScissorsIcon() {
  return <Scissors className="size-4" />;
}

function StartupCard({ icon: Icon, title, description, enabled, delaySeconds, delayLabel, pending, testPrefix, onToggle, onSaveDelay }: {
  icon: typeof Clock3; title: string; description: string; enabled: boolean; delaySeconds: number; delayLabel: string; pending: boolean; testPrefix: string;
  onToggle: (enabled: boolean) => void; onSaveDelay: (seconds: number) => void;
}) {
  const [draft, setDraft] = useState(String(delaySeconds));
  useEffect(() => { setDraft(String(delaySeconds)); }, [delaySeconds]);
  const parsed = Number(draft);
  const valid = draft.trim() !== '' && Number.isInteger(parsed) && parsed >= 0 && parsed <= 86400;
  const dirty = valid && parsed !== delaySeconds;
  return <div className="flex items-start gap-4 rounded-xl border bg-muted/25 p-5" data-testid={`card-${testPrefix}`}>
    <span className="grid size-10 shrink-0 place-items-center rounded-lg bg-teal-50 text-primary"><Icon className="size-5" /></span>
    <div className="min-w-0 flex-1">
      <h4 className="font-bold">{title}</h4>
      <p className="mt-1 text-sm leading-6 text-muted-foreground">{description}</p>
      <div className="mt-4 flex flex-wrap items-center justify-between gap-4 rounded-lg border bg-card px-4 py-3">
        <div><p className="text-sm font-semibold" data-testid={`text-${testPrefix}-value`}>{enabled ? 'Enabled' : 'Disabled'}</p><p className="mt-0.5 text-xs text-muted-foreground">Per-process configuration</p></div>
        <button type="button" role="switch" aria-label={`Toggle ${title}`} aria-checked={enabled} disabled={pending} onClick={() => onToggle(!enabled)} className={`relative h-7 w-12 rounded-full transition ${enabled ? 'bg-primary' : 'bg-muted-foreground/35'} disabled:opacity-50`} data-testid={`switch-server-${testPrefix}`}><span className={`absolute left-1 top-1 size-5 rounded-full bg-card shadow-sm transition-transform ${enabled ? 'translate-x-5' : 'translate-x-0'}`} /></button>
      </div>
      <div className="mt-3 flex flex-wrap items-end gap-3">
        <label className="block text-sm font-semibold">{delayLabel}<input type="number" min={0} max={86400} step={1} value={draft} onChange={(event) => setDraft(event.target.value)} className="mono mt-1.5 block h-10 w-36 rounded-lg border bg-card px-3 text-sm outline-none focus:border-primary" data-testid={`input-${testPrefix}-delay`} /></label>
        <Button variant="secondary" onClick={() => onSaveDelay(parsed)} disabled={!dirty || pending} testId={`button-save-${testPrefix}-delay`}><Save className="size-4" />Save delay</Button>
        {!valid && <p className="text-xs text-red-700">Enter a whole number between 0 and 86400.</p>}
      </div>
    </div>
  </div>;
}

function ServerDetailPage() {
  const params = useParams<{ id: string }>();
  const id = Number(params.id);
  const { can, isAdmin } = useAccess();
  const server = useGetServer(id, { query: { enabled: Number.isFinite(id), queryKey: getGetServerQueryKey(id) } });
  const logs = useGetServerLogs(id, { limit: 180 }, { query: { enabled: Number.isFinite(id) && can('console_view'), queryKey: getGetServerLogsQueryKey(id, { limit: 180 }), refetchInterval: (server.data?.logRefreshIntervalSeconds ?? 10) * 1000 } });
  const [, setLocation] = useLocation();
  const [editing, setEditing] = useState(false);
  const [settingsTab, setSettingsTab] = useState<'definition' | 'files' | 'autostart' | 'schedule'>('definition');
  const [deleteOpen, setDeleteOpen] = useState(false);
  const start = useStartServer();
  const stop = useStopServer();
  const restart = useRestartServer();
  const kill = useKillServer();
  const remove = useDeleteServer();
  const update = useUpdateServer();
  const saveStartup = (data: { autoStart?: boolean; autoStartDelaySeconds?: number; crashStart?: boolean; crashStartDelaySeconds?: number }) => {
    update.mutate({ id, data }, { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getGetServerQueryKey(id) }); queryClient.invalidateQueries({ queryKey: getGetServersQueryKey() }); queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() }); } });
  };
  const invalidate = () => { queryClient.invalidateQueries({ queryKey: getGetServerQueryKey(id) }); queryClient.invalidateQueries({ queryKey: getGetServerLogsQueryKey(id, { limit: 180 }) }); queryClient.invalidateQueries({ queryKey: getGetServersQueryKey() }); queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() }); };
  const action = (kind: 'start' | 'stop' | 'restart' | 'kill') => {
    const mutation = kind === 'start' ? start : kind === 'stop' ? stop : kind === 'kill' ? kill : restart;
    mutation.mutate({ id }, { onSuccess: invalidate, onError: invalidate });
  };
  if (server.isLoading) return <LoadingState label="Loading server details" />;
  if (server.isError || !server.data) return <ErrorNotice onRetry={() => server.refetch()} />;
  const item = server.data;
  // The settings sections a limited user may open follow the permissions an administrator granted.
  const tabOptions = ([['definition', 'Process definition', 'settings'], ['files', 'Files', 'files_view'], ['autostart', 'Auto-start & Crash-start', 'startup'], ['schedule', 'Schedule', 'schedules']] as const).filter(([, , permission]) => can(permission));
  const activeTab = tabOptions.some(([key]) => key === settingsTab) ? settingsTab : tabOptions[0]?.[0];
  return <div className="space-y-6 animate-rise">
    <Link href="/servers" className="inline-flex items-center gap-2 text-xs font-bold text-muted-foreground hover:text-primary" data-testid="link-back-servers"><ArrowLeft className="size-4" />Back to servers</Link>
    <div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-start">
      <div className="flex min-w-0 items-center gap-4"><ServerMark name={item.name} size="lg" /><div className="min-w-0"><div className="flex flex-wrap items-center gap-3"><h2 className="min-w-0 break-words text-2xl font-bold tracking-tight">{item.name}</h2><StatusBadge status={item.status} /></div><p className="mt-1 break-words text-sm text-muted-foreground">{item.description || 'No description provided'}</p></div></div>
      <div className="grid grid-cols-2 gap-2 sm:flex sm:flex-wrap">
        {item.status === 'online' ? <>
          {can('power') && <Button variant="secondary" onClick={() => action('stop')} disabled={stop.isPending || kill.isPending} testId="button-detail-stop"><Square className="size-4" />Stop</Button>}
          {can('kill') && <Button variant="danger" onClick={() => action('kill')} disabled={kill.isPending || stop.isPending} testId="button-detail-kill">{kill.isPending ? <LoaderCircle className="size-4 animate-spin" /> : <X className="size-4" />}Kill</Button>}
        </> : can('power') ? <Button onClick={() => action('start')} disabled={start.isPending} testId="button-detail-start"><Play className="size-4 fill-current" />Start</Button> : null}
        {can('power') && <Button variant="secondary" onClick={() => action('restart')} disabled={restart.isPending || kill.isPending || stop.isPending} testId="button-detail-restart"><RotateCw className="size-4" />Restart</Button>}
         {tabOptions.length > 0 && <Button variant="secondary" onClick={() => setEditing((value) => !value)} testId="button-server-settings"><Settings className="size-4" />{editing ? 'Close settings' : 'Settings'}</Button>}
      </div>
    </div>
     {editing && tabOptions.length > 0 && <section className="overflow-hidden rounded-xl border bg-card shadow-[0_2px_10px_hsl(218_36%_18%/.035)]" data-testid="server-settings-surface"><div className="border-b bg-muted/25 px-4 py-5 sm:px-6"><div className="flex items-start justify-between gap-4"><div><p className="mono text-[10px] uppercase tracking-[.16em] text-primary">Process settings</p><h3 className="mt-2 text-xl font-bold tracking-tight">Settings for {item.name}</h3><p className="mt-1 text-sm text-muted-foreground">Definition, files, startup behavior and scheduled tasks for this process.</p></div><button onClick={() => setEditing(false)} className="rounded-lg p-2 text-muted-foreground hover:bg-muted" aria-label="Close settings" data-testid="button-close-settings"><X className="size-4" /></button></div>
       <div className="mt-5 flex gap-1 overflow-x-auto" role="tablist" aria-label="Process settings sections">{tabOptions.map(([key, label]) => <button key={key} role="tab" aria-selected={activeTab === key} onClick={() => setSettingsTab(key)} className={`whitespace-nowrap rounded-lg px-3.5 py-2 text-sm font-bold transition ${activeTab === key ? 'bg-primary text-primary-foreground shadow-sm' : 'text-muted-foreground hover:bg-muted hover:text-foreground'}`} data-testid={`tab-server-settings-${key}`}>{label}</button>)}</div>
     </div><div className="p-4 sm:p-6">
       {activeTab === 'definition' && <div><div className="mb-5"><h4 className="font-bold">Edit process definition</h4><p className="mt-1 text-xs text-muted-foreground">Changes apply to the next time this process starts.</p></div><ServerForm initial={item} onDone={() => setEditing(false)} onCancel={() => setEditing(false)} /></div>}
       {activeTab === 'files' && <ServerFiles server={item} />}
       {activeTab === 'autostart' && <div className="max-w-2xl space-y-4" data-testid="panel-server-autostart">
         <StartupCard icon={Clock3} title="Start with Nodewatch" testPrefix="autostart" enabled={item.autoStart} delaySeconds={item.autoStartDelaySeconds} pending={update.isPending}
           description="When enabled, Nodewatch starts this process automatically after the API process starts, once the delay below has passed."
           delayLabel="Start delay (seconds)"
           onToggle={(enabled) => saveStartup({ autoStart: enabled })} onSaveDelay={(seconds) => saveStartup({ autoStartDelaySeconds: seconds })} />
         <StartupCard icon={RotateCw} title="Crash-start" testPrefix="crashstart" enabled={item.crashStart} delaySeconds={item.crashStartDelaySeconds} pending={update.isPending}
           description="When enabled, this process is started again automatically if it crashes or stops unexpectedly. Stopping it yourself from the panel does not trigger a restart. Retries pause after 5 failed attempts within 10 minutes."
           delayLabel="Restart delay (seconds)"
           onToggle={(enabled) => saveStartup({ crashStart: enabled })} onSaveDelay={(seconds) => saveStartup({ crashStartDelaySeconds: seconds })} />
         {update.isPending && <p className="flex items-center gap-2 text-xs text-muted-foreground" data-testid="text-autostart-saving"><LoaderCircle className="size-3 animate-spin" />Saving preference</p>}
       </div>}
       {activeTab === 'schedule' && <SchedulePanel server={item} />}
       {activeTab === 'autostart' && update.isError && <p className="mt-4 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700" data-testid="text-autostart-error">Startup settings could not be updated. Try again.</p>}
     </div></section>}
    <div className="grid grid-cols-1 gap-6 xl:grid-cols-[.92fr_1.45fr]">
      <section className="min-w-0 space-y-6">
        <div className="rounded-xl border bg-card p-5 shadow-[0_2px_10px_hsl(218_36%_18%/.035)] sm:p-6"><div className="flex items-center justify-between"><h3 className="font-bold">Process snapshot</h3><ActivityIcon className="size-4 text-muted-foreground" /></div><div className="mt-5 grid grid-cols-2 gap-x-5 gap-y-5">{[['PID', item.pid ? String(item.pid) : '—'], ['Port', item.port ? String(item.port) : '—'], ['Uptime', item.status === 'online' ? formatDuration(item.uptimeSeconds) : '—'], ['Last started', formatTime(item.lastStartedAt)]].map(([label, value]) => <div key={label}><p className="text-xs text-muted-foreground">{label}</p><p className="mono mt-1 truncate text-sm font-bold">{value}</p></div>)}</div></div>
        <div className="rounded-xl border bg-card p-5 shadow-[0_2px_10px_hsl(218_36%_18%/.035)] sm:p-6"><h3 className="font-bold">Process definition</h3><div className="mt-5 space-y-4"><InfoLine icon={FolderOpen} label="Server folder" value={item.directory} mono /><InfoLine icon={Terminal} label="Start command" value={item.command} mono /><InfoLine icon={Clock3} label="Updated" value={formatTime(item.updatedAt)} /></div></div>
        {isAdmin && <Button variant="danger" className="w-full" onClick={() => setDeleteOpen(true)} testId="button-delete-server"><Trash2 className="size-4" />Delete server</Button>}
      </section>
      {can('console_view') && <TerminalPanel server={item} logs={logs} canSend={can('console_send')} canClear={can('console_send')} canConfigure={can('settings')} />}
    </div>
    {deleteOpen && isAdmin && <ConfirmDelete server={item} onCancel={() => setDeleteOpen(false)} pending={remove.isPending} onConfirm={() => remove.mutate({ id }, { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getGetServersQueryKey() }); queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() }); setLocation('/servers'); } })} />}
  </div>;
}

function InfoLine({ icon: Icon, label, value, mono = false }: { icon: typeof FolderOpen; label: string; value: string; mono?: boolean }) {
  return <div className="flex gap-3"><Icon className="mt-0.5 size-4 shrink-0 text-muted-foreground" /><div className="min-w-0"><p className="text-xs text-muted-foreground">{label}</p><p className={`mt-1 truncate text-sm ${mono ? 'mono text-[11px]' : 'font-medium'}`}>{value}</p></div></div>;
}

function SettingsPage({ admin }: { admin: Admin }) {
  const logout = useLogout();
  const [, setLocation] = useLocation();
  const [notice, setNotice] = useState('');
  const signOut = () => logout.mutate(undefined, { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getGetCurrentAdminQueryKey() }); setLocation('/'); } });
  return <div className="max-w-3xl space-y-7 animate-rise"><div><p className="text-sm text-muted-foreground">Identity, access, and this session.</p><h2 className="mt-1 text-2xl font-bold tracking-tight">Settings</h2></div><section className="overflow-hidden rounded-xl border bg-card shadow-[0_2px_10px_hsl(218_36%_18%/.035)]"><div className="border-b px-5 py-4 sm:px-6"><div className="flex items-center gap-3"><span className="grid size-9 place-items-center rounded-lg bg-teal-50 text-primary"><UserCircle className="size-5" /></span><div><h3 className="font-bold">Administrator profile</h3><p className="mt-1 text-xs text-muted-foreground">The account currently holding this session</p></div></div></div><div className="grid gap-5 p-5 sm:grid-cols-2 sm:p-6"><InfoLine icon={UserCircle} label="Display name" value={admin.displayName} /><InfoLine icon={KeyRound} label="Username" value={`@${admin.username}`} /><InfoLine icon={Clock3} label="Account created" value={formatTime(admin.createdAt)} /><InfoLine icon={ShieldCheck} label="Access level" value="Administrator" /></div></section><UsersPanel /><section className="rounded-xl border bg-card p-5 shadow-[0_2px_10px_hsl(218_36%_18%/.035)] sm:p-6"><div className="flex items-start gap-4"><span className="grid size-9 place-items-center rounded-lg bg-muted text-muted-foreground"><CircleHelp className="size-5" /></span><div><h3 className="font-bold">About nodewatch</h3><p className="mt-1 text-sm leading-6 text-muted-foreground">A local operations cockpit for Node.js processes. Server commands execute on the host running the API server.</p><p className="mono mt-4 text-[11px] text-muted-foreground">Session status · <span className="text-primary">authenticated</span></p></div></div></section>{notice && <p className="rounded-lg border border-teal-200 bg-teal-50 px-4 py-3 text-sm text-teal-800" data-testid="text-settings-notice">{notice}</p>}<Button variant="danger" onClick={signOut} disabled={logout.isPending} testId="button-settings-logout"><LogOut className="size-4" />Sign out of this session</Button></div>;
}

function BootScreen() {
  return <div className="grid min-h-[100dvh] place-items-center bg-background"><div className="text-center"><span className="mx-auto grid size-12 place-items-center rounded-2xl bg-primary text-primary-foreground"><Zap className="size-6" /></span><p className="mt-5 text-sm font-bold">Connecting to nodewatch</p><p className="mt-2 text-xs text-muted-foreground">Checking instance status…</p><div className="mx-auto mt-5 h-1 w-32 overflow-hidden rounded-full bg-muted"><div className="h-full w-1/2 animate-pulse-line rounded-full bg-primary" /></div></div></div>;
}

function Router() {
  const [location, setLocation] = useLocation();
  const setup = useGetSetupStatus();
  const authEnabled = setup.data?.needsSetup === false;
  const admin = useGetCurrentAdmin({ query: { enabled: authEnabled, queryKey: getGetCurrentAdminQueryKey() } });
  const access = useAccess(authEnabled);
  const isUser = access.isUser;
  useEffect(() => { if (location === '/' && admin.data && access.access) setLocation(access.isUser ? '/servers' : '/dashboard'); }, [location, admin.data, access.access, access.isUser, setLocation]);
  if (setup.isLoading || (authEnabled && admin.isLoading)) return <BootScreen />;
  if (setup.isError) return <div className="mx-auto flex min-h-[100dvh] max-w-lg items-center p-6"><ErrorNotice onRetry={() => setup.refetch()} /></div>;
  if (setup.data?.needsSetup) return <SetupScreen />;
  if (admin.isError || !admin.data) return <LoginScreen />;
  if (access.isError) return <div className="mx-auto flex min-h-[100dvh] max-w-lg items-center p-6"><ErrorNotice onRetry={() => access.refetch()} /></div>;
  if (access.isLoading || !access.access) return <BootScreen />;
  if (location === '/') return <BootScreen />;
  // Limited users only get the Servers pages; everything else sends them back to Servers.
  if (isUser) return <AppShell admin={admin.data}><Switch><Route path="/servers" component={ServersPage} /><Route path="/servers/:id" component={ServerDetailPage} />{access.can('scripts') && <Route path="/scripts" component={ScriptsPage} />}<Route><Redirect to="/servers" /></Route></Switch></AppShell>;
  return <AppShell admin={admin.data}><Switch><Route path="/dashboard" component={DashboardPage} /><Route path="/servers" component={ServersPage} /><Route path="/scripts" component={ScriptsPage} /><Route path="/console" component={ConsolePage} /><Route path="/servers/:id" component={ServerDetailPage} /><Route path="/settings" component={() => <SettingsPage admin={admin.data as Admin} />} /><Route component={NotFound} /></Switch></AppShell>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><ErrorBoundary resetKey={window.location.pathname}><Router /></ErrorBoundary></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;