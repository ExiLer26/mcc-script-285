import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { Link } from 'wouter';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  ArrowDown, ArrowUp, Check, CircleDashed, Copy, Download, FileArchive, FilePlus2, FolderInput, FolderPlus, LayoutTemplate, Lock, LoaderCircle,
  MoveRight, Pencil, Play, Plus, ScrollText, SkipForward, Terminal as TerminalIcon, Trash2, Upload, Wand2, X, XCircle,
} from 'lucide-react';
import { customFetch, useGetServers } from '@workspace/api-client-react';
import { useAccess } from './access';

/* ------------------------------------------------------------------ */
/* Types and step definitions                                          */
/* ------------------------------------------------------------------ */

type StepType = 'download' | 'unzip' | 'chmod' | 'mkdir' | 'writeFile' | 'delete' | 'move' | 'moveContents' | 'command' | 'setStartCommand';

type Step = {
  type: StepType;
  ignoreErrors?: boolean;
  url?: string; directory?: string; fileName?: string; path?: string; deleteArchive?: boolean;
  overwrite?: boolean; removeEmptyFolder?: boolean;
  mode?: string; content?: string; from?: string; to?: string; command?: string; timeoutSeconds?: number | string;
};

type Variable = { key: string; label: string; defaultValue: string; group?: string[] };

type Script = {
  id: number; name: string; description: string; variables: Variable[]; steps: Step[];
  runCount: number; createdAt: string; updatedAt: string;
};

type ScriptDraft = { name: string; description: string; variables: Variable[]; steps: Step[] };

type FieldDef = { key: keyof Step; label: string; placeholder?: string; kind?: 'text' | 'textarea' | 'number' | 'checkbox'; mono?: boolean };

const STEP_DEFS: Record<StepType, { label: string; hint: string; icon: typeof Download; fields: FieldDef[]; initial: Partial<Step> }> = {
  download: { label: 'Download file', hint: 'Downloads a file from a URL into the server folder.', icon: Download, initial: {}, fields: [
    { key: 'url', label: 'File URL', placeholder: 'https://example.com/app.zip', mono: true },
    { key: 'directory', label: 'Save into folder (optional)', placeholder: 'leave empty for the server folder', mono: true },
    { key: 'fileName', label: 'Save as (optional)', placeholder: 'e.g. server.jar', mono: true },
  ] },
  unzip: { label: 'Unzip archive', hint: 'Extracts a .zip next to itself, without creating an extra folder.', icon: FileArchive, initial: {}, fields: [
    { key: 'path', label: 'ZIP file path', placeholder: 'app.zip', mono: true },
    { key: 'deleteArchive', label: 'Delete the ZIP afterwards', kind: 'checkbox' },
  ] },
  chmod: { label: 'Set permissions (chmod)', hint: 'Changes the permissions of a file or folder.', icon: Lock, initial: { mode: '755' }, fields: [
    { key: 'path', label: 'File or folder path', placeholder: 'start.sh', mono: true },
    { key: 'mode', label: 'Mode (octal)', placeholder: '755', mono: true },
  ] },
  mkdir: { label: 'Create folder', hint: 'Creates a folder (nothing happens if it already exists).', icon: FolderPlus, initial: {}, fields: [
    { key: 'path', label: 'Folder path', placeholder: 'plugins', mono: true },
  ] },
  writeFile: { label: 'Write text file', hint: 'Creates a text file, or overwrites it if it exists.', icon: FilePlus2, initial: {}, fields: [
    { key: 'path', label: 'File path', placeholder: 'eula.txt', mono: true },
    { key: 'content', label: 'Content', kind: 'textarea', mono: true },
  ] },
  delete: { label: 'Delete file or folder', hint: 'Deletes a file or a whole folder (skipped if it is missing).', icon: Trash2, initial: {}, fields: [
    { key: 'path', label: 'Path', placeholder: 'old-build', mono: true },
  ] },
  move: { label: 'Move / rename', hint: 'Moves or renames a file or folder.', icon: MoveRight, initial: {}, fields: [
    { key: 'from', label: 'From', placeholder: 'app-1.2.3', mono: true },
    { key: 'to', label: 'To', placeholder: 'app', mono: true },
  ] },
  moveContents: { label: 'Move folder contents', hint: 'Moves everything inside a folder into another folder. Use it when a ZIP contains its own top-level folder.', icon: FolderInput, initial: { overwrite: true, removeEmptyFolder: true }, fields: [
    { key: 'from', label: 'Folder to empty', placeholder: 'Modpack-Server-1.0', mono: true },
    { key: 'to', label: 'Move into (leave empty for the server folder)', placeholder: 'server folder', mono: true },
    { key: 'overwrite', label: 'Replace files that already exist', kind: 'checkbox' },
    { key: 'removeEmptyFolder', label: 'Delete the empty folder afterwards', kind: 'checkbox' },
  ] },
  command: { label: 'Run command', hint: 'Runs a shell command inside the server folder (e.g. npm install).', icon: TerminalIcon, initial: { timeoutSeconds: 600 }, fields: [
    { key: 'command', label: 'Command', placeholder: 'npm install', mono: true },
    { key: 'timeoutSeconds', label: 'Timeout (seconds)', kind: 'number' },
  ] },
  setStartCommand: { label: 'Set start command', hint: 'Sets the command that starts this server.', icon: Wand2, initial: {}, fields: [
    { key: 'command', label: 'Start command', placeholder: 'npm start', mono: true },
  ] },
};

const STEP_ORDER = Object.keys(STEP_DEFS) as StepType[];

const TEMPLATES: { name: string; description: string; draft: ScriptDraft }[] = [
  {
    name: 'Download a program and make it runnable',
    description: 'Downloads a single file (for example a Linux binary), makes it executable and uses it as the start command.',
    draft: {
      name: 'Download and run a program',
      description: 'Downloads a binary, sets chmod 755 and uses it as the start command.',
      variables: [{ key: 'url', label: 'Download URL', defaultValue: '' }, { key: 'file', label: 'File name', defaultValue: 'app' }],
      steps: [
        { type: 'download', url: '{{url}}', fileName: '{{file}}' },
        { type: 'chmod', path: '{{file}}', mode: '755' },
        { type: 'setStartCommand', command: './{{file}}' },
      ],
    },
  },
  {
    name: 'Node.js project from a ZIP link',
    description: 'Downloads a ZIP, extracts it, runs npm install and sets npm start.',
    draft: {
      name: 'Node.js project from ZIP',
      description: 'Download → unzip → npm install → start command. The ZIP should contain package.json at its top level.',
      variables: [{ key: 'zip_url', label: 'ZIP URL', defaultValue: '' }],
      steps: [
        { type: 'download', url: '{{zip_url}}', fileName: 'project.zip' },
        { type: 'unzip', path: 'project.zip', deleteArchive: true },
        { type: 'command', command: 'npm install', timeoutSeconds: 900 },
        { type: 'setStartCommand', command: 'npm start' },
      ],
    },
  },
  {
    name: 'Minecraft Java server (jar link)',
    description: 'Downloads a server jar, accepts the Minecraft EULA and sets a Java start command.',
    draft: {
      name: 'Minecraft Java server',
      description: 'Downloads the server jar and writes eula.txt. By running it you accept the Minecraft EULA: https://aka.ms/MinecraftEULA',
      variables: [{ key: 'jar_url', label: 'Server jar URL', defaultValue: '' }, { key: 'ram', label: 'Memory (e.g. 1G, 2G)', defaultValue: '1G' }],
      steps: [
        { type: 'download', url: '{{jar_url}}', fileName: 'server.jar' },
        { type: 'writeFile', path: 'eula.txt', content: 'eula=true\n' },
        { type: 'setStartCommand', command: 'java -Xms{{ram}} -Xmx{{ram}} -jar server.jar nogui' },
      ],
    },
  },
];

function errorMessage(error: unknown, fallback: string): string {
  const data = (error as { data?: { error?: unknown } } | null)?.data;
  if (data && typeof data.error === 'string') return data.error;
  return error instanceof Error && error.message ? error.message : fallback;
}

// "{{name1}}" and "name1" both become "name1"; other braces are removed.
function cleanVariableKey(raw: string): string {
  const trimmed = raw.replace(/\s+/g, ' ').trim();
  const wrapped = trimmed.match(/^\{\{\s*([^{}]+?)\s*\}\}$/);
  return (wrapped ? wrapped[1] : trimmed).replace(/[{}]/g, '').replace(/\s+/g, ' ').trim().slice(0, 64).trim();
}

// Two or more {{placeholders}} in one name box share one input box: "{{a}}, {{b}}" or "{{a}}/{{b}}" -> ["a", "b"].
// A single name can never contain braces, so whatever sits between the placeholders is only a separator.
function splitVariableKeys(raw: string): string[] | null {
  const matches = [...raw.matchAll(/\{\{\s*([^{}]+?)\s*\}\}/g)];
  if (matches.length < 2) return null;
  const names: string[] = [];
  for (const match of matches) {
    const name = cleanVariableKey(match[1]).split(' ').slice(0, 10).join(' ').slice(0, 64).trim();
    if (name && !names.some((item) => item.toLowerCase() === name.toLowerCase())) names.push(name);
  }
  return names.length >= 2 ? names : null;
}

const fieldClass = 'h-10 w-full rounded-lg border bg-card px-3 text-sm outline-none focus:border-primary';

/* ------------------------------------------------------------------ */
/* Export / import (JSON file)                                         */
/* ------------------------------------------------------------------ */

const EXPORT_FORMAT = 'nodewatch-script';
const MAX_IMPORT_BYTES = 1_000_000;

function downloadJson(fileName: string, data: unknown) {
  const blob = new Blob([`${JSON.stringify(data, null, 2)}\n`], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = fileName;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function fileSafeName(name: string): string {
  return name.replace(/[^\p{L}\p{N}_-]+/gu, '-').replace(/^-+|-+$/g, '').slice(0, 60) || 'script';
}

function toExportable(script: ScriptDraft): ScriptDraft {
  return { name: script.name, description: script.description, variables: script.variables.map((variable) => (variable.group ? { key: variable.key, label: variable.label, defaultValue: variable.defaultValue, group: variable.group } : { key: variable.key, label: variable.label, defaultValue: variable.defaultValue })), steps: script.steps };
}

function exportScripts(scripts: ScriptDraft[], fileName: string) {
  downloadJson(fileName, { format: EXPORT_FORMAT, version: 1, exportedAt: new Date().toISOString(), scripts: scripts.map(toExportable) });
}

// Accepts an export file, a bare script object, or a list of scripts.
function parseScriptFile(text: string): ScriptDraft[] {
  let data: unknown;
  try {
    data = JSON.parse(text);
  } catch {
    throw new Error('This file is not valid JSON.');
  }
  const wrapped = (data as { scripts?: unknown } | null)?.scripts;
  const list: unknown[] = Array.isArray(data) ? data : Array.isArray(wrapped) ? wrapped : [data];
  if (!list.length) throw new Error('The file does not contain any scripts.');
  if (list.length > 50) throw new Error('A file can hold up to 50 scripts.');
  return list.map((item, index) => {
    const raw = item as Partial<ScriptDraft> | null;
    if (!raw || typeof raw !== 'object' || typeof raw.name !== 'string' || !raw.name.trim() || !Array.isArray(raw.steps)) {
      throw new Error(`Item ${index + 1} is not a Nodewatch script (it needs a name and steps).`);
    }
    const steps = raw.steps.map((step, stepIndex) => {
      const type = (step as { type?: unknown } | null)?.type;
      if (typeof type !== 'string' || !STEP_ORDER.includes(type as StepType)) throw new Error(`“${raw.name}”: step ${stepIndex + 1} has an unknown type.`);
      return step as Step;
    });
    const variables: Variable[] = (Array.isArray(raw.variables) ? raw.variables : []).filter((variable) => variable && typeof variable === 'object').map((variable) => {
      const group = Array.isArray(variable.group) ? variable.group.map(String) : undefined;
      return { key: String(variable.key ?? ''), label: String(variable.label ?? ''), defaultValue: String(variable.defaultValue ?? ''), ...(group && group.length >= 2 ? { group } : {}) };
    });
    return { name: raw.name.trim(), description: typeof raw.description === 'string' ? raw.description : '', variables, steps };
  });
}

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function ScriptsPage() {
  const queryClient = useQueryClient();
  const { can } = useAccess();
  const canManage = can('scripts_edit');
  const scriptsQuery = useQuery({ queryKey: ['install-scripts'], queryFn: () => customFetch<Script[]>('/api/scripts') });
  const [editor, setEditor] = useState<{ id: number | null; draft: ScriptDraft; banner?: string } | null>(null);
  const [importList, setImportList] = useState<ScriptDraft[] | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [templatesOpen, setTemplatesOpen] = useState(false);
  const [runTarget, setRunTarget] = useState<Script | null>(null);
  const [error, setError] = useState('');
  const scripts = scriptsQuery.data ?? [];
  const refresh = () => queryClient.invalidateQueries({ queryKey: ['install-scripts'] });

  const remove = useMutation({
    mutationFn: (script: Script) => customFetch(`/api/scripts/${script.id}`, { method: 'DELETE' }),
    onSuccess: () => { setError(''); void refresh(); },
    onError: (err) => setError(errorMessage(err, 'Could not delete the script.')),
  });

  const blank: ScriptDraft = { name: '', description: '', variables: [], steps: [] };

  const onFileChosen = async (file: File | undefined) => {
    if (fileInputRef.current) fileInputRef.current.value = '';
    if (!file) return;
    setError('');
    try {
      if (file.size > MAX_IMPORT_BYTES) throw new Error('The file is too large (the limit is 1 MB).');
      const scriptsInFile = parseScriptFile(await file.text());
      if (scriptsInFile.length === 1) setEditor({ id: null, draft: scriptsInFile[0], banner: 'Imported from a file. Review the steps before saving: “Run command” steps execute on your server.' });
      else setImportList(scriptsInFile);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not read this file.');
    }
  };

  return <div className="space-y-6" data-testid="page-scripts">
    <div className="flex flex-wrap items-start justify-between gap-4">
      <div className="min-w-0 flex-1 basis-64">
        <p className="mono text-[10px] uppercase tracking-[.16em] text-primary">Automation</p>
        <h2 className="mt-1 text-2xl font-bold tracking-tight">Scripts</h2>
        <p className="mt-1 max-w-2xl text-sm leading-6 text-muted-foreground">Auto-install scripts run a list of steps on a server: download files, unzip, set permissions, write config files, run commands and set the start command.</p>
      </div>
      <div className="flex flex-wrap gap-2">
        {canManage && <input ref={fileInputRef} type="file" accept=".json,application/json" className="sr-only" onChange={(event) => void onFileChosen(event.target.files?.[0])} data-testid="input-import-scripts" />}
        {canManage && <button onClick={() => fileInputRef.current?.click()} className="inline-flex h-10 items-center gap-2 rounded-lg border bg-card px-4 text-sm font-bold hover:bg-muted" data-testid="button-import-scripts"><Upload className="size-4" />Import</button>}
        {scripts.length > 0 && <button onClick={() => exportScripts(scripts, 'nodewatch-scripts.json')} className="inline-flex h-10 items-center gap-2 rounded-lg border bg-card px-4 text-sm font-bold hover:bg-muted" title="Download every script as one JSON file" data-testid="button-export-all-scripts"><Download className="size-4" />Export all</button>}
        {canManage && <button onClick={() => setTemplatesOpen(true)} className="inline-flex h-10 items-center gap-2 rounded-lg border bg-card px-4 text-sm font-bold hover:bg-muted" data-testid="button-script-templates"><LayoutTemplate className="size-4" />Templates</button>}
        {canManage && <button onClick={() => setEditor({ id: null, draft: blank })} className="inline-flex h-10 items-center gap-2 rounded-lg bg-primary px-4 text-sm font-bold text-primary-foreground hover:opacity-90" data-testid="button-new-script"><Plus className="size-4" />New script</button>}
      </div>
    </div>

    {error && <p className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700" role="alert" data-testid="text-scripts-error">{error}</p>}

    {scriptsQuery.isLoading ? <div className="grid gap-4 md:grid-cols-2"><div className="skeleton h-40 rounded-xl" /><div className="skeleton h-40 rounded-xl" /></div>
      : scriptsQuery.isError ? <p className="rounded-lg border bg-muted/30 px-4 py-6 text-sm text-muted-foreground">{errorMessage(scriptsQuery.error, 'Scripts could not be loaded.')} <button onClick={() => scriptsQuery.refetch()} className="font-bold text-primary hover:underline">Try again</button></p>
        : scripts.length === 0 ? <div className="grid place-items-center rounded-xl border border-dashed bg-muted/20 px-6 py-14 text-center" data-testid="empty-scripts"><div><ScrollText className="mx-auto size-9 text-muted-foreground" /><p className="mt-3 font-semibold">No scripts yet</p><p className="mt-1 text-sm text-muted-foreground">{canManage ? 'Start from a template or create your own.' : 'No scripts have been created yet. Ask an administrator.'}</p>{canManage && <button onClick={() => setTemplatesOpen(true)} className="mt-4 inline-flex h-10 items-center gap-2 rounded-lg bg-primary px-4 text-sm font-bold text-primary-foreground hover:opacity-90"><LayoutTemplate className="size-4" />Browse templates</button>}</div></div>
          : <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">{scripts.map((script) => <article key={script.id} className="flex flex-col rounded-xl border bg-card p-5 shadow-[0_2px_10px_hsl(218_36%_18%/.035)]" data-testid={`script-card-${script.id}`}>
            <div className="flex items-start gap-3"><span className="grid size-10 shrink-0 place-items-center rounded-lg bg-teal-50 text-primary"><ScrollText className="size-5" /></span><div className="min-w-0 flex-1"><h3 className="break-words font-bold">{script.name}</h3><p className="mt-1 line-clamp-2 break-words text-xs leading-5 text-muted-foreground">{script.description || 'No description'}</p></div></div>
            <ol className="mt-4 space-y-1 text-xs text-muted-foreground">{script.steps.slice(0, 4).map((step, index) => { const Icon = STEP_DEFS[step.type]?.icon ?? ScrollText; return <li key={index} className="flex items-center gap-2"><Icon className="size-3.5 shrink-0" /><span className="truncate">{STEP_DEFS[step.type]?.label ?? step.type}</span></li>; })}{script.steps.length > 4 && <li className="pl-5">+ {script.steps.length - 4} more step{script.steps.length - 4 === 1 ? '' : 's'}</li>}</ol>
            <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t pt-4">
              <p className="text-[11px] text-muted-foreground">{script.steps.length} step{script.steps.length === 1 ? '' : 's'} · {script.variables.length} variable{script.variables.length === 1 ? '' : 's'} · run {script.runCount}×</p>
              <div className="flex gap-1.5">
                <button onClick={() => setRunTarget(script)} className="inline-flex h-9 items-center gap-1.5 rounded-lg bg-primary px-3.5 text-xs font-bold text-primary-foreground hover:opacity-90" data-testid={`button-run-script-${script.id}`}><Play className="size-3.5" />Run on server</button>
                {canManage && <button onClick={() => setEditor({ id: script.id, draft: { name: script.name, description: script.description, variables: script.variables, steps: script.steps } })} className="grid size-9 place-items-center rounded-lg border hover:bg-muted" aria-label={`Edit ${script.name}`} title="Edit" data-testid={`button-edit-script-${script.id}`}><Pencil className="size-4" /></button>}
                {canManage && <button onClick={() => setEditor({ id: null, draft: { name: `${script.name} (copy)`, description: script.description, variables: script.variables, steps: script.steps } })} className="grid size-9 place-items-center rounded-lg border hover:bg-muted" aria-label={`Duplicate ${script.name}`} title="Duplicate" data-testid={`button-duplicate-script-${script.id}`}><Copy className="size-4" /></button>}
                <button onClick={() => exportScripts([script], `${fileSafeName(script.name)}.json`)} className="grid size-9 place-items-center rounded-lg border hover:bg-muted" aria-label={`Export ${script.name} as a JSON file`} title="Export as JSON" data-testid={`button-export-script-${script.id}`}><Download className="size-4" /></button>
                {canManage && <button onClick={() => { if (window.confirm(`Delete the script "${script.name}"?`)) remove.mutate(script); }} disabled={remove.isPending} className="grid size-9 place-items-center rounded-lg border text-red-700 hover:bg-red-50 disabled:opacity-50" aria-label={`Delete ${script.name}`} title="Delete" data-testid={`button-delete-script-${script.id}`}><Trash2 className="size-4" /></button>}
              </div>
            </div>
          </article>)}</div>}

    {templatesOpen && canManage && <Modal title="Script templates" onClose={() => setTemplatesOpen(false)} wide>
      <p className="text-sm text-muted-foreground">Pick a template to start from. It opens in the editor so you can change anything before saving.</p>
      <div className="mt-4 space-y-3">{TEMPLATES.map((template) => <button key={template.name} onClick={() => { setTemplatesOpen(false); setEditor({ id: null, draft: template.draft }); }} className="flex w-full items-start gap-3 rounded-xl border bg-card p-4 text-left transition hover:border-primary hover:bg-muted/40" data-testid={`template-${template.name.split(' ')[0].toLowerCase()}`}><span className="grid size-10 shrink-0 place-items-center rounded-lg bg-teal-50 text-primary"><LayoutTemplate className="size-5" /></span><span className="min-w-0"><span className="block font-bold">{template.name}</span><span className="mt-1 block text-xs leading-5 text-muted-foreground">{template.description}</span></span></button>)}</div>
    </Modal>}

    {importList && <ImportScriptsDialog scripts={importList} onClose={() => setImportList(null)} onDone={() => { setImportList(null); void refresh(); }} />}
    {editor && canManage && <ScriptEditor scriptId={editor.id} initial={editor.draft} banner={editor.banner} onClose={() => setEditor(null)} onSaved={() => { setEditor(null); void refresh(); }} />}
    {runTarget && <RunScriptDialog script={runTarget} onClose={() => { setRunTarget(null); void refresh(); }} />}
  </div>;
}

/* ------------------------------------------------------------------ */
/* Shared modal                                                        */
/* ------------------------------------------------------------------ */

function Modal({ title, onClose, children, wide = false, footer, closeDisabled = false }: { title: string; onClose: () => void; children: ReactNode; wide?: boolean; footer?: ReactNode; closeDisabled?: boolean }) {
  useEffect(() => {
    const previous = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = previous; };
  }, []);
  return createPortal(
    <div className="fixed inset-0 z-[80] grid place-items-center bg-sidebar/45 p-3 backdrop-blur-sm sm:p-6" role="dialog" aria-modal="true" aria-label={title} onMouseDown={(event) => { if (event.target === event.currentTarget && !closeDisabled) onClose(); }}>
      <div className={`flex max-h-[94dvh] w-full flex-col overflow-hidden rounded-2xl border bg-card shadow-2xl ${wide ? 'max-w-3xl' : 'max-w-xl'}`}>
        <div className="flex items-center justify-between border-b px-5 py-4 sm:px-6"><h3 className="text-lg font-bold">{title}</h3><button onClick={onClose} disabled={closeDisabled} className="grid size-9 place-items-center rounded-lg text-muted-foreground hover:bg-muted disabled:opacity-40" aria-label="Close"><X className="size-5" /></button></div>
        <div className="overflow-y-auto px-5 py-5 sm:px-6">{children}</div>
        {footer && <div className="border-t px-5 py-4 sm:px-6">{footer}</div>}
      </div>
    </div>,
    document.body,
  );
}

/* ------------------------------------------------------------------ */
/* Script editor                                                       */
/* ------------------------------------------------------------------ */

function ScriptEditor({ scriptId, initial, banner, onClose, onSaved }: { scriptId: number | null; initial: ScriptDraft; banner?: string; onClose: () => void; onSaved: () => void }) {
  const [name, setName] = useState(initial.name);
  const [description, setDescription] = useState(initial.description);
  const [variables, setVariables] = useState<Variable[]>(() => initial.variables.map((variable) => (variable.group && variable.group.length >= 2 ? { ...variable, key: variable.group.map((name) => `{{${name}}}`).join(', ') } : variable)));
  const [steps, setSteps] = useState<Step[]>(initial.steps);
  const [addOpen, setAddOpen] = useState(false);
  const [error, setError] = useState('');

  const save = useMutation({
    mutationFn: (body: ScriptDraft) => customFetch(scriptId ? `/api/scripts/${scriptId}` : '/api/scripts', { method: scriptId ? 'PUT' : 'POST', body: JSON.stringify(body) }),
    onSuccess: onSaved,
    onError: (err) => setError(errorMessage(err, 'Could not save the script.')),
  });

  // Leaving the name box (or pressing Enter) cleans the name. Several {{placeholders}} stay in one row and share one input box.
  const commitVariableKey = (index: number) => setVariables((current) => current.map((item, i) => {
    if (i !== index) return item;
    const names = splitVariableKeys(item.key);
    return { ...item, key: names ? names.map((name) => `{{${name}}}`).join(', ') : cleanVariableKey(item.key) };
  }));
  const updateStep = (index: number, patch: Partial<Step>) => setSteps((current) => current.map((step, i) => (i === index ? { ...step, ...patch } : step)));
  const moveStep = (index: number, delta: number) => setSteps((current) => {
    const target = index + delta;
    if (target < 0 || target >= current.length) return current;
    const next = [...current];
    [next[index], next[target]] = [next[target], next[index]];
    return next;
  });

  const submit = () => {
    setError('');
    if (!name.trim()) return setError('Enter a script name.');
    if (!steps.length) return setError('Add at least one step.');
    const finalVariables: Variable[] = variables.map((row) => {
      const names = splitVariableKeys(row.key);
      return names ? { key: names.join('/'), label: row.label, defaultValue: row.defaultValue, group: names } : { key: cleanVariableKey(row.key), label: row.label, defaultValue: row.defaultValue };
    });
    const known = new Set([...finalVariables.flatMap((variable) => variable.group ?? [variable.key]), 'server_name', 'server_dir', 'port']);
    const missing = new Set<string>();
    for (const step of steps) {
      for (const value of Object.values(step)) {
        if (typeof value !== 'string') continue;
        for (const match of value.matchAll(/\{\{([^{}\r\n]+?)\}\}/g)) {
          const key = match[1].replace(/\s+/g, ' ').trim();
          if (/^[A-Za-z_][A-Za-z0-9_]*$/.test(key) && !known.has(key)) missing.add(key);
        }
      }
    }
    if (missing.size) return setError(`The steps use ${[...missing].map((key) => `{{${key}}}`).join(', ')} but no variable has that name. Add the variable(s) above first.`);
    save.mutate({ name: name.trim(), description: description.trim(), variables: finalVariables, steps: steps.map((step) => (step.type === 'command' && step.timeoutSeconds === '' ? { ...step, timeoutSeconds: undefined } : step)) });
  };

  return <Modal title={scriptId ? 'Edit script' : 'New script'} onClose={onClose} wide closeDisabled={save.isPending}
    footer={<div className="flex flex-col-reverse gap-3 sm:flex-row sm:justify-end"><button onClick={onClose} disabled={save.isPending} className="h-11 rounded-lg border px-5 text-sm font-bold hover:bg-muted" data-testid="button-script-cancel">Cancel</button><button onClick={submit} disabled={save.isPending} className="inline-flex h-11 items-center justify-center gap-2 rounded-lg bg-primary px-6 text-sm font-bold text-primary-foreground hover:opacity-90 disabled:opacity-60" data-testid="button-script-save">{save.isPending && <LoaderCircle className="size-4 animate-spin" />}Save script</button></div>}>
    <div className="space-y-6" data-testid="dialog-script-editor">
      {banner && <p className="rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800" data-testid="text-import-banner">{banner}</p>}
      <label className="block space-y-1.5"><span className="text-xs font-bold uppercase tracking-[.1em] text-muted-foreground">Script name</span><input value={name} onChange={(event) => setName(event.target.value)} maxLength={80} className={fieldClass} placeholder="e.g. Install my bot" data-testid="input-script-name" /></label>
      <label className="block space-y-1.5"><span className="text-xs font-bold uppercase tracking-[.1em] text-muted-foreground">Description (optional)</span><textarea value={description} onChange={(event) => setDescription(event.target.value)} maxLength={500} rows={2} className="w-full rounded-lg border bg-card px-3 py-2 text-sm outline-none focus:border-primary" data-testid="input-script-description" /></label>

      <section className="space-y-3">
        <div className="flex items-start justify-between gap-3"><div><h4 className="font-bold">Variables</h4><p className="text-xs leading-5 text-muted-foreground">Values asked when the script runs. Type the name as <code className="mono rounded bg-muted px-1">{'{{isim1}}'}</code> or just <code className="mono rounded bg-muted px-1">isim1</code>. To fill several names from one box write them together, for example <code className="mono rounded bg-muted px-1">{'{{isim1}} {{isim2}}'}</code>; when running you type the values in one box, separated by a space or comma. A name can also be up to 10 words with spaces, letters in any language and symbols, for example <code className="mono rounded bg-muted px-1">{'{{test1 test2}}'}</code>. Use it in any step exactly as shown; tap the small placeholder under a name to copy it. Built in: <code className="mono rounded bg-muted px-1">{'{{server_name}}'}</code> <code className="mono rounded bg-muted px-1">{'{{server_dir}}'}</code> <code className="mono rounded bg-muted px-1">{'{{port}}'}</code></p></div>
          <button onClick={() => setVariables((current) => [...current, { key: '', label: '', defaultValue: '' }])} className="inline-flex h-9 shrink-0 items-center gap-1.5 rounded-lg border px-3 text-xs font-bold hover:bg-muted" data-testid="button-add-variable"><Plus className="size-3.5" />Variable</button></div>
        {variables.map((variable, index) => <div key={index} className="grid grid-cols-1 gap-2 rounded-lg border bg-muted/20 p-3 sm:grid-cols-[1fr_1.2fr_1.2fr_auto]">
          <div className="min-w-0">
            <input value={variable.key} onChange={(event) => { const next = event.target.value.replace(/[\r\n]/g, '').slice(0, 400); if (!splitVariableKeys(next) && next.replace(/[{}]/g, ' ').trim().split(/\s+/).filter(Boolean).length > 10) return; setVariables((current) => current.map((item, i) => (i === index ? { ...item, key: next } : item))); }} onBlur={() => commitVariableKey(index)} onKeyDown={(event) => { if (event.key === 'Enter') { event.preventDefault(); commitVariableKey(index); } }} placeholder="name, e.g. {{isim1}} or {{isim1}} {{isim2}}" aria-label="Variable name" className={`${fieldClass} mono`} data-testid={`input-variable-key-${index}`} />
            {splitVariableKeys(variable.key) ? <p className="mt-1 text-[11px] font-semibold text-primary" data-testid={`text-variable-split-${index}`}>One box for {splitVariableKeys(variable.key)?.length} names: {splitVariableKeys(variable.key)?.join(', ')}. When running you type the values in one box, separated by a space or comma.</p>
              : cleanVariableKey(variable.key) && <button type="button" onClick={() => { void navigator.clipboard?.writeText(`{{${cleanVariableKey(variable.key)}}}`); }} className="mono mt-1 block max-w-full truncate text-left text-[11px] text-primary hover:underline" title="Click to copy" data-testid={`button-copy-placeholder-${index}`}>{`{{${cleanVariableKey(variable.key)}}}`} · {cleanVariableKey(variable.key).split(' ').length}/10 words</button>}
          </div>
          <input value={variable.label} onChange={(event) => setVariables((current) => current.map((item, i) => (i === index ? { ...item, label: event.target.value } : item)))} placeholder="Question shown when running" aria-label="Variable label" className={fieldClass} data-testid={`input-variable-label-${index}`} />
          <input value={variable.defaultValue} onChange={(event) => setVariables((current) => current.map((item, i) => (i === index ? { ...item, defaultValue: event.target.value } : item)))} placeholder="Default value" aria-label="Variable default" className={`${fieldClass} mono`} data-testid={`input-variable-default-${index}`} />
          <button onClick={() => setVariables((current) => current.filter((_, i) => i !== index))} className="grid size-10 place-items-center rounded-lg border text-red-700 hover:bg-red-50" aria-label="Remove variable"><Trash2 className="size-4" /></button>
        </div>)}
      </section>

      <section className="space-y-3">
        <div className="flex items-start justify-between gap-3"><div><h4 className="font-bold">Steps</h4><p className="text-xs leading-5 text-muted-foreground">Steps run top to bottom. Paths are relative to the server's own folder. If a step fails the script stops, unless you tick “continue on error”.</p></div></div>
        {steps.length === 0 && <p className="rounded-lg border border-dashed px-4 py-6 text-center text-sm text-muted-foreground">No steps yet. Add the first one below.</p>}
        {steps.map((step, index) => {
          const def = STEP_DEFS[step.type];
          const Icon = def.icon;
          return <div key={index} className="rounded-xl border bg-card p-4" data-testid={`script-step-${index}`}>
            <div className="flex items-center gap-3"><span className="grid size-8 shrink-0 place-items-center rounded-lg bg-teal-50 text-primary"><Icon className="size-4" /></span><div className="min-w-0 flex-1"><p className="text-sm font-bold">{index + 1}. {def.label}</p><p className="truncate text-[11px] text-muted-foreground">{def.hint}</p></div>
              <div className="flex gap-1"><button onClick={() => moveStep(index, -1)} disabled={index === 0} className="grid size-8 place-items-center rounded-md border hover:bg-muted disabled:opacity-30" aria-label="Move up"><ArrowUp className="size-4" /></button><button onClick={() => moveStep(index, 1)} disabled={index === steps.length - 1} className="grid size-8 place-items-center rounded-md border hover:bg-muted disabled:opacity-30" aria-label="Move down"><ArrowDown className="size-4" /></button><button onClick={() => setSteps((current) => current.filter((_, i) => i !== index))} className="grid size-8 place-items-center rounded-md border text-red-700 hover:bg-red-50" aria-label="Remove step" data-testid={`button-remove-step-${index}`}><Trash2 className="size-4" /></button></div></div>
            <div className="mt-3 grid grid-cols-1 gap-3">{def.fields.map((field) => {
              const value = step[field.key];
              if (field.kind === 'checkbox') return <label key={field.key} className="flex items-center gap-2 text-sm"><input type="checkbox" checked={Boolean(value)} onChange={(event) => updateStep(index, { [field.key]: event.target.checked })} className="size-4 accent-[hsl(var(--primary))]" />{field.label}</label>;
              return <label key={field.key} className="block space-y-1"><span className="text-[11px] font-bold uppercase tracking-[.08em] text-muted-foreground">{field.label}</span>
                {field.kind === 'textarea' ? <textarea value={String(value ?? '')} onChange={(event) => updateStep(index, { [field.key]: event.target.value })} rows={4} spellCheck={false} className={`w-full rounded-lg border bg-card px-3 py-2 text-sm outline-none focus:border-primary ${field.mono ? 'mono text-xs' : ''}`} />
                  : <input type={field.kind === 'number' ? 'number' : 'text'} value={String(value ?? '')} onChange={(event) => updateStep(index, { [field.key]: event.target.value })} placeholder={field.placeholder} spellCheck={false} autoCapitalize="off" className={`${fieldClass} ${field.mono ? 'mono text-xs' : ''}`} data-testid={`input-step-${index}-${field.key}`} />}</label>;
            })}</div>
            <label className="mt-3 flex items-center gap-2 text-xs text-muted-foreground"><input type="checkbox" checked={Boolean(step.ignoreErrors)} onChange={(event) => updateStep(index, { ignoreErrors: event.target.checked })} className="size-3.5" />Continue even if this step fails</label>
          </div>;
        })}
        <div className="relative">
          <button onClick={() => setAddOpen((open) => !open)} className="inline-flex h-10 w-full items-center justify-center gap-2 rounded-lg border border-dashed text-sm font-bold text-primary hover:bg-muted/50" data-testid="button-add-step"><Plus className="size-4" />Add step</button>
          {addOpen && <div className="mt-2 grid grid-cols-1 gap-1.5 rounded-xl border bg-card p-2 shadow-lg sm:grid-cols-2">{STEP_ORDER.map((type) => { const def = STEP_DEFS[type]; const Icon = def.icon; return <button key={type} onClick={() => { setSteps((current) => [...current, { type, ...def.initial }]); setAddOpen(false); }} className="flex items-center gap-2.5 rounded-lg px-3 py-2.5 text-left text-sm font-semibold hover:bg-muted" data-testid={`button-step-type-${type}`}><Icon className="size-4 text-primary" />{def.label}</button>; })}</div>}
        </div>
      </section>

      {error && <p className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700" role="alert" data-testid="text-script-error">{error}</p>}
    </div>
  </Modal>;
}

/* ------------------------------------------------------------------ */
/* Import several scripts                                              */
/* ------------------------------------------------------------------ */

function ImportScriptsDialog({ scripts, onClose, onDone }: { scripts: ScriptDraft[]; onClose: () => void; onDone: () => void }) {
  const [errors, setErrors] = useState<string[]>([]);
  const importAll = useMutation({
    mutationFn: async () => {
      const failed: string[] = [];
      for (const script of scripts) {
        try {
          await customFetch('/api/scripts', { method: 'POST', body: JSON.stringify(script) });
        } catch (err) {
          failed.push(`${script.name}: ${errorMessage(err, 'could not be imported')}`);
        }
      }
      return failed;
    },
    onSuccess: (failed) => { if (failed.length) setErrors(failed); else onDone(); },
  });
  const commands = scripts.reduce((total, script) => total + script.steps.filter((step) => step.type === 'command').length, 0);

  return <Modal title={`Import ${scripts.length} scripts`} onClose={onClose} closeDisabled={importAll.isPending}
    footer={<div className="flex flex-col-reverse gap-3 sm:flex-row sm:justify-end"><button onClick={errors.length ? onDone : onClose} disabled={importAll.isPending} className="h-11 rounded-lg border px-5 text-sm font-bold hover:bg-muted">{errors.length ? 'Close' : 'Cancel'}</button>{!errors.length && <button onClick={() => importAll.mutate()} disabled={importAll.isPending} className="inline-flex h-11 items-center justify-center gap-2 rounded-lg bg-primary px-6 text-sm font-bold text-primary-foreground hover:opacity-90 disabled:opacity-60" data-testid="button-confirm-import">{importAll.isPending && <LoaderCircle className="size-4 animate-spin" />}Import all</button>}</div>}>
    <div className="space-y-4" data-testid="dialog-import-scripts">
      <ul className="space-y-2">{scripts.map((script, index) => <li key={index} className="rounded-lg border bg-muted/20 px-4 py-3"><p className="break-words text-sm font-bold">{script.name}</p><p className="text-xs text-muted-foreground">{script.steps.length} step{script.steps.length === 1 ? '' : 's'} · {script.variables.length} variable{script.variables.length === 1 ? '' : 's'}</p></li>)}</ul>
      {commands > 0 && <p className="rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">These scripts contain {commands} “Run command” step{commands === 1 ? '' : 's'} that execute on your server. Only import files from people you trust, and read the steps before running them.</p>}
      {errors.length > 0 && <div className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700" role="alert" data-testid="text-import-errors"><p className="font-bold">Some scripts could not be imported:</p><ul className="mt-1 list-disc space-y-0.5 pl-5">{errors.map((message) => <li key={message} className="break-words">{message}</li>)}</ul></div>}
    </div>
  </Modal>;
}

/* ------------------------------------------------------------------ */
/* Run dialog                                                          */
/* ------------------------------------------------------------------ */

type RunView = {
  id: string; scriptName: string; serverId: number; serverName: string;
  status: 'running' | 'success' | 'failed' | 'cancelled'; startedAt: string; finishedAt: string | null;
  steps: { index: number; type: StepType; label: string; status: 'pending' | 'running' | 'success' | 'failed' | 'skipped'; message: string | null }[];
  log: string[]; logTotal: number;
};

function RunScriptDialog({ script, onClose }: { script: Script; onClose: () => void }) {
  const serversQuery = useGetServers();
  const servers = serversQuery.data ?? [];
  const [serverId, setServerId] = useState<number | ''>('');
  const [values, setValues] = useState<Record<string, string>>(() => Object.fromEntries(script.variables.map((variable) => [variable.key, variable.defaultValue])));
  const [runId, setRunId] = useState<string | null>(null);
  const [run, setRun] = useState<RunView | null>(null);
  const [logLines, setLogLines] = useState<string[]>([]);
  const [error, setError] = useState('');
  const offsetRef = useRef(0);
  const logRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (serverId === '' && servers.length === 1) setServerId(servers[0].id);
  }, [servers, serverId]);

  const start = useMutation({
    mutationFn: () => customFetch<{ runId: string }>(`/api/scripts/${script.id}/run`, { method: 'POST', body: JSON.stringify({ serverId, variables: values }) }),
    onSuccess: (result) => { setError(''); offsetRef.current = 0; setLogLines([]); setRun(null); setRunId(result.runId); },
    onError: (err) => setError(errorMessage(err, 'Could not start the script.')),
  });
  const cancel = useMutation({
    mutationFn: () => customFetch(`/api/script-runs/${runId}/cancel`, { method: 'POST' }),
    onError: (err) => setError(errorMessage(err, 'Could not cancel the run.')),
  });

  useEffect(() => {
    if (!runId) return undefined;
    let stopped = false;
    const poll = async () => {
      try {
        const view = await customFetch<RunView & { logTotal: number }>(`/api/script-runs/${runId}?since=${offsetRef.current}`);
        if (stopped) return;
        offsetRef.current = view.logTotal;
        setRun(view);
        if (view.log.length) setLogLines((current) => [...current, ...view.log].slice(-3000));
        if (view.status !== 'running') return;
      } catch (err) {
        if (stopped) return;
        setError(errorMessage(err, 'Lost connection to the run.'));
        return;
      }
      window.setTimeout(() => { if (!stopped) void poll(); }, 1000);
    };
    void poll();
    return () => { stopped = true; };
  }, [runId]);

  useEffect(() => {
    const el = logRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [logLines]);

  const running = run?.status === 'running' || start.isPending;
  const canStart = serverId !== '' && !start.isPending && script.variables.every((variable) => (values[variable.key] ?? '').trim());
  const selectedServer = useMemo(() => servers.find((server) => server.id === serverId), [servers, serverId]);

  const statusIcon = (status: RunView['steps'][number]['status']) => {
    if (status === 'running') return <LoaderCircle className="size-4 animate-spin text-primary" />;
    if (status === 'success') return <Check className="size-4 text-emerald-600" />;
    if (status === 'failed') return <XCircle className="size-4 text-red-600" />;
    if (status === 'skipped') return <SkipForward className="size-4 text-muted-foreground" />;
    return <CircleDashed className="size-4 text-muted-foreground" />;
  };

  return <Modal title={`Run “${script.name}”`} onClose={onClose} wide closeDisabled={running}
    footer={<div className="flex flex-col-reverse gap-3 sm:flex-row sm:items-center sm:justify-between">
      <div className="min-h-5 text-sm">{run && run.status !== 'running' && <span className={`font-bold ${run.status === 'success' ? 'text-emerald-700' : run.status === 'cancelled' ? 'text-muted-foreground' : 'text-red-700'}`} data-testid="text-run-result">{run.status === 'success' ? 'Finished successfully' : run.status === 'cancelled' ? 'Cancelled' : 'Failed'}</span>}</div>
      <div className="flex flex-col-reverse gap-3 sm:flex-row">
        {run && selectedServer && run.status !== 'running' && <Link href={`/servers/${selectedServer.id}`} className="inline-flex h-11 items-center justify-center rounded-lg border px-5 text-sm font-bold hover:bg-muted" data-testid="link-run-open-server">Open server</Link>}
        {run?.status === 'running' ? <button onClick={() => cancel.mutate()} disabled={cancel.isPending} className="inline-flex h-11 items-center justify-center gap-2 rounded-lg border border-red-200 px-5 text-sm font-bold text-red-700 hover:bg-red-50" data-testid="button-cancel-run"><X className="size-4" />Cancel run</button>
          : runId ? <button onClick={onClose} className="h-11 rounded-lg bg-primary px-6 text-sm font-bold text-primary-foreground hover:opacity-90" data-testid="button-run-close">Close</button>
            : <><button onClick={onClose} className="h-11 rounded-lg border px-5 text-sm font-bold hover:bg-muted">Cancel</button><button onClick={() => start.mutate()} disabled={!canStart} className="inline-flex h-11 items-center justify-center gap-2 rounded-lg bg-primary px-6 text-sm font-bold text-primary-foreground hover:opacity-90 disabled:opacity-50" data-testid="button-start-script">{start.isPending ? <LoaderCircle className="size-4 animate-spin" /> : <Play className="size-4" />}Start</button></>}
      </div>
    </div>}>
    <div className="space-y-5" data-testid="dialog-run-script">
      {!runId && <>
        <label className="block space-y-1.5"><span className="text-xs font-bold uppercase tracking-[.1em] text-muted-foreground">Run on server</span>
          <select value={serverId} onChange={(event) => setServerId(event.target.value ? Number(event.target.value) : '')} className={fieldClass} data-testid="select-run-server"><option value="">{serversQuery.isLoading ? 'Loading servers…' : servers.length ? 'Choose a server' : 'No servers yet'}</option>{servers.map((server) => <option key={server.id} value={server.id}>{server.name}{server.status === 'online' ? ' (running)' : ''}</option>)}</select></label>
        {selectedServer?.status === 'online' && <p className="rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800">This server is running. If the script replaces its files, stop the server first.</p>}
        {script.variables.map((variable) => <label key={variable.key} className="block space-y-1.5"><span className="text-xs font-bold uppercase tracking-[.1em] text-muted-foreground">{variable.label || variable.key}</span><input value={values[variable.key] ?? ''} onChange={(event) => setValues((current) => ({ ...current, [variable.key]: event.target.value }))} spellCheck={false} autoCapitalize="off" placeholder={variable.group ? variable.group.join(' ') : undefined} className={`${fieldClass} mono text-xs`} data-testid={`input-run-var-${variable.key}`} />{variable.group && <span className="block text-[11px] normal-case tracking-normal text-muted-foreground">Enter {variable.group.length} values in this order: {variable.group.join(', ')}. Separate them with a space or comma; the last one may contain spaces.</span>}</label>)}
        <div className="rounded-lg border bg-muted/20 p-3"><p className="text-[11px] font-bold uppercase tracking-[.1em] text-muted-foreground">What will happen</p><ol className="mt-2 space-y-1 text-xs text-muted-foreground">{script.steps.map((step, index) => <li key={index} className="flex gap-2"><span className="mono w-5 shrink-0 text-right">{index + 1}.</span><span className="min-w-0 break-words">{STEP_DEFS[step.type]?.label}</span></li>)}</ol></div>
      </>}

      {runId && <>
        <ol className="space-y-1.5" data-testid="run-steps">{(run?.steps ?? script.steps.map((step, index) => ({ index, type: step.type, label: STEP_DEFS[step.type]?.label ?? step.type, status: 'pending' as const, message: null }))).map((step) => <li key={step.index} className="flex items-start gap-2.5 rounded-lg border bg-card px-3 py-2.5 text-sm"><span className="mt-0.5 shrink-0">{statusIcon(step.status)}</span><span className="min-w-0 flex-1"><span className="block break-words font-semibold">{step.label}</span>{step.message && <span className={`mt-0.5 block break-words text-xs ${step.status === 'failed' ? 'text-red-700' : 'text-muted-foreground'}`}>{step.message}</span>}</span></li>)}</ol>
        <div ref={logRef} className="mono max-h-64 overflow-y-auto whitespace-pre-wrap break-words rounded-xl bg-[#121920] p-4 text-[11px] leading-5 text-slate-200" data-testid="run-log" aria-live="polite">{logLines.length ? logLines.map((line, index) => <div key={index} className={line.startsWith('✖') ? 'text-red-300' : line.startsWith('✔') ? 'text-emerald-300' : line.startsWith('▶') ? 'font-bold text-teal-200' : ''}>{line || ' '}</div>) : <span className="text-slate-500">Starting…</span>}</div>
      </>}

      {error && <p className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700" role="alert" data-testid="text-run-error">{error}</p>}
    </div>
  </Modal>;
}
