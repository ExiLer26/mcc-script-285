import { useQuery } from '@tanstack/react-query';
import { customFetch, getGetCurrentAdminQueryKey, useGetCurrentAdmin } from '@workspace/api-client-react';

export type Permission =
  | 'power' | 'kill' | 'console_view' | 'console_send' | 'files_view' | 'files_edit' | 'schedules' | 'startup' | 'settings' | 'scripts' | 'scripts_edit';

export type Access = {
  role: 'admin' | 'user';
  permissions: string[];
  allServers: boolean;
  serverIds: number[];
};

// What the signed-in account may do. Administrators can do everything; limited users only what
// an administrator granted them. The server enforces the same rules, this only hides controls.
export function useAccess(enabled = true) {
  const me = useGetCurrentAdmin({ query: { enabled, queryKey: getGetCurrentAdminQueryKey() } });
  const username = me.data?.username ?? '';
  const query = useQuery({
    queryKey: ['auth-access', username],
    queryFn: () => customFetch<Access>('/api/auth/access'),
    enabled: enabled && Boolean(username),
    staleTime: 60_000,
  });
  const access = query.data;
  const isAdmin = access?.role === 'admin';
  const can = (permission: Permission) => isAdmin || Boolean(access?.permissions.includes(permission));
  return {
    access,
    isAdmin,
    isUser: access?.role === 'user',
    can,
    isLoading: enabled && (me.isLoading || (Boolean(username) && query.isLoading)),
    isError: query.isError,
    refetch: query.refetch,
  };
}
