import { useEffect, useState, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { Link } from 'wouter';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { LoaderCircle, Play, Plus, RotateCw, Skull, Square, SquareTerminal, X } from 'lucide-react';
import {
  customFetch, getGetDashboardQueryKey, getGetServerLogsQueryKey, getGetServersQueryKey,
  useGetServerLogs, useGetServers, useKillServer, useRestartServer, useStartServer, useStopServer,
  type ManagedServer,
} from '@workspace/api-client-react';
import { TerminalPanel } from './terminal';

const STATUS_STYLE: Record<ManagedServer['status'], { label: string; tone: string; dot: string }> = {
  online: { label: 'Online', tone: 'text-teal-700 bg-teal-50 border-teal-200', dot: 'bg-teal-500' },
  offline: { label: 'Offline', tone: 'text-slate-600 bg-slate-100 border-slate-200', dot: 'bg-slate-400' },
  starting: { label: 'Starting', tone: 'text-amber-700 bg-amber-50 border-amber-200', dot: 'bg-amber-500 animate-pulse' },
  stopping: { label: 'Stopping', tone: 'text-amber-700 bg-amber-50 border-amber-200', dot: 'bg-amber-500 animate-pulse' },
  failed: { label: 'Failed', tone: 'text-red-700 bg-red-50 border-red-200', dot: 'bg-red-500' },
};

function errorMessage(error: unknown, fallback: string): string {
  const data = (error as { data?: { error?: unknown } } | null)?.data;
  if (data && typeof data.error === 'string') return data.error;
  return error instanceof Error && error.message ? error.message : fallback;
}

const pinsKey = ['console-terminals'] as const;

/* ------------------------------------------------------------------ */

export default function ConsolePage() {
  const queryClient = useQueryClient();
  const pinsQuery = useQuery({ queryKey: pinsKey, queryFn: () => customFetch<{ serverId: number }[]>('/api/console-terminals') });
  const serversQuery = useGetServers({ query: { queryKey: getGetServersQueryKey(), refetchInterval: 5000 } });
  const [addOpen, setAddOpen] = useState(false);
  const [error, setError] = useState('');

  const servers = serversQuery.data ?? [];
  const pinned = (pinsQuery.data ?? []).map((pin) => servers.find((server) => server.id === pin.serverId)).filter((server): server is ManagedServer => Boolean(server));
  const pinnedIds = new Set((pinsQuery.data ?? []).map((pin) => pin.serverId));
  const available = servers.filter((server) => !pinnedIds.has(server.id));

  const add = useMutation({
    mutationFn: (serverId: number) => customFetch('/api/console-terminals', { method: 'POST', body: JSON.stringify({ serverId }) }),
    onSuccess: () => { setError(''); setAddOpen(false); void queryClient.invalidateQueries({ queryKey: pinsKey }); },
    onError: (err) => setError(errorMessage(err, 'Could not add the terminal.')),
  });
  const remove = useMutation({
    mutationFn: (serverId: number) => customFetch(`/api/console-terminals/${serverId}`, { method: 'DELETE' }),
    onSuccess: () => { setError(''); void queryClient.invalidateQueries({ queryKey: pinsKey }); },
    onError: (err) => setError(errorMessage(err, 'Could not remove the terminal.')),
  });

  return <div className="space-y-6" data-testid="page-console">
    <div className="flex flex-wrap items-start justify-between gap-4">
      <div className="min-w-0 flex-1 basis-64">
        <p className="mono text-[10px] uppercase tracking-[.16em] text-primary">Live view</p>
        <h2 className="mt-1 text-2xl font-bold tracking-tight">Console</h2>
        <p className="mt-1 max-w-2xl text-sm leading-6 text-muted-foreground">Watch the terminal output of several servers on one page and start, stop or restart them. You cannot type commands here; use the server's own page for that.</p>
      </div>
      <button onClick={() => { setError(''); setAddOpen(true); }} className="inline-flex h-10 items-center gap-2 rounded-lg bg-primary px-4 text-sm font-bold text-primary-foreground hover:opacity-90" data-testid="button-add-terminal"><Plus className="size-4" />Add terminal</button>
    </div>

    {error && <p className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700" role="alert" data-testid="text-console-error">{error}</p>}

    {pinsQuery.isLoading || serversQuery.isLoading ? <div className="skeleton h-72 rounded-xl" />
      : pinsQuery.isError ? <p className="rounded-lg border bg-muted/30 px-4 py-6 text-sm text-muted-foreground">{errorMessage(pinsQuery.error, 'The console could not be loaded.')} <button onClick={() => pinsQuery.refetch()} className="font-bold text-primary hover:underline">Try again</button></p>
        : pinned.length === 0 ? <div className="grid place-items-center rounded-xl border border-dashed bg-muted/20 px-6 py-16 text-center" data-testid="empty-console"><div><SquareTerminal className="mx-auto size-9 text-muted-foreground" /><p className="mt-3 font-semibold">No terminals added yet</p><p className="mt-1 text-sm text-muted-foreground">Add a server to see its terminal here.</p><button onClick={() => setAddOpen(true)} className="mt-4 inline-flex h-10 items-center gap-2 rounded-lg bg-primary px-4 text-sm font-bold text-primary-foreground hover:opacity-90"><Plus className="size-4" />Add terminal</button></div></div>
          : <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">{pinned.map((server) => <ConsoleCard key={server.id} server={server} onRemove={() => remove.mutate(server.id)} removing={remove.isPending && remove.variables === server.id} />)}</div>}

    {addOpen && <AddTerminalDialog servers={available} loading={serversQuery.isLoading} pending={add.isPending} error={error} onAdd={(serverId) => add.mutate(serverId)} onClose={() => setAddOpen(false)} />}
  </div>;
}

/* ------------------------------------------------------------------ */

function ConsoleCard({ server, onRemove, removing }: { server: ManagedServer; onRemove: () => void; removing: boolean }) {
  const queryClient = useQueryClient();
  const start = useStartServer();
  const stop = useStopServer();
  const restart = useRestartServer();
  const kill = useKillServer();
  const [error, setError] = useState('');
  const logs = useGetServerLogs(server.id, { limit: 180 }, { query: { queryKey: getGetServerLogsQueryKey(server.id, { limit: 180 }), refetchInterval: server.logRefreshIntervalSeconds * 1000 } });

  const refresh = () => {
    void queryClient.invalidateQueries({ queryKey: getGetServersQueryKey() });
    void queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
    void logs.refetch();
  };
  const run = (kind: 'start' | 'stop' | 'restart' | 'kill') => {
    setError('');
    const mutation = kind === 'start' ? start : kind === 'stop' ? stop : kind === 'restart' ? restart : kill;
    mutation.mutate({ id: server.id }, { onSuccess: refresh, onError: (err) => { setError(errorMessage(err, 'The action failed.')); refresh(); } });
  };

  const meta = STATUS_STYLE[server.status];
  const busy = start.isPending || stop.isPending || restart.isPending || kill.isPending || server.status === 'starting' || server.status === 'stopping';
  const online = server.status === 'online';
  const spin = (pending: boolean, icon: ReactNode) => (pending ? <LoaderCircle className="size-4 animate-spin" /> : icon);
  const actionButton = 'inline-flex h-9 items-center justify-center gap-1.5 rounded-lg border bg-card px-3 text-xs font-bold transition hover:bg-muted disabled:pointer-events-none disabled:opacity-50';

  return <article className="min-w-0 space-y-3" data-testid={`console-card-${server.id}`}>
    <div className="flex flex-wrap items-center gap-x-3 gap-y-2 rounded-xl border bg-card px-4 py-3 shadow-[0_2px_10px_hsl(218_36%_18%/.035)]">
      <div className="min-w-0 flex-1 basis-40">
        <div className="flex items-center gap-2"><Link href={`/servers/${server.id}`} className="truncate font-bold hover:text-primary hover:underline" data-testid={`link-console-server-${server.id}`}>{server.name}</Link></div>
        <span className={`mt-1 inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 text-[10px] font-bold uppercase tracking-[.08em] ${meta.tone}`} data-testid={`console-status-${server.id}`}><span className={`status-dot ${meta.dot}`} />{meta.label}</span>
      </div>
      <div className="flex flex-wrap items-center gap-1.5">
        {online ? <>
          <button onClick={() => run('stop')} disabled={busy} className={actionButton} data-testid={`button-console-stop-${server.id}`}>{spin(stop.isPending, <Square className="size-4" />)}Stop</button>
          <button onClick={() => run('restart')} disabled={busy} className={actionButton} data-testid={`button-console-restart-${server.id}`}>{spin(restart.isPending, <RotateCw className="size-4" />)}Restart</button>
          <button onClick={() => { if (window.confirm(`Force kill "${server.name}"? Unsaved data may be lost.`)) run('kill'); }} disabled={busy} className={`${actionButton} text-red-700 hover:bg-red-50`} data-testid={`button-console-kill-${server.id}`}>{spin(kill.isPending, <Skull className="size-4" />)}Kill</button>
        </> : <>
          <button onClick={() => run('start')} disabled={busy} className={`${actionButton} border-transparent bg-primary text-primary-foreground hover:bg-primary hover:brightness-95`} data-testid={`button-console-start-${server.id}`}>{spin(start.isPending, <Play className="size-4" />)}Start</button>
          <button onClick={() => run('restart')} disabled={busy} className={actionButton} data-testid={`button-console-restart-${server.id}`}>{spin(restart.isPending, <RotateCw className="size-4" />)}Restart</button>
        </>}
        <button onClick={onRemove} disabled={removing} className="grid size-9 place-items-center rounded-lg border text-muted-foreground hover:bg-muted hover:text-foreground disabled:opacity-50" aria-label={`Remove ${server.name} from the console`} title="Remove from console (the server is not deleted)" data-testid={`button-console-remove-${server.id}`}>{removing ? <LoaderCircle className="size-4 animate-spin" /> : <X className="size-4" />}</button>
      </div>
    </div>
    {error && <p className="rounded-lg border border-red-200 bg-red-50 px-4 py-2.5 text-sm text-red-700" role="alert">{error}</p>}
    <TerminalPanel server={server} logs={logs} readOnly />
  </article>;
}

/* ------------------------------------------------------------------ */

function AddTerminalDialog({ servers, loading, pending, error, onAdd, onClose }: { servers: ManagedServer[]; loading: boolean; pending: boolean; error: string; onAdd: (serverId: number) => void; onClose: () => void }) {
  const [serverId, setServerId] = useState<number | ''>('');

  useEffect(() => {
    const previous = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = previous; };
  }, []);

  return createPortal(
    <div className="fixed inset-0 z-[80] grid place-items-center bg-sidebar/45 p-3 backdrop-blur-sm sm:p-6" role="dialog" aria-modal="true" aria-label="Add terminal" onMouseDown={(event) => { if (event.target === event.currentTarget && !pending) onClose(); }} data-testid="dialog-add-terminal">
      <div className="w-full max-w-md overflow-hidden rounded-2xl border bg-card shadow-2xl">
        <div className="flex items-center justify-between border-b px-5 py-4"><h3 className="text-lg font-bold">Add terminal</h3><button onClick={onClose} disabled={pending} className="grid size-9 place-items-center rounded-lg text-muted-foreground hover:bg-muted" aria-label="Close"><X className="size-5" /></button></div>
        <div className="space-y-4 px-5 py-5">
          {loading ? <div className="skeleton h-11 rounded-lg" />
            : servers.length === 0 ? <p className="rounded-lg border border-dashed px-4 py-6 text-center text-sm text-muted-foreground">Every server already has a terminal here, or you have not created a server yet.</p>
              : <label className="block space-y-1.5"><span className="text-xs font-bold uppercase tracking-[.1em] text-muted-foreground">Server</span>
                <select value={serverId} onChange={(event) => setServerId(event.target.value ? Number(event.target.value) : '')} className="h-11 w-full rounded-lg border bg-card px-3 text-sm outline-none focus:border-primary" data-testid="select-terminal-server"><option value="">Choose a server</option>{servers.map((server) => <option key={server.id} value={server.id}>{server.name}{server.status === 'online' ? ' (running)' : ''}</option>)}</select></label>}
          {error && <p className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700" role="alert">{error}</p>}
        </div>
        <div className="flex flex-col-reverse gap-3 border-t px-5 py-4 sm:flex-row sm:justify-end">
          <button onClick={onClose} disabled={pending} className="h-11 rounded-lg border px-5 text-sm font-bold hover:bg-muted">Cancel</button>
          <button onClick={() => serverId !== '' && onAdd(serverId)} disabled={serverId === '' || pending} className="inline-flex h-11 items-center justify-center gap-2 rounded-lg bg-primary px-6 text-sm font-bold text-primary-foreground hover:opacity-90 disabled:opacity-50" data-testid="button-confirm-add-terminal">{pending && <LoaderCircle className="size-4 animate-spin" />}Add</button>
        </div>
      </div>
    </div>,
    document.body,
  );
}
