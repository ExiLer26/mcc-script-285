import {
  useCallback, useEffect, useMemo, useRef, useState,
  type CSSProperties, type FormEvent, type KeyboardEvent, type ReactNode,
} from 'react';
import { createPortal } from 'react-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { ArrowDown, Check, ChevronDown, Copy, FileCode2, LoaderCircle, RefreshCw, Settings, Trash2, X } from 'lucide-react';
import {
  customFetch, getGetServerQueryKey, getGetServersQueryKey,
  useClearServerLogs, useSendServerConsoleCommand, useUpdateServer, type ManagedServer,
} from '@workspace/api-client-react';

/* ------------------------------------------------------------------ */
/* Settings                                                            */
/* ------------------------------------------------------------------ */

export type TerminalSettings = {
  emulated: boolean;
  colors: boolean;
  lineEnding: 'lf' | 'crlf' | 'cr';
  stopCommand: string;
  inputEncoding: string;
  outputEncoding: string;
};

export const DEFAULT_TERMINAL_SETTINGS: TerminalSettings = {
  emulated: true,
  colors: true,
  lineEnding: 'lf',
  stopCommand: '^C',
  inputEncoding: 'utf8',
  outputEncoding: 'utf-8',
};

const LINE_ENDING_OPTIONS: { value: TerminalSettings['lineEnding']; label: string }[] = [
  { value: 'lf', label: 'Line Feed (\\n) — Linux / macOS' },
  { value: 'crlf', label: 'Carriage Return + Line Feed (\\r\\n) — Windows' },
  { value: 'cr', label: 'Carriage Return (\\r)' },
];

const INPUT_ENCODING_OPTIONS = [
  { value: 'utf8', label: 'UTF-8' },
  { value: 'latin1', label: 'Latin-1 (ISO-8859-1)' },
  { value: 'ascii', label: 'ASCII' },
  { value: 'utf16le', label: 'UTF-16 LE' },
];

const OUTPUT_ENCODING_OPTIONS = [
  { value: 'utf-8', label: 'UTF-8' },
  { value: 'utf-16le', label: 'UTF-16 LE' },
  { value: 'windows-1252', label: 'Western (Windows-1252)' },
  { value: 'windows-1254', label: 'Turkish (Windows-1254)' },
  { value: 'iso-8859-15', label: 'Latin-9 (ISO-8859-15)' },
  { value: 'windows-1251', label: 'Cyrillic (Windows-1251)' },
  { value: 'koi8-r', label: 'Cyrillic (KOI8-R)' },
  { value: 'gbk', label: 'GBK' },
  { value: 'gb18030', label: 'GB18030' },
  { value: 'big5', label: 'Big5' },
  { value: 'shift_jis', label: 'Shift_JIS' },
  { value: 'euc-jp', label: 'EUC-JP' },
  { value: 'euc-kr', label: 'EUC-KR' },
];

const settingsKey = (serverId: number) => ['terminal-settings', serverId] as const;

function useTerminalSettings(serverId: number) {
  return useQuery({
    queryKey: settingsKey(serverId),
    queryFn: () => customFetch<TerminalSettings>(`/api/servers/${serverId}/terminal-settings`),
    staleTime: 30_000,
  });
}

function errorMessage(error: unknown, fallback: string): string {
  const data = (error as { data?: { error?: unknown } } | null)?.data;
  if (data && typeof data.error === 'string') return data.error;
  return error instanceof Error && error.message ? error.message : fallback;
}

/* ------------------------------------------------------------------ */
/* ANSI + Minecraft colour parsing                                     */
/* ------------------------------------------------------------------ */

type AnsiStyle = { fg?: string; bg?: string; bold?: boolean; dim?: boolean; italic?: boolean; underline?: boolean };
type Segment = { text: string; style: AnsiStyle };

const ANSI_COLORS = [
  '#64748b', '#f87171', '#4ade80', '#facc15', '#60a5fa', '#e879f9', '#22d3ee', '#e2e8f0',
  '#94a3b8', '#fca5a5', '#86efac', '#fde047', '#93c5fd', '#f0abfc', '#67e8f9', '#ffffff',
];

const MC_COLORS: Record<string, string> = {
  '0': '#6b7280', '1': '#5b8cff', '2': '#22c55e', '3': '#22d3ee', '4': '#ef4444', '5': '#c084fc',
  '6': '#fbbf24', '7': '#cbd5e1', '8': '#94a3b8', '9': '#93c5fd', a: '#86efac', b: '#67e8f9',
  c: '#fca5a5', d: '#f0abfc', e: '#fde047', f: '#ffffff',
};

const ESCAPE_NOISE = /\u001b\][^\u0007\u001b]*(?:\u0007|\u001b\\)|\u001b\[[0-9;?]*[A-LN-Za-ln-z]|\u001b[()][A-Z0-9]/g;
const COLOR_TOKEN = /\u001b\[([0-9;]*)m|§([0-9a-fk-or])/gi;

function color256(n: number): string {
  if (n < 16) return ANSI_COLORS[n];
  if (n >= 232) {
    const v = 8 + (n - 232) * 10;
    return `rgb(${v},${v},${v})`;
  }
  const i = n - 16;
  const level = (x: number) => (x === 0 ? 0 : 55 + x * 40);
  return `rgb(${level(Math.floor(i / 36))},${level(Math.floor((i % 36) / 6))},${level(i % 6)})`;
}

function applySgr(style: AnsiStyle, params: string): AnsiStyle {
  const codes = params === '' ? [0] : params.split(';').map((value) => Number(value) || 0);
  let next = { ...style };
  for (let i = 0; i < codes.length; i += 1) {
    const code = codes[i];
    if (code === 0) next = {};
    else if (code === 1) next.bold = true;
    else if (code === 2) next.dim = true;
    else if (code === 3) next.italic = true;
    else if (code === 4) next.underline = true;
    else if (code === 22) { next.bold = false; next.dim = false; }
    else if (code === 23) next.italic = false;
    else if (code === 24) next.underline = false;
    else if (code >= 30 && code <= 37) next.fg = ANSI_COLORS[code - 30];
    else if (code >= 90 && code <= 97) next.fg = ANSI_COLORS[code - 90 + 8];
    else if (code === 39) next.fg = undefined;
    else if (code >= 40 && code <= 47) next.bg = ANSI_COLORS[code - 40];
    else if (code >= 100 && code <= 107) next.bg = ANSI_COLORS[code - 100 + 8];
    else if (code === 49) next.bg = undefined;
    else if (code === 38 || code === 48) {
      const target = code === 38 ? 'fg' : 'bg';
      if (codes[i + 1] === 5 && codes[i + 2] !== undefined) {
        next[target] = color256(codes[i + 2]);
        i += 2;
      } else if (codes[i + 1] === 2 && codes[i + 4] !== undefined) {
        next[target] = `rgb(${codes[i + 2]},${codes[i + 3]},${codes[i + 4]})`;
        i += 4;
      }
    }
  }
  return next;
}

function applyMinecraftCode(style: AnsiStyle, code: string): AnsiStyle {
  const lower = code.toLowerCase();
  if (lower in MC_COLORS) return { fg: MC_COLORS[lower] };
  if (lower === 'l') return { ...style, bold: true };
  if (lower === 'o') return { ...style, italic: true };
  if (lower === 'n') return { ...style, underline: true };
  if (lower === 'r') return {};
  return style;
}

export function stripFormatting(line: string): string {
  return line.replace(ESCAPE_NOISE, '').replace(COLOR_TOKEN, '');
}

function parseLine(line: string, colors: boolean): Segment[] {
  const cleaned = line.replace(ESCAPE_NOISE, '');
  if (!colors) return [{ text: cleaned.replace(COLOR_TOKEN, ''), style: {} }];
  const segments: Segment[] = [];
  let style: AnsiStyle = {};
  let last = 0;
  for (const match of cleaned.matchAll(COLOR_TOKEN)) {
    const index = match.index ?? 0;
    if (index > last) segments.push({ text: cleaned.slice(last, index), style });
    style = match[1] !== undefined ? applySgr(style, match[1]) : applyMinecraftCode(style, match[2]);
    last = index + match[0].length;
  }
  if (last < cleaned.length) segments.push({ text: cleaned.slice(last), style });
  return segments.length ? segments : [{ text: '', style: {} }];
}

const LEVEL_PATTERN = /\b(ERROR|SEVERE|FATAL)\b|\b(WARN|WARNING)\b|\b(INFO)\b|\b(DEBUG|TRACE)\b/g;

function levelColor(match: RegExpMatchArray): string {
  if (match[1]) return '#f87171';
  if (match[2]) return '#fbbf24';
  if (match[3]) return '#38bdf8';
  return '#94a3b8';
}

function renderSegments(segments: Segment[], colors: boolean): ReactNode[] {
  const nodes: ReactNode[] = [];
  segments.forEach((segment, segmentIndex) => {
    const css: CSSProperties = {
      color: segment.style.fg,
      backgroundColor: segment.style.bg,
      fontWeight: segment.style.bold ? 700 : undefined,
      opacity: segment.style.dim ? 0.65 : undefined,
      fontStyle: segment.style.italic ? 'italic' : undefined,
      textDecoration: segment.style.underline ? 'underline' : undefined,
    };
    if (colors && !segment.style.fg) {
      let cursor = 0;
      for (const match of segment.text.matchAll(LEVEL_PATTERN)) {
        const index = match.index ?? 0;
        if (index > cursor) nodes.push(<span key={`${segmentIndex}-${cursor}`} style={css}>{segment.text.slice(cursor, index)}</span>);
        nodes.push(<span key={`${segmentIndex}-${index}`} style={{ ...css, color: levelColor(match), fontWeight: 700 }}>{match[0]}</span>);
        cursor = index + match[0].length;
      }
      if (cursor < segment.text.length) nodes.push(<span key={`${segmentIndex}-${cursor}`} style={css}>{segment.text.slice(cursor)}</span>);
    } else {
      nodes.push(<span key={segmentIndex} style={css}>{segment.text}</span>);
    }
  });
  return nodes;
}

function TerminalLine({ line, colors }: { line: string; colors: boolean }) {
  if (line.startsWith('> ')) {
    return <div className="flex gap-2 py-px"><span className="select-none font-bold text-teal-400">❯</span><span className="min-w-0 break-words font-semibold text-teal-200">{line.slice(2)}</span></div>;
  }
  if (line.startsWith('$ ')) {
    return <div className="py-px italic text-slate-500">{line}</div>;
  }
  if (line.startsWith('[stderr] ')) {
    const rest = line.slice(9);
    return <div className="flex gap-2 py-px"><span className="mt-[3px] h-4 shrink-0 select-none rounded bg-red-500/15 px-1.5 text-[9px] font-bold uppercase leading-4 tracking-wider text-red-300">err</span><span className="min-w-0 whitespace-pre-wrap break-words text-slate-200">{renderSegments(parseLine(rest, colors), colors)}</span></div>;
  }
  return <div className="min-h-5 whitespace-pre-wrap break-words py-px text-slate-200">{renderSegments(parseLine(line, colors), colors)}</div>;
}

/* ------------------------------------------------------------------ */
/* Terminal panel                                                      */
/* ------------------------------------------------------------------ */

type LogsQuery = {
  data: { lines: string[] } | undefined;
  isLoading: boolean;
  isError: boolean;
  isFetching: boolean;
  refetch: () => Promise<unknown>;
};

export function TerminalPanel({ server, logs, readOnly = false, canSend, canClear, canConfigure }: { server: ManagedServer; logs: LogsQuery; readOnly?: boolean; canSend?: boolean; canClear?: boolean; canConfigure?: boolean }) {
  // `readOnly` is a view-only panel; the can* props allow single abilities (for limited users).
  const allowSend = canSend ?? !readOnly;
  const allowClear = canClear ?? !readOnly;
  const allowConfigure = canConfigure ?? !readOnly;
  const queryClient = useQueryClient();
  const settingsQuery = useTerminalSettings(server.id);
  const settings = settingsQuery.data ?? DEFAULT_TERMINAL_SETTINGS;
  const send = useSendServerConsoleCommand();
  const clear = useClearServerLogs();
  const updateInterval = useUpdateServer();
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [intervalDraft, setIntervalDraft] = useState(String(server.logRefreshIntervalSeconds));
  const [command, setCommand] = useState('');
  const [sendError, setSendError] = useState('');
  const [copied, setCopied] = useState(false);
  const [atBottom, setAtBottom] = useState(true);
  const historyRef = useRef<string[]>([]);
  const historyIndexRef = useRef(-1);
  const draftRef = useRef('');
  const stickRef = useRef(true);
  const outputRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => { setIntervalDraft(String(server.logRefreshIntervalSeconds)); }, [server.logRefreshIntervalSeconds]);

  const isMinecraftConsoleClient = useMemo(() => {
    const tokens = server.command.trim().match(/"[^"]*"|'[^']*'|\S+/g) ?? [];
    let index = 0;
    while (index < tokens.length && /^(?:mono|dotnet|exec)$/i.test(tokens[index])) index += 1;
    const baseName = (tokens[index] ?? '').replace(/^["']|["']$/g, '').split(/[\\/]/).pop() ?? '';
    return /^(?:mc\.exe|minecraftclient(?:[-_.].*)?|mcc(?:[-_.].*)?)$/i.test(baseName) || /\bBasicIO(?:-NoColor)?(?:\s|$)/i.test(server.command);
  }, [server.command]);

  const lines = logs.data?.lines ?? [];

  const scrollToBottom = useCallback(() => {
    const output = outputRef.current;
    if (output) output.scrollTop = output.scrollHeight;
    stickRef.current = true;
    setAtBottom(true);
  }, []);

  useEffect(() => {
    if (stickRef.current) {
      const output = outputRef.current;
      if (output) output.scrollTop = output.scrollHeight;
    }
  }, [lines, settings.emulated]);

  const handleScroll = () => {
    const output = outputRef.current;
    if (!output) return;
    const near = output.scrollHeight - output.scrollTop - output.clientHeight < 48;
    stickRef.current = near;
    setAtBottom(near);
  };

  const commitInterval = () => {
    const parsed = Math.round(Number(intervalDraft));
    const next = Number.isFinite(parsed) ? Math.min(300, Math.max(1, parsed)) : server.logRefreshIntervalSeconds;
    setIntervalDraft(String(next));
    if (next === server.logRefreshIntervalSeconds) return;
    updateInterval.mutate({ id: server.id, data: { logRefreshIntervalSeconds: next } }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetServerQueryKey(server.id) });
        queryClient.invalidateQueries({ queryKey: getGetServersQueryKey() });
      },
      onError: () => setIntervalDraft(String(server.logRefreshIntervalSeconds)),
    });
  };

  const submit = (event?: FormEvent) => {
    event?.preventDefault();
    const value = command.trim();
    if (!value || send.isPending) return;
    historyRef.current = [...historyRef.current.filter((item) => item !== value), value].slice(-100);
    historyIndexRef.current = -1;
    setCommand('');
    setSendError('');
    stickRef.current = true;
    send.mutate({ id: server.id, data: { command: value } }, {
      onSuccess: () => { void logs.refetch(); },
      onError: (error) => setSendError(errorMessage(error, 'Command could not be executed.')),
    });
  };

  const onInputKeyDown = (event: KeyboardEvent<HTMLInputElement>) => {
    const history = historyRef.current;
    // The inline prompt has no form around it, so Enter is handled here.
    if (event.key === 'Enter' && settings.emulated && !event.nativeEvent.isComposing) {
      event.preventDefault();
      submit();
      return;
    }
    if (event.key === 'ArrowUp' && history.length) {
      event.preventDefault();
      if (historyIndexRef.current === -1) { draftRef.current = command; historyIndexRef.current = history.length - 1; }
      else historyIndexRef.current = Math.max(0, historyIndexRef.current - 1);
      setCommand(history[historyIndexRef.current]);
    } else if (event.key === 'ArrowDown' && historyIndexRef.current !== -1) {
      event.preventDefault();
      if (historyIndexRef.current >= history.length - 1) { historyIndexRef.current = -1; setCommand(draftRef.current); }
      else { historyIndexRef.current += 1; setCommand(history[historyIndexRef.current]); }
    } else if (event.key === 'Escape') {
      setCommand('');
      historyIndexRef.current = -1;
    }
  };

  const clearLogs = () => {
    if (clear.isPending) return;
    clear.mutate({ id: server.id }, {
      onSuccess: () => { setSendError(''); void logs.refetch(); },
      onError: (error) => setSendError(errorMessage(error, 'Could not clear console output.')),
    });
  };

  const copyOutput = async () => {
    const text = lines.map(stripFormatting).join('\n');
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const area = document.createElement('textarea');
      area.value = text;
      document.body.appendChild(area);
      area.select();
      document.execCommand('copy');
      area.remove();
    }
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1500);
  };

  const focusInput = () => {
    if (window.getSelection()?.toString()) return;
    inputRef.current?.focus();
  };

  const placeholder = isMinecraftConsoleClient ? 'Chat message or /command' : 'Type a command and press Enter';
  const online = server.status === 'online';

  const iconButton = 'grid size-8 place-items-center rounded-lg text-slate-400 transition hover:bg-white/10 hover:text-white disabled:opacity-50';

  const promptInput = (
    <input
      ref={inputRef}
      value={command}
      onChange={(event) => { setCommand(event.target.value); historyIndexRef.current = -1; }}
      onKeyDown={onInputKeyDown}
      readOnly={send.isPending}
      placeholder={placeholder}
      autoCapitalize="off"
      autoComplete="off"
      autoCorrect="off"
      spellCheck={false}
      enterKeyHint="send"
      aria-label="Console command"
      className="min-w-0 flex-1 bg-transparent font-mono text-[12px] text-teal-100 caret-teal-300 outline-none placeholder:text-slate-600"
      data-testid="input-console-command"
    />
  );

  return <section className="overflow-hidden rounded-xl border border-slate-700/60 bg-[#121920] text-slate-100 shadow-[0_8px_30px_hsl(218_36%_8%/.35)]" data-testid="panel-terminal">
    <div className="flex flex-wrap items-center gap-x-3 gap-y-2 border-b border-white/5 bg-[#1a232d] px-4 py-3">
      <div className="flex min-w-0 flex-1 basis-48 items-center gap-3">
        <div className="hidden gap-1.5 sm:flex" aria-hidden="true"><span className="size-3 rounded-full bg-red-400/80" /><span className="size-3 rounded-full bg-amber-300/80" /><span className="size-3 rounded-full bg-emerald-400/80" /></div>
        <div className="min-w-0">
          <div className="flex items-center gap-2"><span className={`status-dot ${online ? 'bg-emerald-400' : 'bg-slate-500'}`} /><h3 className="font-bold leading-none">Terminal</h3></div>
          <p className="mt-1 truncate text-[11px] text-slate-400">{isMinecraftConsoleClient ? 'MCC: text goes to game chat · /command runs an MCC command' : `Refreshes every ${server.logRefreshIntervalSeconds}s · ${online ? 'running' : 'stopped'}${allowSend ? '' : ' · view only'}`}</p>
        </div>
      </div>
      <div className="flex items-center gap-1">
        <label className="mr-1 flex items-center gap-1.5 text-[11px] text-slate-400" title="Terminal refresh interval in seconds (1–300)">Refresh<input type="number" min={1} max={300} value={intervalDraft} onChange={(event) => setIntervalDraft(event.target.value)} onBlur={commitInterval} onKeyDown={(event) => { if (event.key === 'Enter') { event.preventDefault(); commitInterval(); } }} aria-label="Terminal refresh interval in seconds" className="h-8 w-14 rounded-md border border-slate-600 bg-slate-900/60 px-2 text-center font-mono text-xs text-white outline-none focus:border-teal-400" data-testid="input-log-refresh-interval" />s</label>
        <button onClick={copyOutput} className={iconButton} aria-label="Copy output" title="Copy output" data-testid="button-copy-logs">{copied ? <Check className="size-4 text-emerald-300" /> : <Copy className="size-4" />}</button>
        {allowClear && <button onClick={clearLogs} disabled={clear.isPending} className={`${iconButton} hover:text-red-300`} aria-label="Clear console logs" title="Clear" data-testid="button-clear-logs">{clear.isPending ? <LoaderCircle className="size-4 animate-spin" /> : <Trash2 className="size-4" />}</button>}
        <button onClick={() => logs.refetch()} className={iconButton} aria-label="Refresh logs" title="Refresh" data-testid="button-refresh-logs"><RefreshCw className={`size-4 ${logs.isFetching ? 'animate-spin' : ''}`} /></button>
        {allowConfigure && <button onClick={() => setSettingsOpen(true)} className={iconButton} aria-label="Terminal settings" title="Terminal settings" data-testid="button-terminal-settings"><Settings className="size-4" /></button>}
      </div>
    </div>

    <div className="relative">
      <div ref={outputRef} onScroll={handleScroll} onClick={settings.emulated && allowSend ? focusInput : undefined} className="max-h-[55dvh] min-h-[260px] cursor-text overflow-y-auto overscroll-contain px-4 py-3 font-mono text-[12px] leading-5 sm:max-h-[460px] sm:px-5" data-testid="logs-scroll-viewport">
        {logs.isLoading ? <div className="space-y-3 py-2"><div className="skeleton h-4 bg-slate-700" /><div className="skeleton h-4 w-2/3 bg-slate-700" /><div className="skeleton h-4 w-1/2 bg-slate-700" /></div>
          : logs.isError ? <div className="py-4 text-sm text-slate-400">Logs are unavailable right now. <button onClick={() => logs.refetch()} className="font-bold text-teal-300 hover:underline">Try again</button></div>
            : lines.length ? <div data-testid="logs-output">{lines.map((line, index) => <TerminalLine key={index} line={line} colors={settings.colors} />)}</div>
              : <div className="grid min-h-[200px] place-items-center text-center text-sm text-slate-500" data-testid="empty-logs"><div><FileCode2 className="mx-auto size-7 opacity-60" /><p className="mt-3">No output yet. Start the server to see its console here.</p></div></div>}
        {settings.emulated && allowSend && <div className="mt-1 flex items-center gap-2 py-px"><span className="select-none font-bold text-teal-400">❯</span>{promptInput}{send.isPending && <LoaderCircle className="size-3.5 animate-spin text-slate-500" />}</div>}
      </div>
      {!atBottom && <button onClick={scrollToBottom} className="absolute bottom-3 right-4 inline-flex items-center gap-1.5 rounded-full border border-slate-600 bg-slate-800/95 px-3 py-1.5 text-[11px] font-bold text-slate-200 shadow-lg hover:bg-slate-700" data-testid="button-scroll-bottom"><ArrowDown className="size-3.5" />Latest</button>}
    </div>

    {!settings.emulated && allowSend && <form onSubmit={submit} className="flex gap-2 border-t border-white/5 bg-[#1a232d] p-3 sm:p-4">
      <div className="flex min-w-0 flex-1 items-center gap-2 rounded-lg border border-slate-600 bg-slate-900/60 px-3 py-2"><span className="select-none font-mono font-bold text-teal-400">❯</span>{promptInput}</div>
      <button type="submit" disabled={!command.trim() || send.isPending} aria-label="Send" className="inline-flex h-10 shrink-0 items-center justify-center gap-2 rounded-lg bg-teal-400 px-3 text-sm font-bold text-slate-950 transition hover:bg-teal-300 disabled:pointer-events-none disabled:opacity-50 sm:px-4" data-testid="button-send-command">{send.isPending ? <LoaderCircle className="size-4 animate-spin" /> : <ChevronDown className="size-4 -rotate-90" />}<span className="hidden sm:inline">Send</span></button>
    </form>}
    {sendError && <p className="border-t border-red-500/20 bg-red-500/10 px-4 py-2 text-xs text-red-300" role="alert" data-testid="text-terminal-error">{sendError}</p>}

    {settingsOpen && allowConfigure && <TerminalSettingsDialog serverId={server.id} settings={settings} onClose={() => setSettingsOpen(false)} />}
  </section>;
}

/* ------------------------------------------------------------------ */
/* Settings dialog                                                     */
/* ------------------------------------------------------------------ */

function SettingBlock({ title, description, children }: { title: string; description: string; children: ReactNode }) {
  return <div className="space-y-3 border-b border-slate-700/60 pb-6 last:border-b-0 last:pb-0">
    <h3 className="text-lg font-bold text-white">{title}</h3>
    <p className="text-sm leading-6 text-slate-400">{description}</p>
    {children}
  </div>;
}

function Switch({ checked, onChange, label, testId }: { checked: boolean; onChange: (value: boolean) => void; label: string; testId: string }) {
  return <button type="button" role="switch" aria-checked={checked} aria-label={label} onClick={() => onChange(!checked)} className={`relative h-8 w-14 rounded-full transition ${checked ? 'bg-blue-600' : 'bg-slate-600'}`} data-testid={testId}><span className={`absolute left-1 top-1 size-6 rounded-full bg-white shadow transition-transform ${checked ? 'translate-x-6' : 'translate-x-0'}`} /></button>;
}

const selectClass = 'h-12 w-full rounded-xl border border-slate-600 bg-[#121920] px-4 text-sm text-white outline-none focus:border-blue-500';

function TerminalSettingsDialog({ serverId, settings, onClose }: { serverId: number; settings: TerminalSettings; onClose: () => void }) {
  const queryClient = useQueryClient();
  const [draft, setDraft] = useState<TerminalSettings>(settings);
  const [error, setError] = useState('');
  const save = useMutation({
    mutationFn: (value: TerminalSettings) => customFetch<TerminalSettings>(`/api/servers/${serverId}/terminal-settings`, { method: 'PUT', body: JSON.stringify(value) }),
    onSuccess: (value) => { queryClient.setQueryData(settingsKey(serverId), value); onClose(); },
    onError: (err) => setError(errorMessage(err, 'Could not save terminal settings.')),
  });

  useEffect(() => {
    const onKey = (event: globalThis.KeyboardEvent) => { if (event.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    const previous = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => { window.removeEventListener('keydown', onKey); document.body.style.overflow = previous; };
  }, [onClose]);

  const update = <K extends keyof TerminalSettings>(key: K, value: TerminalSettings[K]) => setDraft((current) => ({ ...current, [key]: value }));

  return createPortal(
    <div className="fixed inset-0 z-[70] grid place-items-center bg-black/60 p-3 backdrop-blur-sm sm:p-6" role="dialog" aria-modal="true" aria-label="Terminal settings" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }} data-testid="dialog-terminal-settings">
      <div className="flex max-h-[92dvh] w-full max-w-xl flex-col overflow-hidden rounded-2xl border border-slate-700 bg-[#1e1e1e] text-slate-100 shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-700/70 px-6 py-4"><h2 className="text-xl font-bold">Terminal Settings</h2><button onClick={onClose} className="grid size-9 place-items-center rounded-lg text-slate-400 hover:bg-white/10 hover:text-white" aria-label="Close"><X className="size-5" /></button></div>
        <div className="space-y-6 overflow-y-auto px-6 py-6">
          <SettingBlock title="Emulated Terminal" description="Shows the command prompt inside the terminal, like a real shell, with command history (↑ / ↓). When off, a separate input bar with a Send button is used.">
            <Switch checked={draft.emulated} onChange={(value) => update('emulated', value)} label="Emulated terminal" testId="switch-terminal-emulated" />
          </SettingBlock>
          <SettingBlock title="Color Processing" description="Renders ANSI and Minecraft (§) colour codes and highlights log levels such as INFO, WARN and ERROR. Turn it off to show plain text.">
            <Switch checked={draft.colors} onChange={(value) => update('colors', value)} label="Color processing" testId="switch-terminal-colors" />
          </SettingBlock>
          <SettingBlock title="Command Line Ending" description="If the app does not react when you press Enter, try another option. Windows programs usually expect CRLF (\r\n), Linux and macOS programs LF (\n).">
            <select value={draft.lineEnding} onChange={(event) => update('lineEnding', event.target.value as TerminalSettings['lineEnding'])} className={selectClass} data-testid="select-terminal-line-ending">{LINE_ENDING_OPTIONS.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}</select>
          </SettingBlock>
          <SettingBlock title="Stop Command" description="Used by the Stop button. ^C sends Ctrl+C (SIGINT). Any other text, for example stop or end, is typed into the console, and the process is terminated if it has not exited in 20 seconds. SIGTERM, SIGHUP and SIGQUIT are also accepted.">
            <input value={draft.stopCommand} onChange={(event) => update('stopCommand', event.target.value)} maxLength={120} className="h-12 w-full rounded-xl border border-slate-600 bg-[#121920] px-4 font-mono text-sm text-white outline-none focus:border-blue-500" data-testid="input-terminal-stop-command" />
          </SettingBlock>
          <SettingBlock title="Input and Output Encoding" description="If the console shows garbled text, change the output encoding. The output encoding is applied the next time the server starts. Input supports the encodings listed below.">
            <label className="block space-y-1.5"><span className="text-xs font-bold uppercase tracking-wider text-slate-500">Input</span><select value={draft.inputEncoding} onChange={(event) => update('inputEncoding', event.target.value)} className={selectClass} data-testid="select-terminal-input-encoding">{INPUT_ENCODING_OPTIONS.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}</select></label>
            <label className="block space-y-1.5"><span className="text-xs font-bold uppercase tracking-wider text-slate-500">Output</span><select value={draft.outputEncoding} onChange={(event) => update('outputEncoding', event.target.value)} className={selectClass} data-testid="select-terminal-output-encoding">{OUTPUT_ENCODING_OPTIONS.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}</select></label>
          </SettingBlock>
          {error && <p className="rounded-lg bg-red-500/10 px-3 py-2 text-sm text-red-300" role="alert" data-testid="text-terminal-settings-error">{error}</p>}
        </div>
        <div className="flex justify-end gap-3 border-t border-slate-700/70 px-6 py-4">
          <button onClick={onClose} className="h-11 rounded-xl border border-slate-600 px-5 text-sm font-semibold text-slate-200 hover:bg-white/5" data-testid="button-terminal-settings-cancel">Cancel</button>
          <button onClick={() => { setError(''); save.mutate(draft); }} disabled={save.isPending || !draft.stopCommand.trim()} className="inline-flex h-11 items-center gap-2 rounded-xl bg-blue-600 px-6 text-sm font-bold text-white hover:bg-blue-500 disabled:opacity-60" data-testid="button-terminal-settings-save">{save.isPending && <LoaderCircle className="size-4 animate-spin" />}Save</button>
        </div>
      </div>
    </div>,
    document.body,
  );
}
