import { useCallback, useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Compartment, EditorState, type Extension } from '@codemirror/state';
import { EditorView, keymap } from '@codemirror/view';
import { basicSetup } from 'codemirror';
import { indentWithTab } from '@codemirror/commands';
import { openSearchPanel, search } from '@codemirror/search';
import { ensureSyntaxTree, indentUnit, syntaxTree } from '@codemirror/language';
import { diagnosticCount, linter, lintGutter, nextDiagnostic, type Diagnostic } from '@codemirror/lint';
import { oneDark } from '@codemirror/theme-one-dark';
import { javascript } from '@codemirror/lang-javascript';
import { json, jsonParseLinter } from '@codemirror/lang-json';
import { html } from '@codemirror/lang-html';
import { css } from '@codemirror/lang-css';
import { markdown } from '@codemirror/lang-markdown';
import { python } from '@codemirror/lang-python';
import { yaml } from '@codemirror/lang-yaml';
import { AlertTriangle, LoaderCircle, Save, Search, TextCursorInput, WrapText, X } from 'lucide-react';

type LanguageInfo = { label: string; extensions: Extension[] };

// Marks the parts of the document the parser could not understand with a red wavy underline.
function syntaxErrorLinter() {
  return linter((view) => {
    const diagnostics: Diagnostic[] = [];
    const length = view.state.doc.length;
    const tree = ensureSyntaxTree(view.state, length, 300) ?? syntaxTree(view.state);
    tree.iterate({
      enter: (node) => {
        if (!node.type.isError || diagnostics.length >= 100) return;
        let from = node.from;
        let to = node.to;
        if (to <= from) {
          to = Math.min(from + 1, length);
          if (to <= from) { from = Math.max(0, from - 1); to = length; }
        }
        if (to > from) diagnostics.push({ from, to, severity: 'error', message: 'Syntax error' });
      },
    });
    return diagnostics;
  }, { delay: 400 });
}

function languageFor(path: string): LanguageInfo {
  const name = path.split('/').pop()?.toLowerCase() ?? '';
  const ext = name.includes('.') ? name.split('.').pop() ?? '' : '';
  switch (ext) {
    case 'js': case 'mjs': case 'cjs': return { label: 'JavaScript', extensions: [javascript(), syntaxErrorLinter()] };
    case 'jsx': return { label: 'JSX', extensions: [javascript({ jsx: true }), syntaxErrorLinter()] };
    case 'ts': return { label: 'TypeScript', extensions: [javascript({ typescript: true }), syntaxErrorLinter()] };
    case 'tsx': return { label: 'TSX', extensions: [javascript({ typescript: true, jsx: true }), syntaxErrorLinter()] };
    case 'json': return { label: 'JSON', extensions: [json(), linter(jsonParseLinter(), { delay: 400 })] };
    case 'html': case 'htm': return { label: 'HTML', extensions: [html(), syntaxErrorLinter()] };
    case 'css': return { label: 'CSS', extensions: [css(), syntaxErrorLinter()] };
    case 'md': case 'markdown': return { label: 'Markdown', extensions: [markdown()] };
    case 'py': return { label: 'Python', extensions: [python(), syntaxErrorLinter()] };
    case 'yml': case 'yaml': return { label: 'YAML', extensions: [yaml(), syntaxErrorLinter()] };
    default: return { label: 'Plain text', extensions: [] };
  }
}

const editorTheme = EditorView.theme({
  '&': { height: '100%', fontSize: '13px' },
  '.cm-scroller': { fontFamily: "ui-monospace, SFMono-Regular, Menlo, Consolas, 'Liberation Mono', monospace", lineHeight: '1.6', overflow: 'auto' },
  '.cm-gutters': { borderRight: '1px solid rgba(255,255,255,.06)' },
  '.cm-lintRange-error': { backgroundImage: 'none', textDecoration: 'underline wavy #ef4444', textDecorationSkipInk: 'none', textUnderlineOffset: '3px' },
  '.cm-panels': { zIndex: '5' },
  '@media (max-width: 640px)': {
    '&': { fontSize: '14px' },
    '.cm-panels input, .cm-panels button, .cm-panels label': { fontSize: '16px' },
    '.cm-panels input[type=text]': { minHeight: '38px' },
    '.cm-panels button': { minHeight: '34px' },
  },
});

export type CodeEditorDialogProps = {
  path: string;
  loading: boolean;
  loadError: boolean;
  onRetry: () => void;
  initialContent: string | null;
  saving: boolean;
  onSave: (content: string) => Promise<void>;
  onDirtyChange: (dirty: boolean) => void;
  onClose: () => void;
  readOnly?: boolean;
};

export function CodeEditorDialog({ path, loading, loadError, onRetry, initialContent, saving, onSave, onDirtyChange, onClose, readOnly = false }: CodeEditorDialogProps) {
  const hostRef = useRef<HTMLDivElement>(null);
  const viewRef = useRef<EditorView | null>(null);
  const wrapCompartment = useRef(new Compartment());
  const savedTextRef = useRef('');
  const saveRef = useRef<() => void>(() => undefined);
  const dirtyRef = useRef(false);
  const language = languageFor(path);
  const languageLabel = language.label;
  const [dirty, setDirty] = useState(false);
  const [wrap, setWrap] = useState(() => typeof window !== 'undefined' && window.innerWidth < 640);
  const [cursor, setCursor] = useState({ line: 1, column: 1, lines: 1 });
  const [problems, setProblems] = useState(0);
  const [saveError, setSaveError] = useState('');

  const fileName = path.split('/').pop() ?? path;
  const folder = path.includes('/') ? path.slice(0, path.lastIndexOf('/')) : '';

  const updateDirty = useCallback((next: boolean) => {
    if (dirtyRef.current === next) return;
    dirtyRef.current = next;
    setDirty(next);
    onDirtyChange(next);
  }, [onDirtyChange]);

  const doSave = useCallback(async () => {
    const view = viewRef.current;
    if (!view || saving) return;
    const text = view.state.doc.toString();
    setSaveError('');
    try {
      await onSave(text);
      savedTextRef.current = text;
      updateDirty(view.state.doc.toString() !== text);
    } catch (error) {
      setSaveError(error instanceof Error ? error.message : 'Could not save this file.');
    }
  }, [onSave, saving, updateDirty]);

  useEffect(() => { saveRef.current = () => { void doSave(); }; }, [doSave]);

  // Build the editor once the file content has arrived.
  useEffect(() => {
    if (initialContent === null || !hostRef.current) return undefined;
    savedTextRef.current = initialContent;
    const state = EditorState.create({
      doc: initialContent,
      extensions: [
        basicSetup,
        EditorState.readOnly.of(readOnly),
        search({ top: true }),
        lintGutter(),
        oneDark,
        editorTheme,
        indentUnit.of('  '),
        keymap.of([
          { key: 'Mod-s', preventDefault: true, run: () => { saveRef.current(); return true; } },
          indentWithTab,
        ]),
        wrapCompartment.current.of(window.innerWidth < 640 ? EditorView.lineWrapping : []),
        ...language.extensions,
        EditorView.updateListener.of((update) => {
          if (update.docChanged) {
            const doc = update.state.doc;
            const saved = savedTextRef.current;
            updateDirty(doc.length !== saved.length || doc.toString() !== saved);
          }
          if (update.selectionSet || update.docChanged) {
            const head = update.state.selection.main.head;
            const line = update.state.doc.lineAt(head);
            setCursor({ line: line.number, column: head - line.from + 1, lines: update.state.doc.lines });
          }
          setProblems(diagnosticCount(update.state));
        }),
      ],
    });
    const view = new EditorView({ state, parent: hostRef.current });
    viewRef.current = view;
    setCursor({ line: 1, column: 1, lines: state.doc.lines });
    updateDirty(false);
    return () => { view.destroy(); viewRef.current = null; };
    // The editor is created once per opened file.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialContent === null, path]);

  useEffect(() => {
    viewRef.current?.dispatch({ effects: wrapCompartment.current.reconfigure(wrap ? EditorView.lineWrapping : []) });
  }, [wrap, initialContent]);

  useEffect(() => {
    const previous = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = previous; };
  }, []);

  useEffect(() => {
    const onBeforeUnload = (event: BeforeUnloadEvent) => { if (dirtyRef.current) { event.preventDefault(); event.returnValue = ''; } };
    window.addEventListener('beforeunload', onBeforeUnload);
    return () => window.removeEventListener('beforeunload', onBeforeUnload);
  }, []);

  const barButton = 'inline-flex h-9 items-center justify-center gap-1.5 rounded-lg border border-white/10 px-3 text-xs font-semibold text-slate-200 transition hover:bg-white/10 disabled:opacity-50';

  return createPortal(
    <div className="fixed inset-0 z-[90] flex h-[100dvh] flex-col bg-[#21252b] text-slate-100" role="dialog" aria-modal="true" aria-label={`Editing ${fileName}`} data-testid="file-editor">
      <div className="flex flex-wrap items-center gap-x-3 gap-y-2 border-b border-white/10 bg-[#282c34] px-3 py-2.5 sm:px-4">
        <div className="min-w-0 flex-1 basis-40">
          <p className="flex items-center gap-2 truncate text-sm font-bold"><span className="truncate">{fileName}</span>{readOnly && <span className="shrink-0 rounded-full bg-slate-400/15 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-slate-300" data-testid="text-editor-readonly">Read only</span>}{dirty && <span className="shrink-0 rounded-full bg-amber-400/15 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-amber-300" data-testid="text-editor-unsaved">Unsaved</span>}</p>
          <p className="mono truncate text-[11px] text-slate-500">{folder || '/'}</p>
        </div>
        <div className="flex items-center gap-1.5">
          <button onClick={() => viewRef.current && openSearchPanel(viewRef.current)} disabled={initialContent === null} className={barButton} title="Search and replace (Ctrl+F)" data-testid="button-editor-search"><Search className="size-4" /><span className="hidden sm:inline">Search</span></button>
          <button onClick={() => { const view = viewRef.current; if (view) { nextDiagnostic(view); view.focus(); } }} disabled={initialContent === null || problems === 0} className={`${barButton} ${problems ? 'border-red-500/40 text-red-300' : ''}`} title="Jump to the next error" data-testid="button-editor-next-error"><AlertTriangle className="size-4" />{problems}<span className="hidden sm:inline">{problems === 1 ? 'error' : 'errors'}</span></button>
          <button onClick={() => setWrap((value) => !value)} aria-pressed={wrap} className={`${barButton} ${wrap ? 'bg-white/10' : ''}`} title="Wrap long lines" data-testid="button-editor-wrap"><WrapText className="size-4" /><span className="hidden sm:inline">Wrap</span></button>
          {!readOnly && <button onClick={() => void doSave()} disabled={saving || !dirty || initialContent === null} className="inline-flex h-9 items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 text-xs font-bold text-white transition hover:bg-blue-500 disabled:opacity-50" title="Save (Ctrl+S)" data-testid="button-save-file-content">{saving ? <LoaderCircle className="size-4 animate-spin" /> : <Save className="size-4" />}Save</button>}
          <button onClick={onClose} className="grid size-9 place-items-center rounded-lg text-slate-400 hover:bg-white/10 hover:text-white" aria-label="Close editor" title="Close" data-testid="button-close-file-editor"><X className="size-5" /></button>
        </div>
      </div>

      {saveError && <p className="border-b border-red-500/30 bg-red-500/10 px-4 py-2 text-xs text-red-300" role="alert" data-testid="text-editor-save-error">{saveError}</p>}

      <div className="relative min-h-0 flex-1">
        {loading ? <div className="space-y-3 p-5" data-testid="state-file-content-loading"><div className="skeleton h-5 w-1/3 rounded bg-slate-700" /><div className="skeleton h-56 rounded-lg bg-slate-700" /></div>
          : loadError ? <div className="grid h-full place-items-center p-6 text-center text-sm text-slate-400"><div><p>This file could not be opened as UTF-8 text.</p><button onClick={onRetry} className="mt-3 font-bold text-teal-300 hover:underline">Try again</button></div></div>
            : <div ref={hostRef} className="h-full" data-testid="input-file-content" />}
      </div>

      <div className="flex flex-wrap items-center justify-between gap-x-4 gap-y-1 border-t border-white/10 bg-[#282c34] px-4 py-1.5 text-[11px] text-slate-400">
        <span className="inline-flex items-center gap-1.5"><TextCursorInput className="size-3.5" />Ln {cursor.line}, Col {cursor.column}</span>
        <span>{cursor.lines.toLocaleString()} lines · {languageLabel} · UTF-8</span>
      </div>
    </div>,
    document.body,
  );
}
