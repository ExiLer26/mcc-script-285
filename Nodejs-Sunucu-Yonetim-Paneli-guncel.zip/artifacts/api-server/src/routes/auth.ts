import { Router, type IRouter } from "express";
import { asc, eq } from "drizzle-orm";
import { db, adminsTable, panelUsersTable } from "@workspace/db";
import {
  CreateInitialAdminBody,
  CreateInitialAdminResponse,
  GetCurrentAdminResponse,
  GetSetupStatusResponse,
  LoginBody,
  LoginResponse,
} from "@workspace/api-zod";
import {
  createPasswordRecord,
  createSession,
  createUserSession,
  deleteSession,
  ensureUserTables,
  getSessionPrincipal,
  publicAdmin,
  publicUser,
  SESSION_COOKIE,
  verifyPassword,
} from "../lib/auth";
import { PERMISSIONS } from "../lib/permissions";
import { requireAuth } from "../middlewares/auth";

const router: IRouter = Router();

function setSessionCookie(res: Parameters<Parameters<IRouter["post"]>[1]>[1], token: string): void {
  res.cookie(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 1000 * 60 * 60 * 24 * 14,
    path: "/",
  });
}

router.get("/setup/status", async (_req, res): Promise<void> => {
  const [admin] = await db.select({ id: adminsTable.id }).from(adminsTable).orderBy(asc(adminsTable.id)).limit(1);
  res.json(GetSetupStatusResponse.parse({ needsSetup: !admin }));
});

router.post("/setup/admin", async (req, res): Promise<void> => {
  const parsed = CreateInitialAdminBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [existing] = await db.select({ id: adminsTable.id }).from(adminsTable).limit(1);
  if (existing) {
    res.status(409).json({ error: "Initial admin already exists" });
    return;
  }
  const password = createPasswordRecord(parsed.data.password);
  const [admin] = await db.insert(adminsTable).values({
    username: parsed.data.username.trim().toLowerCase(),
    displayName: parsed.data.displayName.trim(),
    passwordHash: password.hash,
    passwordSalt: password.salt,
  }).returning();
  const token = await createSession(admin.id);
  setSessionCookie(res, token);
  res.status(201).json(CreateInitialAdminResponse.parse({ admin: publicAdmin(admin) }));
});

router.post("/auth/login", async (req, res): Promise<void> => {
  const parsed = LoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const username = parsed.data.username.trim().toLowerCase();
  const [admin] = await db.select().from(adminsTable).where(eq(adminsTable.username, username)).limit(1);
  if (admin) {
    if (!verifyPassword(parsed.data.password, admin.passwordSalt, admin.passwordHash)) {
      res.status(401).json({ error: "Username or password is incorrect" });
      return;
    }
    const token = await createSession(admin.id);
    setSessionCookie(res, token);
    res.json(LoginResponse.parse({ admin: publicAdmin(admin) }));
    return;
  }

  // Not an administrator: try the limited accounts created in Settings > New User.
  try {
    await ensureUserTables();
    const [user] = await db.select().from(panelUsersTable).where(eq(panelUsersTable.username, username)).limit(1);
    if (!user || user.disabled || !verifyPassword(parsed.data.password, user.passwordSalt, user.passwordHash)) {
      res.status(401).json({ error: "Username or password is incorrect" });
      return;
    }
    const token = await createUserSession(user.id);
    setSessionCookie(res, token);
    res.json(LoginResponse.parse({ admin: publicUser(user) }));
  } catch {
    res.status(401).json({ error: "Username or password is incorrect" });
  }
});

router.post("/auth/logout", async (req, res): Promise<void> => {
  await deleteSession(req.cookies?.[SESSION_COOKIE]);
  res.clearCookie(SESSION_COOKIE, { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", path: "/" });
  res.sendStatus(204);
});

router.get("/auth/me", requireAuth, async (req, res): Promise<void> => {
  const principal = await getSessionPrincipal(req.cookies?.[SESSION_COOKIE]);
  if (!principal) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }
  res.json(GetCurrentAdminResponse.parse(principal.kind === "admin" ? publicAdmin(principal.admin) : publicUser(principal.user)));
});

// What the signed-in account may see and do. The interface hides what it cannot use;
// the server enforces the same rules on every request.
router.get("/auth/access", requireAuth, async (req, res): Promise<void> => {
  const principal = await getSessionPrincipal(req.cookies?.[SESSION_COOKIE]);
  if (!principal) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }
  if (principal.kind === "admin") {
    res.json({ role: "admin", permissions: [...PERMISSIONS], allServers: true, serverIds: [] });
    return;
  }
  res.json({ role: "user", permissions: principal.access.permissions, allServers: principal.access.allServers, serverIds: principal.access.serverIds });
});

export default router;
