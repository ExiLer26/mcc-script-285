import { Router, type IRouter } from "express";
import { rm } from "node:fs/promises";
import { desc, eq } from "drizzle-orm";
import {
  CreateServerBody,
  CreateServerResponse,
  ClearServerLogsParams,
  DeleteServerParams,
  GetServerLogsParams,
  GetServerLogsQueryParams,
  GetServerLogsResponse,
  GetServerParams,
  GetServerResponse,
  GetServersResponse,
  KillServerParams,
  KillServerResponse,
  SendServerConsoleCommandBody,
  SendServerConsoleCommandParams,
  SendServerConsoleCommandResponse,
  StartServerParams,
  StartServerResponse,
  StopServerParams,
  StopServerResponse,
  RestartServerParams,
  RestartServerResponse,
  UpdateServerBody,
  UpdateServerParams,
  UpdateServerResponse,
} from "@workspace/api-zod";
import { db, activityTable, serversTable, type ManagedServer } from "@workspace/db";
import { requireAuth, type AuthenticatedRequest } from "../middlewares/auth";
import { formatServer } from "./dashboard";
import { clearManagedProcess, clearProcessLogLines, getProcessLines, killManagedProcess, sendManagedProcessInput, stopManagedProcess } from "../lib/process-manager";
import { startManagedServerProcess } from "../lib/server-lifecycle";
import { getStopOptions, getTerminalSettings, LINE_ENDINGS } from "../lib/terminal-settings";
import { clearCrashStartRetryState } from "../lib/server-lifecycle";
import { cancelScheduledAutoStart } from "../lib/auto-start";
import {
  createManagedServerDirectory,
  isManagedServerDirectory,
  prepareManualServerDirectory,
  ServerDirectoryInvalidError,
  removeStagedManagedServerDirectory,
  restoreManagedServerDirectory,
  ServerDirectoryConflictError,
  stageManagedServerDirectoryDeletion,
} from "../lib/server-directories";

const router: IRouter = Router();
router.use(requireAuth);

async function findServer(id: number) {
  const [server] = await db.select().from(serversTable).where(eq(serversTable.id, id)).limit(1);
  return server;
}

async function addActivity(message: string, kind: "info" | "success" | "warning" | "error"): Promise<void> {
  await db.insert(activityTable).values({ message, kind });
}

router.get("/servers", async (req, res): Promise<void> => {
  const auth = (req as AuthenticatedRequest).auth;
  let servers = await db.select().from(serversTable).orderBy(desc(serversTable.updatedAt));
  if (auth.kind === "user" && !auth.access.allServers) {
    servers = servers.filter((server) => auth.access.serverIds.includes(server.id));
  }
  res.json(GetServersResponse.parse(servers.map(formatServer)));
});

// Tells the delete dialog whether the folder is deleted together with the server.
router.get("/servers/:id/folder-info", async (req, res): Promise<void> => {
  const id = Number(req.params.id);
  const [server] = Number.isInteger(id) && id > 0 ? await db.select().from(serversTable).where(eq(serversTable.id, id)).limit(1) : [];
  if (!server) {
    res.status(404).json({ error: "Server not found" });
    return;
  }
  res.json({ directory: server.directory, managed: isManagedServerDirectory(server.directory) });
});

router.post("/servers", async (req, res): Promise<void> => {
  const parsed = CreateServerBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const name = parsed.data.name.trim();
  if (name.length < 2) {
    res.status(400).json({ error: "Server name must be at least 2 characters." });
    return;
  }

  // The form can also let the administrator choose the folder (these two fields are not part of
  // the generated request schema, so they are read from the raw body).
  const rawBody = (req.body ?? {}) as { directoryMode?: unknown; directoryPath?: unknown };
  const manualFolder = rawBody.directoryMode === "manual";

  let directory: string;
  let removableOnFailure = true;
  try {
    if (manualFolder) {
      const prepared = await prepareManualServerDirectory(typeof rawBody.directoryPath === "string" ? rawBody.directoryPath : "");
      directory = prepared.directory;
      removableOnFailure = prepared.created;
      const [existing] = await db.select({ id: serversTable.id }).from(serversTable).where(eq(serversTable.directory, directory)).limit(1);
      if (existing) {
        if (prepared.created) await rm(directory, { recursive: true, force: true }).catch(() => undefined);
        res.status(409).json({ error: "This folder is already used by another server." });
        return;
      }
    } else {
      directory = await createManagedServerDirectory(name);
    }
  } catch (error) {
    if (error instanceof ServerDirectoryConflictError) {
      res.status(409).json({ error: error.message });
      return;
    }
    if (error instanceof ServerDirectoryInvalidError) {
      res.status(400).json({ error: error.message });
      return;
    }
    throw error;
  }

  let server: ManagedServer;
  try {
    const [created] = await db.insert(serversTable).values({
      name,
      description: parsed.data.description.trim(),
      directory,
      command: parsed.data.command.trim(),
      port: parsed.data.port ?? null,
      autoStart: parsed.data.autoStart ?? false,
      autoStartDelaySeconds: parsed.data.autoStartDelaySeconds ?? 5,
      crashStart: parsed.data.crashStart ?? false,
      crashStartDelaySeconds: parsed.data.crashStartDelaySeconds ?? 5,
      logRefreshIntervalSeconds: parsed.data.logRefreshIntervalSeconds ?? 10,
    }).returning();
    if (!created) throw new Error("Could not persist the server configuration.");
    server = created;
  } catch (error) {
    // Only remove a folder that this request just created; an existing folder is never touched.
    if (removableOnFailure) await rm(directory, { recursive: true, force: true });
    throw error;
  }
  await addActivity(`${server.name} added to the fleet`, "success");
  res.status(201).json(CreateServerResponse.parse(formatServer(server)));
});

router.get("/servers/:id", async (req, res): Promise<void> => {
  const parsed = GetServerParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const server = await findServer(parsed.data.id);
  if (!server) {
    res.status(404).json({ error: "Server not found" });
    return;
  }
  res.json(GetServerResponse.parse(formatServer(server)));
});

router.patch("/servers/:id", async (req, res): Promise<void> => {
  const params = UpdateServerParams.safeParse(req.params);
  const body = UpdateServerBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const existing = await findServer(params.data.id);
  if (!existing) {
    res.status(404).json({ error: "Server not found" });
    return;
  }
  const [server] = await db.update(serversTable).set({
    ...body.data,
    name: body.data.name?.trim(),
    description: body.data.description?.trim(),
    command: body.data.command?.trim(),
    updatedAt: new Date(),
  }).where(eq(serversTable.id, params.data.id)).returning();
  if (body.data.autoStart === false) cancelScheduledAutoStart(server.id);
  if (body.data.crashStart === false) clearCrashStartRetryState(server.id);
  await addActivity(`${server.name} configuration updated`, "info");
  res.json(UpdateServerResponse.parse(formatServer(server)));
});

router.delete("/servers/:id", async (req, res): Promise<void> => {
  const params = DeleteServerParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const server = await findServer(params.data.id);
  if (!server) {
    res.status(404).json({ error: "Server not found" });
    return;
  }
  cancelScheduledAutoStart(server.id);
  clearCrashStartRetryState(server.id);
  await stopManagedProcess(server.id, await getStopOptions(server.id));
  const stagedDirectory = await stageManagedServerDirectoryDeletion(server.directory);
  try {
    await db.delete(serversTable).where(eq(serversTable.id, server.id));
  } catch (error) {
    if (stagedDirectory) await restoreManagedServerDirectory(stagedDirectory);
    throw error;
  }
  if (stagedDirectory) {
    await removeStagedManagedServerDirectory(stagedDirectory).catch((error) => {
      req.log.error(
        { err: error, serverId: server.id, directory: stagedDirectory.stagedPath },
        "Server was removed but its staged data folder could not be deleted",
      );
    });
  }
  await addActivity(`${server.name} removed from the fleet`, "warning");
  res.sendStatus(204);
});

async function startServer(id: number, res: Parameters<Parameters<IRouter["post"]>[1]>[1], schema: typeof StartServerResponse): Promise<void> {
  const server = await findServer(id);
  if (!server) {
    res.status(404).json({ error: "Server not found" });
    return;
  }
  try {
    cancelScheduledAutoStart(server.id);
    clearCrashStartRetryState(server.id);
    const updated = await startManagedServerProcess(server);
    res.json(schema.parse(formatServer(updated)));
  } catch (error) {
    res.status(409).json({ error: error instanceof Error ? error.message : "Could not start server" });
  }
}

router.post("/servers/:id/start", async (req, res): Promise<void> => {
  const params = StartServerParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }
  await startServer(params.data.id, res, StartServerResponse);
});

router.post("/servers/:id/stop", async (req, res): Promise<void> => {
  const params = StopServerParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }
  const server = await findServer(params.data.id);
  if (!server) { res.status(404).json({ error: "Server not found" }); return; }
  cancelScheduledAutoStart(server.id);
  clearCrashStartRetryState(server.id);
  await stopManagedProcess(server.id, await getStopOptions(server.id));
  await db.update(serversTable).set({ status: "offline", pid: null, updatedAt: new Date() }).where(eq(serversTable.id, server.id));
  await addActivity(`${server.name} stopped`, "warning");
  const updated = await findServer(server.id);
  res.json(StopServerResponse.parse(formatServer(updated ?? server)));
});

router.post("/servers/:id/kill", async (req, res): Promise<void> => {
  const params = KillServerParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }
  const server = await findServer(params.data.id);
  if (!server) { res.status(404).json({ error: "Server not found" }); return; }
  cancelScheduledAutoStart(server.id);
  clearCrashStartRetryState(server.id);
  await killManagedProcess(server.id);
  await db.update(serversTable).set({ status: "offline", pid: null, updatedAt: new Date() }).where(eq(serversTable.id, server.id));
  await addActivity(`${server.name} killed`, "warning");
  const updated = await findServer(server.id);
  res.json(KillServerResponse.parse(formatServer(updated ?? server)));
});

router.post("/servers/:id/restart", async (req, res): Promise<void> => {
  const params = RestartServerParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }
  const server = await findServer(params.data.id);
  if (!server) { res.status(404).json({ error: "Server not found" }); return; }
  cancelScheduledAutoStart(server.id);
  clearCrashStartRetryState(server.id);
  await stopManagedProcess(server.id, await getStopOptions(server.id));
  clearManagedProcess(server.id);
  await startServer(server.id, res, RestartServerResponse);
});

router.get("/servers/:id/logs", async (req, res): Promise<void> => {
  const params = GetServerLogsParams.safeParse(req.params);
  const query = GetServerLogsQueryParams.safeParse(req.query);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }
  const server = await findServer(params.data.id);
  if (!server) { res.status(404).json({ error: "Server not found" }); return; }
  const lines = getProcessLines(server.id).slice(-query.data.limit);
  res.json(GetServerLogsResponse.parse({ serverId: server.id, lines, updatedAt: new Date().toISOString() }));
});

router.delete("/servers/:id/logs", async (req, res): Promise<void> => {
  const params = ClearServerLogsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const server = await findServer(params.data.id);
  if (!server) {
    res.status(404).json({ error: "Server not found" });
    return;
  }
  clearProcessLogLines(server.id);
  res.sendStatus(204);
});

router.post("/servers/:id/console", async (req, res): Promise<void> => {
  const params = SendServerConsoleCommandParams.safeParse(req.params);
  const body = SendServerConsoleCommandBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const server = await findServer(params.data.id);
  if (!server) {
    res.status(404).json({ error: "Server not found" });
    return;
  }

  const command = body.data.command.trim();
  try {
    const terminalSettings = await getTerminalSettings(server.id);
    sendManagedProcessInput(server.id, command, {
      lineEnding: LINE_ENDINGS[terminalSettings.lineEnding],
      encoding: terminalSettings.inputEncoding,
    });
  } catch (error) {
    res.status(409).json({ error: error instanceof Error ? error.message : "Could not send input to the server console" });
    return;
  }
  await addActivity(`${server.name} console command sent`, "info");
  res.json(SendServerConsoleCommandResponse.parse({
    serverId: server.id,
    command,
    sentAt: new Date().toISOString(),
  }));
});

export default router;