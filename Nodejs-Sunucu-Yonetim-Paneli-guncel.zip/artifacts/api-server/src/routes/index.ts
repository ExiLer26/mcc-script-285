import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import dashboardRouter from "./dashboard";
import serversRouter from "./servers";
import serverFilesRouter from "./server-files";
import terminalSettingsRouter from "./terminal-settings";
import schedulesRouter from "./schedules";
import installScriptsRouter from "./install-scripts";
import activityRouter from "./activity";
import consoleTerminalsRouter from "./console-terminals";
import usersRouter from "./users";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(dashboardRouter);
router.use(serversRouter);
router.use(serverFilesRouter);
router.use(terminalSettingsRouter);
router.use(schedulesRouter);
router.use(installScriptsRouter);
router.use(activityRouter);
router.use(consoleTerminalsRouter);
router.use(usersRouter);

export default router;
