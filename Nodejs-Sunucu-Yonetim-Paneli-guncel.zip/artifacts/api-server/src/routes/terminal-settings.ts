import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, serversTable } from "@workspace/db";
import { requireAuth } from "../middlewares/auth";
import {
  getTerminalSettings,
  parseTerminalSettingsInput,
  saveTerminalSettings,
} from "../lib/terminal-settings";

const router: IRouter = Router();
router.use(requireAuth);

async function serverExists(rawId: string): Promise<number | null> {
  const id = Number(rawId);
  if (!Number.isInteger(id) || id < 1) return null;
  const [server] = await db.select({ id: serversTable.id }).from(serversTable).where(eq(serversTable.id, id)).limit(1);
  return server?.id ?? null;
}

router.get("/servers/:id/terminal-settings", async (req, res): Promise<void> => {
  const id = await serverExists(req.params.id);
  if (id === null) {
    res.status(404).json({ error: "Server not found" });
    return;
  }
  res.json(await getTerminalSettings(id));
});

router.put("/servers/:id/terminal-settings", async (req, res): Promise<void> => {
  const id = await serverExists(req.params.id);
  if (id === null) {
    res.status(404).json({ error: "Server not found" });
    return;
  }
  const parsed = parseTerminalSettingsInput(req.body);
  if (!parsed.ok) {
    res.status(400).json({ error: parsed.error });
    return;
  }
  try {
    await saveTerminalSettings(id, parsed.value);
  } catch (error) {
    req.log?.error({ err: error }, "Could not save terminal settings");
    res.status(500).json({ error: `Could not save terminal settings: ${error instanceof Error ? error.message : "database error"}` });
    return;
  }
  res.json(parsed.value);
});

export default router;
