import os from "node:os";
import { Router, type IRouter } from "express";
import { desc } from "drizzle-orm";
import { db, activityTable, serversTable } from "@workspace/db";
import { GetDashboardResponse } from "@workspace/api-zod";
import { requireAuth } from "../middlewares/auth";
import { getManagedProcess } from "../lib/process-manager";

const router: IRouter = Router();

function formatServer(row: typeof serversTable.$inferSelect) {
  const running = getManagedProcess(row.id);
  const isRunning = Boolean(running && running.child.exitCode === null);
  const startedAt = running ? new Date(running.startedAt) : row.lastStartedAt;
  return {
    id: row.id,
    name: row.name,
    description: row.description,
    directory: row.directory,
    command: row.command,
    autoStart: row.autoStart,
    autoStartDelaySeconds: row.autoStartDelaySeconds,
    crashStart: row.crashStart,
    crashStartDelaySeconds: row.crashStartDelaySeconds,
    logRefreshIntervalSeconds: row.logRefreshIntervalSeconds,
    status: isRunning ? "online" : row.status,
    pid: isRunning ? running?.child.pid ?? null : row.pid,
    port: row.port,
    uptimeSeconds: startedAt && (isRunning || row.status === "online")
      ? Math.max(0, Math.floor((Date.now() - startedAt.getTime()) / 1000))
      : 0,
    lastStartedAt: startedAt?.toISOString() ?? null,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

router.get("/dashboard", requireAuth, async (_req, res): Promise<void> => {
  const [servers, recentActivity] = await Promise.all([
    db.select().from(serversTable).orderBy(desc(serversTable.updatedAt)),
    db.select().from(activityTable).orderBy(desc(activityTable.createdAt)).limit(8),
  ]);
  const mappedServers = servers.map(formatServer);
  const totalMemory = os.totalmem();
  const freeMemory = os.freemem();
  const cpu = os.loadavg()[0] / Math.max(os.cpus().length, 1) * 100;
  const payload = {
    servers: mappedServers,
    totalServers: mappedServers.length,
    onlineServers: mappedServers.filter((server) => server.status === "online").length,
    offlineServers: mappedServers.filter((server) => server.status === "offline").length,
    failedServers: mappedServers.filter((server) => server.status === "failed").length,
    recentActivity: recentActivity.map((item) => ({
      id: item.id,
      message: item.message,
      kind: item.kind,
      createdAt: item.createdAt.toISOString(),
    })),
    system: {
      cpuPercent: Number(Math.min(100, Math.max(0, cpu)).toFixed(1)),
      memoryPercent: Number(((1 - freeMemory / totalMemory) * 100).toFixed(1)),
      memoryUsedMb: Math.round((totalMemory - freeMemory) / 1024 / 1024),
      memoryTotalMb: Math.round(totalMemory / 1024 / 1024),
      uptimeSeconds: Math.floor(os.uptime()),
    },
  };
  res.json(GetDashboardResponse.parse(payload));
});

export { formatServer };
export default router;