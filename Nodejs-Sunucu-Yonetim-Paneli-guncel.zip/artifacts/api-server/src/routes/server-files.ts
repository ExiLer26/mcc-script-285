import express, { Router, type IRouter } from "express";
import { constants as fsConstants, createReadStream } from "node:fs";
import { open } from "node:fs/promises";
import { pipeline } from "node:stream/promises";
import {
  CreateServerDirectoryBody,
  CreateServerDirectoryParams,
  CreateServerDirectoryResponse,
  CreateServerFileBody,
  CreateServerFileParams,
  CreateServerFileResponse,
  DeleteServerFileBody,
  DeleteServerFileParams,
  DownloadServerFileArchiveBody,
  DownloadServerFileArchiveParams,
  DownloadServerFileFromUrlBody,
  DownloadServerFileFromUrlParams,
  DownloadServerFileFromUrlResponse,
  DownloadServerFileParams,
  DownloadServerFileQueryParams,
  ExtractServerZipArchiveBody,
  ExtractServerZipArchiveParams,
  ExtractServerZipArchiveResponse,
  SetServerFilePermissionsBody,
  SetServerFilePermissionsParams,
  SetServerFilePermissionsResponse,
  GetServerFileContentParams,
  GetServerFileContentQueryParams,
  GetServerFileContentResponse,
  ListServerFilesParams,
  ListServerFilesQueryParams,
  ListServerFilesResponse,
  MoveServerFileBody,
  MoveServerFileParams,
  MoveServerFileResponse,
  SaveServerFileContentBody,
  SaveServerFileContentParams,
  SaveServerFileContentResponse,
  UploadServerFileHeader,
  UploadServerFileParams,
  UploadServerFileQueryParams,
  UploadServerFileResponse,
} from "@workspace/api-zod";
import { db, serversTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth";
import {
  MAX_UPLOAD_BYTES,
  createServerFilesArchive,
  createServerFolder,
  createServerTextFile,
  deleteServerEntry,
  downloadServerFileFromUrl,
  extractServerZipArchive,
  getServerFileDownload,
  setServerFilePermissions,
  listServerDirectory,
  mapServerFilesError,
  moveServerEntry,
  readServerTextFile,
  removeServerFilesArchive,
  saveServerTextFile,
  type ServerFilesArchive,
  uploadServerFile,
} from "../lib/server-files";

const router: IRouter = Router();
router.use(requireAuth);

async function findServer(id: number) {
  const [server] = await db.select().from(serversTable).where(eq(serversTable.id, id)).limit(1);
  return server;
}

function respondWithFileError(
  req: express.Request,
  res: express.Response,
  error: unknown,
): void {
  const fileError = mapServerFilesError(error);
  if (fileError) {
    res.status(fileError.status).json({ error: fileError.message });
    return;
  }
  req.log.error({ err: error }, "Managed server file operation failed");
  res.status(500).json({ error: "Could not complete the file operation." });
}

router.get("/servers/:id/files", async (req, res): Promise<void> => {
  const params = ListServerFilesParams.safeParse(req.params);
  const query = ListServerFilesQueryParams.safeParse(req.query);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }

  const server = await findServer(params.data.id);
  if (!server) {
    res.status(404).json({ error: "Managed server not found." });
    return;
  }
  try {
    res.json(ListServerFilesResponse.parse(await listServerDirectory(server, query.data.path)));
  } catch (error) {
    respondWithFileError(req, res, error);
  }
});

router.get("/servers/:id/files/content", async (req, res): Promise<void> => {
  const params = GetServerFileContentParams.safeParse(req.params);
  const query = GetServerFileContentQueryParams.safeParse(req.query);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }

  const server = await findServer(params.data.id);
  if (!server) {
    res.status(404).json({ error: "Managed server not found." });
    return;
  }
  try {
    res.json(GetServerFileContentResponse.parse(await readServerTextFile(server, query.data.path)));
  } catch (error) {
    respondWithFileError(req, res, error);
  }
});

router.put("/servers/:id/files/content", async (req, res): Promise<void> => {
  const params = SaveServerFileContentParams.safeParse(req.params);
  const body = SaveServerFileContentBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const server = await findServer(params.data.id);
  if (!server) {
    res.status(404).json({ error: "Managed server not found." });
    return;
  }
  try {
    res.json(SaveServerFileContentResponse.parse(
      await saveServerTextFile(server, body.data.path, body.data.content),
    ));
  } catch (error) {
    respondWithFileError(req, res, error);
  }
});

router.get("/servers/:id/files/download", async (req, res): Promise<void> => {
  const params = DownloadServerFileParams.safeParse(req.params);
  const query = DownloadServerFileQueryParams.safeParse(req.query);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }

  const server = await findServer(params.data.id);
  if (!server) {
    res.status(404).json({ error: "Managed server not found." });
    return;
  }
  try {
    const file = await getServerFileDownload(server, query.data.path);
    const fileHandle = await open(file.absolutePath, fsConstants.O_RDONLY | fsConstants.O_NOFOLLOW);
    try {
      res.attachment(file.fileName);
      res.type("application/octet-stream");
      await pipeline(fileHandle.createReadStream({ autoClose: false }), res);
    } finally {
      await fileHandle.close();
    }
  } catch (error) {
    if (res.headersSent) {
      req.log.warn({ err: error }, "File download stream ended unexpectedly");
      res.destroy(error instanceof Error ? error : undefined);
      return;
    }
    respondWithFileError(req, res, error);
  }
});

router.post("/servers/:id/files/archive", async (req, res): Promise<void> => {
  const params = DownloadServerFileArchiveParams.safeParse(req.params);
  const body = DownloadServerFileArchiveBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const server = await findServer(params.data.id);
  if (!server) {
    res.status(404).json({ error: "Managed server not found." });
    return;
  }

  let archive: ServerFilesArchive | undefined;
  try {
    archive = await createServerFilesArchive(server, body.data.paths);
    res.attachment(archive.fileName);
    res.type("application/zip");
    await pipeline(createReadStream(archive.filePath), res);
  } catch (error) {
    if (res.headersSent) {
      req.log.warn({ err: error }, "Server file archive stream ended unexpectedly");
      res.destroy(error instanceof Error ? error : undefined);
    } else {
      respondWithFileError(req, res, error);
    }
  } finally {
    if (archive) {
      await removeServerFilesArchive(archive).catch((error) => {
        req.log.error({ err: error, serverId: params.data.id }, "Could not remove temporary server archive");
      });
    }
  }
});

router.post(
  "/servers/:id/files/upload",
  express.raw({ type: "application/octet-stream", limit: MAX_UPLOAD_BYTES }),
  async (req, res): Promise<void> => {
    const params = UploadServerFileParams.safeParse(req.params);
    const query = UploadServerFileQueryParams.safeParse(req.query);
    const header = UploadServerFileHeader.safeParse({
      "X-File-Name": req.get("X-File-Name"),
    });
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    if (!query.success) {
      res.status(400).json({ error: query.error.message });
      return;
    }
    if (!header.success) {
      res.status(400).json({ error: header.error.message });
      return;
    }
    if (!Buffer.isBuffer(req.body)) {
      res.status(400).json({ error: "Upload body must contain file bytes." });
      return;
    }

    let fileName: string;
    try {
      fileName = decodeURIComponent(header.data["X-File-Name"]);
    } catch {
      res.status(400).json({ error: "Invalid upload file name." });
      return;
    }

    const server = await findServer(params.data.id);
    if (!server) {
      res.status(404).json({ error: "Managed server not found." });
      return;
    }
    try {
      const entry = await uploadServerFile(server, query.data.directory, fileName, req.body);
      res.status(201).json(UploadServerFileResponse.parse(entry));
    } catch (error) {
      respondWithFileError(req, res, error);
    }
  },
);

router.post("/servers/:id/files/directory", async (req, res): Promise<void> => {
  const params = CreateServerDirectoryParams.safeParse(req.params);
  const body = CreateServerDirectoryBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const server = await findServer(params.data.id);
  if (!server) {
    res.status(404).json({ error: "Managed server not found." });
    return;
  }
  try {
    res.status(201).json(CreateServerDirectoryResponse.parse(
      await createServerFolder(server, body.data.path),
    ));
  } catch (error) {
    respondWithFileError(req, res, error);
  }
});

router.post("/servers/:id/files/file", async (req, res): Promise<void> => {
  const params = CreateServerFileParams.safeParse(req.params);
  const body = CreateServerFileBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const server = await findServer(params.data.id);
  if (!server) {
    res.status(404).json({ error: "Managed server not found." });
    return;
  }
  try {
    const saved = await createServerTextFile(server, body.data.path, body.data.content);
    res.status(201).json(CreateServerFileResponse.parse(saved));
  } catch (error) {
    respondWithFileError(req, res, error);
  }
});

router.post("/servers/:id/files/move", async (req, res): Promise<void> => {
  const params = MoveServerFileParams.safeParse(req.params);
  const body = MoveServerFileBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const server = await findServer(params.data.id);
  if (!server) {
    res.status(404).json({ error: "Managed server not found." });
    return;
  }
  try {
    res.json(MoveServerFileResponse.parse(
      await moveServerEntry(server, body.data.source, body.data.destination),
    ));
  } catch (error) {
    respondWithFileError(req, res, error);
  }
});

router.delete("/servers/:id/files", async (req, res): Promise<void> => {
  const params = DeleteServerFileParams.safeParse(req.params);
  const body = DeleteServerFileBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const server = await findServer(params.data.id);
  if (!server) {
    res.status(404).json({ error: "Managed server not found." });
    return;
  }
  try {
    await deleteServerEntry(server, body.data.path);
    res.sendStatus(204);
  } catch (error) {
    respondWithFileError(req, res, error);
  }
});

router.post("/servers/:id/files/download-url", async (req, res): Promise<void> => {
  const params = DownloadServerFileFromUrlParams.safeParse(req.params);
  const body = DownloadServerFileFromUrlBody.safeParse(req.body);
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }
  if (!body.success) { res.status(400).json({ error: body.error.message }); return; }
  const server = await findServer(params.data.id);
  if (!server) { res.status(404).json({ error: "Managed server not found." }); return; }
  try {
    const entry = await downloadServerFileFromUrl(server, body.data.url, body.data.directory);
    res.status(201).json(DownloadServerFileFromUrlResponse.parse(entry));
  } catch (error) {
    respondWithFileError(req, res, error);
  }
});

router.post("/servers/:id/files/unzip", async (req, res): Promise<void> => {
  const params = ExtractServerZipArchiveParams.safeParse(req.params);
  const body = ExtractServerZipArchiveBody.safeParse(req.body);
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }
  if (!body.success) { res.status(400).json({ error: body.error.message }); return; }
  const server = await findServer(params.data.id);
  if (!server) { res.status(404).json({ error: "Managed server not found." }); return; }
  try {
    const result = await extractServerZipArchive(server, body.data.path);
    res.status(201).json(ExtractServerZipArchiveResponse.parse(result));
  } catch (error) {
    respondWithFileError(req, res, error);
  }
});

router.patch("/servers/:id/files/permissions", async (req, res): Promise<void> => {
  const params = SetServerFilePermissionsParams.safeParse(req.params);
  const body = SetServerFilePermissionsBody.safeParse(req.body);
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }
  if (!body.success) { res.status(400).json({ error: body.error.message }); return; }
  const server = await findServer(params.data.id);
  if (!server) { res.status(404).json({ error: "Managed server not found." }); return; }
  try {
    const entry = await setServerFilePermissions(server, body.data.path, body.data.mode);
    res.json(SetServerFilePermissionsResponse.parse(entry));
  } catch (error) {
    respondWithFileError(req, res, error);
  }
});

export default router;
