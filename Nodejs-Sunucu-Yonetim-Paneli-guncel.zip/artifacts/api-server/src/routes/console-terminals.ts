import { Router, type IRouter } from "express";
import { asc, eq, sql } from "drizzle-orm";
import { consoleTerminalsTable, db, serversTable } from "@workspace/db";
import { requireAuth } from "../middlewares/auth";

const router: IRouter = Router();
router.use(requireAuth);

// Creates the table on demand so no manual database push is needed.
let ensureTablePromise: Promise<void> | null = null;
function ensureTable(): Promise<void> {
  if (!ensureTablePromise) {
    ensureTablePromise = db
      .execute(sql`
        CREATE TABLE IF NOT EXISTS console_terminals (
          server_id integer PRIMARY KEY REFERENCES managed_servers(id) ON DELETE CASCADE,
          created_at timestamptz NOT NULL DEFAULT now()
        )
      `)
      .then(() => undefined)
      .catch((error) => {
        ensureTablePromise = null;
        throw error;
      });
  }
  return ensureTablePromise;
}

function dbError(error: unknown): string {
  return error instanceof Error ? error.message : "database error";
}

router.get("/console-terminals", async (_req, res): Promise<void> => {
  try {
    await ensureTable();
    const rows = await db.select().from(consoleTerminalsTable).orderBy(asc(consoleTerminalsTable.createdAt));
    res.json(rows.map((row) => ({ serverId: row.serverId })));
  } catch (error) {
    res.status(500).json({ error: `Could not load the console: ${dbError(error)}` });
  }
});

router.post("/console-terminals", async (req, res): Promise<void> => {
  const serverId = Number((req.body as { serverId?: unknown } | undefined)?.serverId);
  if (!Number.isInteger(serverId) || serverId < 1) {
    res.status(400).json({ error: "Choose a server." });
    return;
  }
  try {
    await ensureTable();
    const [server] = await db.select({ id: serversTable.id }).from(serversTable).where(eq(serversTable.id, serverId)).limit(1);
    if (!server) {
      res.status(404).json({ error: "Server not found" });
      return;
    }
    await db.insert(consoleTerminalsTable).values({ serverId }).onConflictDoNothing();
    res.status(201).json({ serverId });
  } catch (error) {
    res.status(500).json({ error: `Could not add the terminal: ${dbError(error)}` });
  }
});

router.delete("/console-terminals/:serverId", async (req, res): Promise<void> => {
  const serverId = Number(req.params.serverId);
  if (!Number.isInteger(serverId) || serverId < 1) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }
  try {
    await ensureTable();
    await db.delete(consoleTerminalsTable).where(eq(consoleTerminalsTable.serverId, serverId));
    res.sendStatus(204);
  } catch (error) {
    res.status(500).json({ error: `Could not remove the terminal: ${dbError(error)}` });
  }
});

export default router;
