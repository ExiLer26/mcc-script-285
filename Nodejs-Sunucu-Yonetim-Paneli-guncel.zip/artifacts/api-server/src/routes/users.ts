import { Router, type IRouter } from "express";
import { asc, eq } from "drizzle-orm";
import { adminsTable, db, panelUsersTable, serversTable, type PanelUser } from "@workspace/db";
import { requireAdmin } from "../middlewares/auth";
import { createPasswordRecord, ensureUserTables, toUserAccess } from "../lib/auth";
import { normalizePermissions } from "../lib/permissions";

const router: IRouter = Router();

function formatUser(user: PanelUser) {
  const access = toUserAccess(user);
  return {
    id: user.id,
    username: user.username,
    displayName: user.displayName,
    permissions: access.permissions,
    allServers: access.allServers,
    serverIds: access.serverIds,
    disabled: user.disabled,
    createdAt: user.createdAt.toISOString(),
  };
}

function toId(value: string | undefined): number | null {
  const id = Number(value);
  return Number.isInteger(id) && id > 0 ? id : null;
}

function dbError(error: unknown): string {
  return error instanceof Error ? error.message : "database error";
}

type UserInput = {
  username?: string;
  displayName: string;
  password?: string;
  permissions: string[];
  allServers: boolean;
  serverIds: number[];
  disabled: boolean;
};

async function parseUserInput(body: unknown, creating: boolean): Promise<{ ok: true; value: UserInput } | { ok: false; error: string }> {
  if (!body || typeof body !== "object") return { ok: false, error: "Invalid user." };
  const input = body as Record<string, unknown>;

  let username: string | undefined;
  if (creating) {
    username = typeof input.username === "string" ? input.username.trim().toLowerCase() : "";
    if (!/^[a-z0-9._-]{3,32}$/.test(username)) {
      return { ok: false, error: "The username must be 3-32 characters: lowercase letters, numbers, dot, dash or underscore." };
    }
  }
  const displayName = typeof input.displayName === "string" ? input.displayName.trim() : "";
  if (!displayName || displayName.length > 60) return { ok: false, error: "The display name must be 1-60 characters." };

  let password: string | undefined;
  if (typeof input.password === "string" && input.password.length > 0) {
    if (input.password.length < 8 || input.password.length > 128) return { ok: false, error: "The password must be 8-128 characters." };
    password = input.password;
  } else if (creating) {
    return { ok: false, error: "Enter a password (at least 8 characters)." };
  }

  const permissions = normalizePermissions(input.permissions);
  const allServers = input.allServers === true;
  const requestedIds = Array.isArray(input.serverIds) ? input.serverIds.filter((id): id is number => typeof id === "number" && Number.isInteger(id) && id > 0) : [];
  let serverIds: number[] = [];
  if (!allServers && requestedIds.length) {
    const existing = await db.select({ id: serversTable.id }).from(serversTable);
    const known = new Set(existing.map((server) => server.id));
    serverIds = [...new Set(requestedIds)].filter((id) => known.has(id));
  }
  if (!allServers && !serverIds.length) return { ok: false, error: "Choose at least one server, or allow all servers." };

  return { ok: true, value: { username, displayName, password, permissions, allServers, serverIds, disabled: input.disabled === true } };
}

router.get("/users", requireAdmin, async (_req, res): Promise<void> => {
  try {
    await ensureUserTables();
    const rows = await db.select().from(panelUsersTable).orderBy(asc(panelUsersTable.id));
    res.json(rows.map(formatUser));
  } catch (error) {
    res.status(500).json({ error: `Could not load users: ${dbError(error)}` });
  }
});

router.post("/users", requireAdmin, async (req, res): Promise<void> => {
  const parsed = await parseUserInput(req.body, true);
  if (!parsed.ok) {
    res.status(400).json({ error: parsed.error });
    return;
  }
  const { username, displayName, password, permissions, allServers, serverIds } = parsed.value;
  try {
    await ensureUserTables();
    const [adminWithName] = await db.select({ id: adminsTable.id }).from(adminsTable).where(eq(adminsTable.username, username as string)).limit(1);
    const [userWithName] = await db.select({ id: panelUsersTable.id }).from(panelUsersTable).where(eq(panelUsersTable.username, username as string)).limit(1);
    if (adminWithName || userWithName) {
      res.status(409).json({ error: "This username is already taken." });
      return;
    }
    const record = createPasswordRecord(password as string);
    const [row] = await db
      .insert(panelUsersTable)
      .values({
        username: username as string,
        displayName,
        passwordHash: record.hash,
        passwordSalt: record.salt,
        permissions: JSON.stringify(permissions),
        allServers,
        serverIds: JSON.stringify(serverIds),
      })
      .returning();
    res.status(201).json(formatUser(row));
  } catch (error) {
    res.status(500).json({ error: `Could not create the user: ${dbError(error)}` });
  }
});

router.put("/users/:id", requireAdmin, async (req, res): Promise<void> => {
  const id = toId(req.params.id);
  if (!id) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }
  const parsed = await parseUserInput(req.body, false);
  if (!parsed.ok) {
    res.status(400).json({ error: parsed.error });
    return;
  }
  const { displayName, password, permissions, allServers, serverIds, disabled } = parsed.value;
  try {
    await ensureUserTables();
    const changes: Partial<typeof panelUsersTable.$inferInsert> = {
      displayName,
      permissions: JSON.stringify(permissions),
      allServers,
      serverIds: JSON.stringify(serverIds),
      disabled,
    };
    if (password) {
      const record = createPasswordRecord(password);
      changes.passwordHash = record.hash;
      changes.passwordSalt = record.salt;
    }
    const [row] = await db.update(panelUsersTable).set(changes).where(eq(panelUsersTable.id, id)).returning();
    if (!row) {
      res.status(404).json({ error: "User not found" });
      return;
    }
    res.json(formatUser(row));
  } catch (error) {
    res.status(500).json({ error: `Could not update the user: ${dbError(error)}` });
  }
});

router.delete("/users/:id", requireAdmin, async (req, res): Promise<void> => {
  const id = toId(req.params.id);
  if (!id) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }
  try {
    await ensureUserTables();
    const deleted = await db.delete(panelUsersTable).where(eq(panelUsersTable.id, id)).returning({ id: panelUsersTable.id });
    if (!deleted.length) {
      res.status(404).json({ error: "User not found" });
      return;
    }
    res.sendStatus(204);
  } catch (error) {
    res.status(500).json({ error: `Could not delete the user: ${dbError(error)}` });
  }
});

export default router;
