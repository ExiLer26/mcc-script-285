import { Router, type IRouter } from "express";
import { and, asc, count, eq } from "drizzle-orm";
import { db, serversTable, serverSchedulesTable } from "@workspace/db";
import { requireAuth } from "../middlewares/auth";
import {
  computeNextRun,
  ensureSchedulesTable,
  executeScheduledCommand,
  formatSchedule,
  MAX_TASKS_PER_SERVER,
  parseScheduleInput,
  parseStoredConfig,
  type ScheduleType,
} from "../lib/schedules";

const router: IRouter = Router();
router.use(requireAuth);

function toId(value: string | undefined): number | null {
  const id = Number(value);
  return Number.isInteger(id) && id > 0 ? id : null;
}

async function serverExists(serverId: number): Promise<boolean> {
  const [server] = await db.select({ id: serversTable.id }).from(serversTable).where(eq(serversTable.id, serverId)).limit(1);
  return Boolean(server);
}

async function loadTask(serverId: number, taskId: number) {
  const [task] = await db
    .select()
    .from(serverSchedulesTable)
    .where(and(eq(serverSchedulesTable.id, taskId), eq(serverSchedulesTable.serverId, serverId)))
    .limit(1);
  return task;
}

router.get("/servers/:id/schedules", async (req, res): Promise<void> => {
  const serverId = toId(req.params.id);
  if (!serverId || !(await serverExists(serverId))) {
    res.status(404).json({ error: "Server not found" });
    return;
  }
  try {
    await ensureSchedulesTable();
    const rows = await db.select().from(serverSchedulesTable).where(eq(serverSchedulesTable.serverId, serverId)).orderBy(asc(serverSchedulesTable.id));
    res.json(rows.map(formatSchedule));
  } catch (error) {
    res.status(500).json({ error: `Could not load tasks: ${error instanceof Error ? error.message : "database error"}` });
  }
});

router.post("/servers/:id/schedules", async (req, res): Promise<void> => {
  const serverId = toId(req.params.id);
  if (!serverId || !(await serverExists(serverId))) {
    res.status(404).json({ error: "Server not found" });
    return;
  }
  const parsed = parseScheduleInput(req.body);
  if (!parsed.ok) {
    res.status(400).json({ error: parsed.error });
    return;
  }
  try {
    await ensureSchedulesTable();
    const [{ total }] = await db.select({ total: count() }).from(serverSchedulesTable).where(eq(serverSchedulesTable.serverId, serverId));
    if (total >= MAX_TASKS_PER_SERVER) {
      res.status(400).json({ error: `A server can have up to ${MAX_TASKS_PER_SERVER} tasks.` });
      return;
    }
    const { name, taskType, config, command } = parsed.value;
    const [row] = await db
      .insert(serverSchedulesTable)
      .values({ serverId, name, taskType, config: JSON.stringify(config), command, enabled: true, nextRunAt: computeNextRun(taskType, config, new Date()) })
      .returning();
    res.status(201).json(formatSchedule(row));
  } catch (error) {
    res.status(500).json({ error: `Could not save the task: ${error instanceof Error ? error.message : "database error"}` });
  }
});

router.put("/servers/:id/schedules/:taskId", async (req, res): Promise<void> => {
  const serverId = toId(req.params.id);
  const taskId = toId(req.params.taskId);
  if (!serverId || !taskId) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }
  const existing = await loadTask(serverId, taskId);
  if (!existing) {
    res.status(404).json({ error: "Task not found" });
    return;
  }
  const parsed = parseScheduleInput(req.body);
  if (!parsed.ok) {
    res.status(400).json({ error: parsed.error });
    return;
  }
  const { name, taskType, config, command } = parsed.value;
  const [row] = await db
    .update(serverSchedulesTable)
    .set({ name, taskType, config: JSON.stringify(config), command, enabled: true, nextRunAt: computeNextRun(taskType, config, new Date()), lastStatus: null })
    .where(eq(serverSchedulesTable.id, taskId))
    .returning();
  res.json(formatSchedule(row));
});

router.patch("/servers/:id/schedules/:taskId", async (req, res): Promise<void> => {
  const serverId = toId(req.params.id);
  const taskId = toId(req.params.taskId);
  if (!serverId || !taskId) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }
  const task = await loadTask(serverId, taskId);
  if (!task) {
    res.status(404).json({ error: "Task not found" });
    return;
  }
  const enabled = (req.body as { enabled?: unknown } | undefined)?.enabled;
  if (typeof enabled !== "boolean") {
    res.status(400).json({ error: "enabled must be true or false." });
    return;
  }
  let nextRunAt: Date | null = null;
  if (enabled) {
    nextRunAt = computeNextRun(task.taskType as ScheduleType, parseStoredConfig(task), new Date());
    if (!nextRunAt) {
      res.status(400).json({ error: "This task has no upcoming run time. Edit it and choose a new time." });
      return;
    }
  }
  const [row] = await db.update(serverSchedulesTable).set({ enabled, nextRunAt }).where(eq(serverSchedulesTable.id, taskId)).returning();
  res.json(formatSchedule(row));
});

router.post("/servers/:id/schedules/:taskId/run", async (req, res): Promise<void> => {
  const serverId = toId(req.params.id);
  const taskId = toId(req.params.taskId);
  if (!serverId || !taskId) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }
  const task = await loadTask(serverId, taskId);
  if (!task) {
    res.status(404).json({ error: "Task not found" });
    return;
  }
  const status = await executeScheduledCommand(task);
  const [row] = await db
    .update(serverSchedulesTable)
    .set({ lastRunAt: new Date(), lastStatus: `${status} (manual)`, runCount: task.runCount + 1 })
    .where(eq(serverSchedulesTable.id, taskId))
    .returning();
  res.json(formatSchedule(row));
});

router.delete("/servers/:id/schedules/:taskId", async (req, res): Promise<void> => {
  const serverId = toId(req.params.id);
  const taskId = toId(req.params.taskId);
  if (!serverId || !taskId) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }
  const task = await loadTask(serverId, taskId);
  if (!task) {
    res.status(404).json({ error: "Task not found" });
    return;
  }
  await db.delete(serverSchedulesTable).where(eq(serverSchedulesTable.id, taskId));
  res.sendStatus(204);
});

export default router;
