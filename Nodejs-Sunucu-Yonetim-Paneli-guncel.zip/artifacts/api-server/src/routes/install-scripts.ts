import { Router, type IRouter } from "express";
import { asc, eq } from "drizzle-orm";
import { db, installScriptsTable, serversTable } from "@workspace/db";
import { requireAuth, type AuthenticatedRequest } from "../middlewares/auth";
import { canAccessServer } from "../lib/permissions";
import {
  cancelJob,
  ensureScriptsTable,
  formatScript,
  getActiveJobForServer,
  getJobView,
  parseScriptInput,
  splitGroupValue,
  startScriptJob,
  substituteStep,
  type ScriptStep,
  type ScriptVariable,
} from "../lib/install-scripts";

const router: IRouter = Router();
router.use(requireAuth);

function toId(value: string | undefined): number | null {
  const id = Number(value);
  return Number.isInteger(id) && id > 0 ? id : null;
}

function dbError(error: unknown): string {
  return error instanceof Error ? error.message : "database error";
}

router.get("/scripts", async (_req, res): Promise<void> => {
  try {
    await ensureScriptsTable();
    const rows = await db.select().from(installScriptsTable).orderBy(asc(installScriptsTable.id));
    res.json(rows.map(formatScript));
  } catch (error) {
    res.status(500).json({ error: `Could not load scripts: ${dbError(error)}` });
  }
});

router.post("/scripts", async (req, res): Promise<void> => {
  const parsed = parseScriptInput(req.body);
  if (!parsed.ok) {
    res.status(400).json({ error: parsed.error });
    return;
  }
  try {
    await ensureScriptsTable();
    const { name, description, variables, steps } = parsed.value;
    const [row] = await db
      .insert(installScriptsTable)
      .values({ name, description, variables: JSON.stringify(variables), steps: JSON.stringify(steps) })
      .returning();
    res.status(201).json(formatScript(row));
  } catch (error) {
    res.status(500).json({ error: `Could not save the script: ${dbError(error)}` });
  }
});

router.put("/scripts/:id", async (req, res): Promise<void> => {
  const id = toId(req.params.id);
  const parsed = parseScriptInput(req.body);
  if (!id) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }
  if (!parsed.ok) {
    res.status(400).json({ error: parsed.error });
    return;
  }
  const { name, description, variables, steps } = parsed.value;
  const [row] = await db
    .update(installScriptsTable)
    .set({ name, description, variables: JSON.stringify(variables), steps: JSON.stringify(steps), updatedAt: new Date() })
    .where(eq(installScriptsTable.id, id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "Script not found" });
    return;
  }
  res.json(formatScript(row));
});

router.delete("/scripts/:id", async (req, res): Promise<void> => {
  const id = toId(req.params.id);
  if (!id) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }
  const deleted = await db.delete(installScriptsTable).where(eq(installScriptsTable.id, id)).returning({ id: installScriptsTable.id });
  if (!deleted.length) {
    res.status(404).json({ error: "Script not found" });
    return;
  }
  res.sendStatus(204);
});

router.post("/scripts/:id/run", async (req, res): Promise<void> => {
  const id = toId(req.params.id);
  const body = (req.body ?? {}) as { serverId?: unknown; variables?: unknown };
  const serverId = typeof body.serverId === "number" ? body.serverId : Number(body.serverId);
  if (!id || !Number.isInteger(serverId) || serverId < 1) {
    res.status(400).json({ error: "Choose a server to run the script on." });
    return;
  }
  const [script] = await db.select().from(installScriptsTable).where(eq(installScriptsTable.id, id)).limit(1);
  if (!script) {
    res.status(404).json({ error: "Script not found" });
    return;
  }
  const auth = (req as AuthenticatedRequest).auth;
  if (auth.kind === "user" && !canAccessServer(auth.access, serverId)) {
    res.status(403).json({ error: "You do not have access to this server." });
    return;
  }
  const [server] = await db.select().from(serversTable).where(eq(serversTable.id, serverId)).limit(1);
  if (!server) {
    res.status(404).json({ error: "Server not found" });
    return;
  }
  if (getActiveJobForServer(server.id)) {
    res.status(409).json({ error: "A script is already running on this server. Wait for it to finish or cancel it." });
    return;
  }

  const definition = formatScript(script);
  const provided = (body.variables && typeof body.variables === "object" ? body.variables : {}) as Record<string, unknown>;
  const values = new Map<string, string>([
    ["server_name", server.name],
    ["server_dir", server.directory],
    ["port", server.port ? String(server.port) : ""],
  ]);
  for (const variable of definition.variables as ScriptVariable[]) {
    const raw = Object.prototype.hasOwnProperty.call(provided, variable.key) ? provided[variable.key] : undefined;
    const value = typeof raw === "string" ? raw.trim() : variable.defaultValue;
    if (!value) {
      res.status(400).json({ error: `Fill in "${variable.label}".` });
      return;
    }
    if (/[\r\n]/.test(value) || value.length > 500) {
      res.status(400).json({ error: `"${variable.label}" must be a single line (up to 500 characters).` });
      return;
    }
    if (variable.group && variable.group.length >= 2) {
      const parts = splitGroupValue(value, variable.group.length);
      if (!parts) {
        res.status(400).json({ error: `Enter ${variable.group.length} values for "${variable.label}" (${variable.group.join(", ")}), separated by a space or comma.` });
        return;
      }
      variable.group.forEach((name, position) => values.set(name, parts[position]));
    } else {
      values.set(variable.key, value);
    }
  }

  const steps: ScriptStep[] = [];
  const unknown = new Set<string>();
  for (const step of definition.steps as ScriptStep[]) {
    const result = substituteStep(step, values);
    result.unknown.forEach((key) => unknown.add(key));
    steps.push(result.step);
  }
  if (unknown.size) {
    res.status(400).json({ error: `Unknown variable(s): ${[...unknown].map((key) => `{{${key}}}`).join(", ")}. Add them to the script's variables.` });
    return;
  }

  const runId = startScriptJob(script, server, steps);
  res.status(202).json({ runId });
});

function runVisibleToUser(req: AuthenticatedRequest, runId: string): boolean {
  const auth = req.auth;
  if (auth.kind === "admin") return true;
  const view = getJobView(runId, 0);
  return Boolean(view) && canAccessServer(auth.access, view!.serverId);
}

router.get("/script-runs/:runId", (req, res): void => {
  const since = Math.max(0, Number(req.query.since) || 0);
  const view = runVisibleToUser(req as AuthenticatedRequest, req.params.runId) ? getJobView(req.params.runId, since) : null;
  if (!view) {
    res.status(404).json({ error: "This run is no longer available." });
    return;
  }
  res.json(view);
});

router.post("/script-runs/:runId/cancel", (req, res): void => {
  if (!runVisibleToUser(req as AuthenticatedRequest, req.params.runId) || !cancelJob(req.params.runId)) {
    res.status(404).json({ error: "This run is not active." });
    return;
  }
  res.json({ ok: true });
});

export default router;
