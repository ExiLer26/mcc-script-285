import { Router, type IRouter } from "express";
import { activityTable, db } from "@workspace/db";
import { requireAuth } from "../middlewares/auth";

const router: IRouter = Router();
router.use(requireAuth);

// Deletes every entry of the recent activity list from the database.
router.delete("/activity", async (_req, res): Promise<void> => {
  try {
    await db.delete(activityTable);
    res.sendStatus(204);
  } catch (error) {
    res.status(500).json({ error: `Could not clear the activity: ${error instanceof Error ? error.message : "database error"}` });
  }
});

export default router;
