import type { NextFunction, Request, Response } from "express";
import { getSessionPrincipal, SESSION_COOKIE, type Principal } from "../lib/auth";
import { authorizeUserRequest } from "../lib/permissions";

export type AuthenticatedRequest = Request & { auth: Principal };

// Administrators may use everything. Limited users are checked against their permissions and
// are denied by default on any path that is not explicitly allowed (see lib/permissions.ts).
export async function requireAuth(req: Request, res: Response, next: NextFunction): Promise<void> {
  const principal = await getSessionPrincipal(req.cookies?.[SESSION_COOKIE]);
  if (!principal) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }
  if (principal.kind === "user") {
    const path = req.originalUrl.split("?")[0].replace(/^\/api(?=\/|$)/, "") || "/";
    const denial = authorizeUserRequest(principal.access, req.method, path, req.body);
    if (denial) {
      res.status(403).json({ error: denial });
      return;
    }
  }
  (req as AuthenticatedRequest).auth = principal;
  next();
}

export async function requireAdmin(req: Request, res: Response, next: NextFunction): Promise<void> {
  const principal = await getSessionPrincipal(req.cookies?.[SESSION_COOKIE]);
  if (!principal) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }
  if (principal.kind !== "admin") {
    res.status(403).json({ error: "This area is only available to administrators." });
    return;
  }
  (req as AuthenticatedRequest).auth = principal;
  next();
}
