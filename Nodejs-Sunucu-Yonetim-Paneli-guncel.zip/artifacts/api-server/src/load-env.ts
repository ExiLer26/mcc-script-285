// Loads variables from a ".env" file in the api-server folder when it exists, so the
// panel starts the same way everywhere (Replit, Termux, a VPS) without extra node flags.
// Variables that are already set in the environment are never overwritten.
try {
  (process as unknown as { loadEnvFile?: (path?: string) => void }).loadEnvFile?.(".env");
} catch {
  // No .env file: the environment must already contain PORT and DATABASE_URL.
}

export {};
