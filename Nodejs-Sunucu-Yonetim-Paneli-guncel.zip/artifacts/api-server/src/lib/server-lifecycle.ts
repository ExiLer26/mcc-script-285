import { eq } from "drizzle-orm";
import { activityTable, db, serversTable, type ManagedServer } from "@workspace/db";
import { logger } from "./logger";
import { getManagedProcess, startManagedProcess } from "./process-manager";
import { getTerminalSettings } from "./terminal-settings";

const CRASH_START_WINDOW_MS = 10 * 60 * 1000;
const MAX_CRASH_START_ATTEMPTS = 5;
const crashStartTimers = new Map<number, NodeJS.Timeout>();
const crashStartAttempts = new Map<number, { windowStartedAt: number; attempts: number }>();

export function cancelScheduledCrashStart(id: number): void {
  const timer = crashStartTimers.get(id);
  if (timer) clearTimeout(timer);
  crashStartTimers.delete(id);
}

export function clearCrashStartRetryState(id: number): void {
  cancelScheduledCrashStart(id);
  crashStartAttempts.delete(id);
}

function scheduleCrashStart(server: ManagedServer): void {
  if (!server.crashStart) return;
  cancelScheduledCrashStart(server.id);

  const now = Date.now();
  let attemptState = crashStartAttempts.get(server.id);
  if (!attemptState || now - attemptState.windowStartedAt >= CRASH_START_WINDOW_MS) {
    attemptState = { windowStartedAt: now, attempts: 0 };
  }
  if (attemptState.attempts >= MAX_CRASH_START_ATTEMPTS) {
    logger.error(
      { serverId: server.id, attempts: attemptState.attempts },
      "Crash-start paused after repeated process exits",
    );
    crashStartAttempts.set(server.id, attemptState);
    return;
  }
  attemptState.attempts += 1;
  crashStartAttempts.set(server.id, attemptState);

  const timer = setTimeout(() => {
    crashStartTimers.delete(server.id);
    void (async () => {
      const [current] = await db
        .select()
        .from(serversTable)
        .where(eq(serversTable.id, server.id))
        .limit(1);
      if (!current?.crashStart) return;
      try {
        await startManagedServerProcess(current, { crashRestart: true });
      } catch (error) {
        logger.error(
          { err: error, serverId: server.id, attempt: attemptState.attempts },
          "Could not restart crashed managed process",
        );
      }
    })().catch((error) => {
      logger.error({ err: error, serverId: server.id }, "Could not schedule crash-start retry");
    });
  }, server.crashStartDelaySeconds * 1000);
  timer.unref();
  crashStartTimers.set(server.id, timer);
}

async function handleManagedProcessExit(
  id: number,
  code: number | null,
  signal: NodeJS.Signals | null,
  unexpected: boolean,
): Promise<void> {
  const [server] = await db.select().from(serversTable).where(eq(serversTable.id, id)).limit(1);
  if (!server) return;

  const runningProcess = getManagedProcess(id);
  if (runningProcess && Date.now() - runningProcess.startedAt >= CRASH_START_WINDOW_MS) {
    crashStartAttempts.delete(id);
  }
  const failed = code !== 0 && signal === null;
  await db.update(serversTable)
    .set({ status: failed ? "failed" : "offline", pid: null, updatedAt: new Date() })
    .where(eq(serversTable.id, id));
  await db.insert(activityTable).values({
    message: `${server.name} ${failed ? "process exited with an error" : "stopped"}`,
    kind: failed ? "error" : "warning",
  });
  if (unexpected) scheduleCrashStart(server);
}

export async function startManagedServerProcess(
  server: ManagedServer,
  options: { crashRestart?: boolean } = {},
): Promise<ManagedServer> {
  cancelScheduledCrashStart(server.id);
  if (!options.crashRestart) crashStartAttempts.delete(server.id);
  const terminalSettings = await getTerminalSettings(server.id);
  const child = startManagedProcess(server.id, server.command, server.directory, (code, signal, unexpected) => {
    void handleManagedProcessExit(server.id, code, signal, unexpected).catch((error) => {
      logger.error({ err: error, serverId: server.id }, "Could not record managed process exit");
    });
  }, server.port, terminalSettings.outputEncoding);

  const startedAt = new Date();
  const [updated] = await db.update(serversTable)
    .set({
      status: "online",
      pid: child.pid ?? null,
      lastStartedAt: startedAt,
      updatedAt: startedAt,
    })
    .where(eq(serversTable.id, server.id))
    .returning();
  await db.insert(activityTable).values({ message: `${server.name} started`, kind: "success" });

  return updated ?? { ...server, status: "online", pid: child.pid ?? null, lastStartedAt: startedAt, updatedAt: startedAt };
}
