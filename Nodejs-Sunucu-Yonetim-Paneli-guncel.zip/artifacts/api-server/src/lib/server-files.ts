import { constants as fsConstants, createWriteStream } from "node:fs";
import { spawn } from "node:child_process";
import http from "node:http";
import https from "node:https";
import dns from "node:dns";
import net from "node:net";
import { pipeline } from "node:stream/promises";
import yauzl from "yauzl";
import {
  chmod,
  lstat,
  mkdtemp,
  mkdir,
  open,
  readFile,
  readdir,
  realpath,
  rename,
  rm,
  stat,
  unlink,
} from "node:fs/promises";
import { randomUUID } from "node:crypto";
import { tmpdir } from "node:os";
import { TextDecoder } from "node:util";
import path from "node:path";
import type { ManagedServer } from "@workspace/db";

const MAX_TEXT_BYTES = 1024 * 1024;
export const MAX_UPLOAD_BYTES = 50 * 1024 * 1024;
const MAX_DIRECTORY_ENTRIES = 1000;
const MAX_ARCHIVE_SELECTIONS = 200;

export class ServerFilesError extends Error {
  constructor(
    readonly status: number,
    message: string,
  ) {
    super(message);
    this.name = "ServerFilesError";
  }
}

function normalizeRelativePath(value: string | undefined): string {
  const raw = (value ?? "").replace(/\\/g, "/");
  if (raw.includes("\0") || raw.length > 2000 || raw.startsWith("/")) {
    throw new ServerFilesError(400, "Invalid file path.");
  }

  const segments = raw.split("/");
  if (segments.some((segment) => segment === "..")) {
    throw new ServerFilesError(400, "Paths cannot leave the configured server folder.");
  }

  const normalized = segments.filter((segment) => segment && segment !== ".").join(path.sep);
  return normalized || ".";
}

function pathIsInside(root: string, candidate: string): boolean {
  const relative = path.relative(root, candidate);
  return relative === "" ||
    (relative !== ".." && !relative.startsWith(`..${path.sep}`) && !path.isAbsolute(relative));
}

function displayPath(relative: string): string {
  return relative === "." ? "" : relative.split(path.sep).join("/");
}

function toFileError(error: unknown): ServerFilesError | undefined {
  if (error instanceof ServerFilesError) return error;
  const code = (error as NodeJS.ErrnoException | undefined)?.code;
  if (code === "ENOENT" || code === "ENOTDIR") {
    return new ServerFilesError(404, "The requested file or folder was not found.");
  }
  if (code === "EEXIST") {
    return new ServerFilesError(409, "A file or folder with that name already exists.");
  }
  if (code === "EACCES" || code === "EPERM") {
    return new ServerFilesError(403, "The process folder does not allow this operation.");
  }
  if (code === "ENAMETOOLONG" || code === "EINVAL") {
    return new ServerFilesError(400, "Invalid file path.");
  }
  return undefined;
}

async function resolveServerRoot(server: ManagedServer): Promise<string> {
  let root: string;
  try {
    root = await realpath(server.directory);
  } catch (error) {
    const known = toFileError(error);
    if (known) throw known;
    throw error;
  }

  const rootStats = await stat(root);
  if (!rootStats.isDirectory()) {
    throw new ServerFilesError(400, "The configured process folder is not a directory.");
  }
  return root;
}

type ResolvedEntry = {
  absolutePath: string;
  relativePath: string;
  stats: Awaited<ReturnType<typeof lstat>>;
};

async function resolveExistingEntry(
  root: string,
  inputPath: string | undefined,
  options: { allowFinalSymlink?: boolean } = {},
): Promise<ResolvedEntry> {
  const relativePath = normalizeRelativePath(inputPath);
  const segments = relativePath === "." ? [] : relativePath.split(path.sep);
  let absolutePath = root;
  let entryStats = await lstat(root);

  for (let index = 0; index < segments.length; index += 1) {
    absolutePath = path.join(absolutePath, segments[index]);
    entryStats = await lstat(absolutePath);
    const isFinalSegment = index === segments.length - 1;

    if (entryStats.isSymbolicLink()) {
      if (options.allowFinalSymlink && isFinalSegment) {
        return { absolutePath, relativePath, stats: entryStats };
      }
      throw new ServerFilesError(400, "Symbolic links cannot be opened or navigated.");
    }

    const canonicalPath = await realpath(absolutePath);
    if (!pathIsInside(root, canonicalPath)) {
      throw new ServerFilesError(400, "Paths cannot leave the configured server folder.");
    }
    if (!isFinalSegment && !entryStats.isDirectory()) {
      throw new ServerFilesError(400, "A path segment is not a folder.");
    }
  }

  return { absolutePath, relativePath, stats: entryStats };
}

async function resolveNewEntry(
  root: string,
  inputPath: string,
): Promise<{ absolutePath: string; relativePath: string }> {
  const relativePath = normalizeRelativePath(inputPath);
  if (relativePath === ".") {
    throw new ServerFilesError(400, "Choose a name inside the process folder.");
  }

  const segments = relativePath.split(path.sep);
  const name = segments.pop();
  if (!name || name.includes("/") || name.includes("\0")) {
    throw new ServerFilesError(400, "Invalid file name.");
  }

  const parentPath = segments.join(path.sep) || ".";
  const parent = await resolveExistingEntry(root, parentPath);
  if (!parent.stats.isDirectory()) {
    throw new ServerFilesError(400, "The destination parent is not a folder.");
  }

  const absolutePath = path.join(parent.absolutePath, name);
  if (!pathIsInside(root, absolutePath)) {
    throw new ServerFilesError(400, "Paths cannot leave the configured server folder.");
  }
  return { absolutePath, relativePath };
}

function entryKind(stats: Awaited<ReturnType<typeof lstat>>): "file" | "directory" | "link" {
  if (stats.isSymbolicLink()) return "link";
  if (stats.isDirectory()) return "directory";
  if (stats.isFile()) return "file";
  return "link";
}

function toEntry(name: string, relativePath: string, stats: Awaited<ReturnType<typeof lstat>>) {
  return {
    name,
    path: displayPath(relativePath),
    kind: entryKind(stats),
    size: stats.isFile() ? Number(stats.size) : 0,
    modifiedAt: stats.mtime.toISOString(),
    mode: (stats.mode && 0o777).toString(8).padStart(3, "0"),
  };
}

export async function listServerDirectory(server: ManagedServer, inputPath?: string) {
  const root = await resolveServerRoot(server);
  const directory = await resolveExistingEntry(root, inputPath);
  if (!directory.stats.isDirectory()) {
    throw new ServerFilesError(400, "The selected path is not a folder.");
  }

  const names = await readdir(directory.absolutePath);
  const truncated = names.length > MAX_DIRECTORY_ENTRIES;
  const entries = await Promise.all(
    names.slice(0, MAX_DIRECTORY_ENTRIES).map(async (name) => {
      const entryPath = path.join(directory.absolutePath, name);
      const stats = await lstat(entryPath);
      const relativePath = directory.relativePath === "."
        ? name
        : path.join(directory.relativePath, name);
      return toEntry(name, relativePath, stats);
    }),
  );

  entries.sort((a, b) => {
    const aDirectory = a.kind === "directory" ? 0 : 1;
    const bDirectory = b.kind === "directory" ? 0 : 1;
    return aDirectory - bDirectory || a.name.localeCompare(b.name, undefined, { sensitivity: "base" });
  });

  const currentPath = displayPath(directory.relativePath);
  const parentPath = currentPath
    ? displayPath(path.dirname(directory.relativePath))
    : null;

  return { currentPath, parentPath, entries, truncated };
}

export async function readServerTextFile(server: ManagedServer, inputPath: string) {
  const root = await resolveServerRoot(server);
  const file = await resolveExistingEntry(root, inputPath);
  if (!file.stats.isFile()) {
    throw new ServerFilesError(400, "Only regular text files can be opened.");
  }
  if (file.stats.size > MAX_TEXT_BYTES) {
    throw new ServerFilesError(413, "This file is too large to open in the editor.");
  }

  const bytes = await readFile(file.absolutePath);
  if (bytes.includes(0)) {
    throw new ServerFilesError(415, "This file is binary and cannot be edited as text.");
  }
  let content: string;
  try {
    content = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
  } catch {
    throw new ServerFilesError(415, "This file is not valid UTF-8 text.");
  }

  const currentStats = await lstat(file.absolutePath);
  return {
    path: displayPath(file.relativePath),
    content,
    size: bytes.byteLength,
    modifiedAt: currentStats.mtime.toISOString(),
  };
}

export async function saveServerTextFile(server: ManagedServer, inputPath: string, content: string) {
  const bytes = Buffer.from(content, "utf8");
  if (bytes.byteLength > MAX_TEXT_BYTES) {
    throw new ServerFilesError(413, "Text files are limited to 1 MiB.");
  }

  const root = await resolveServerRoot(server);
  const file = await resolveExistingEntry(root, inputPath);
  if (!file.stats.isFile()) {
    throw new ServerFilesError(400, "Only regular text files can be edited.");
  }
  await readServerTextFile(server, inputPath);

  const temporaryPath = path.join(
    path.dirname(file.absolutePath),
    `.nodewatch-${randomUUID()}.tmp`,
  );
  const mode = Number(file.stats.mode) & 0o777;
  try {
    const handle = await open(
      temporaryPath,
      fsConstants.O_WRONLY | fsConstants.O_CREAT | fsConstants.O_EXCL | fsConstants.O_NOFOLLOW,
      mode,
    );
    try {
      await handle.writeFile(bytes);
    } finally {
      await handle.close();
    }
    await rename(temporaryPath, file.absolutePath);
  } catch (error) {
    await unlink(temporaryPath).catch(() => undefined);
    throw error;
  }

  const savedStats = await lstat(file.absolutePath);
  return {
    path: displayPath(file.relativePath),
    size: bytes.byteLength,
    modifiedAt: savedStats.mtime.toISOString(),
  };
}

export async function createServerTextFile(server: ManagedServer, inputPath: string, content: string) {
  const bytes = Buffer.from(content, "utf8");
  if (bytes.byteLength > MAX_TEXT_BYTES) {
    throw new ServerFilesError(413, "Text files are limited to 1 MiB.");
  }

  const root = await resolveServerRoot(server);
  const target = await resolveNewEntry(root, inputPath);
  const handle = await open(
    target.absolutePath,
    fsConstants.O_WRONLY | fsConstants.O_CREAT | fsConstants.O_EXCL | fsConstants.O_NOFOLLOW,
    0o644,
  );
  try {
    await handle.writeFile(bytes);
  } finally {
    await handle.close();
  }

  const stats = await lstat(target.absolutePath);
  return {
    path: displayPath(target.relativePath),
    size: bytes.byteLength,
    modifiedAt: stats.mtime.toISOString(),
  };
}

export async function createServerFolder(server: ManagedServer, inputPath: string) {
  const root = await resolveServerRoot(server);
  const target = await resolveNewEntry(root, inputPath);
  await mkdir(target.absolutePath, { mode: 0o755 });
  const stats = await lstat(target.absolutePath);
  return toEntry(path.basename(target.absolutePath), target.relativePath, stats);
}

export async function uploadServerFile(
  server: ManagedServer,
  directoryPath: string | undefined,
  fileName: string,
  bytes: Buffer,
) {
  if (bytes.byteLength > MAX_UPLOAD_BYTES) {
    throw new ServerFilesError(413, "Uploads are limited to 50 MiB.");
  }
  if (
    !fileName ||
    fileName === "." ||
    fileName === ".." ||
    /[\/\\\0-\x1f\x7f]/.test(fileName)
  ) {
    throw new ServerFilesError(400, "Invalid upload file name.");
  }

  const root = await resolveServerRoot(server);
  const directory = await resolveExistingEntry(root, directoryPath);
  if (!directory.stats.isDirectory()) {
    throw new ServerFilesError(400, "The upload destination is not a folder.");
  }

  const relativePath = directory.relativePath === "."
    ? fileName
    : path.join(directory.relativePath, fileName);
  const target = await resolveNewEntry(root, relativePath);
  const handle = await open(
    target.absolutePath,
    fsConstants.O_WRONLY | fsConstants.O_CREAT | fsConstants.O_EXCL | fsConstants.O_NOFOLLOW,
    0o644,
  );
  try {
    await handle.writeFile(bytes);
  } finally {
    await handle.close();
  }

  const stats = await lstat(target.absolutePath);
  return toEntry(fileName, target.relativePath, stats);
}

export async function moveServerEntry(server: ManagedServer, sourcePath: string, destinationPath: string) {
  const root = await resolveServerRoot(server);
  const source = await resolveExistingEntry(root, sourcePath);
  if (source.relativePath === ".") {
    throw new ServerFilesError(400, "The process root folder cannot be moved.");
  }
  if (source.stats.isSymbolicLink()) {
    throw new ServerFilesError(400, "Symbolic links cannot be moved.");
  }
  const destination = await resolveNewEntry(root, destinationPath);
  if (
    source.stats.isDirectory() &&
    (destination.absolutePath === source.absolutePath ||
      destination.absolutePath.startsWith(`${source.absolutePath}${path.sep}`))
  ) {
    throw new ServerFilesError(409, "A folder cannot be moved into itself.");
  }

  try {
    await lstat(destination.absolutePath);
    throw new ServerFilesError(409, "A file or folder with that name already exists.");
  } catch (error) {
    if (error instanceof ServerFilesError) throw error;
    if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
  }

  await rename(source.absolutePath, destination.absolutePath);
  return {
    sourcePath: displayPath(source.relativePath),
    destinationPath: displayPath(destination.relativePath),
  };
}

export async function deleteServerEntry(server: ManagedServer, inputPath: string): Promise<void> {
  const root = await resolveServerRoot(server);
  const entry = await resolveExistingEntry(root, inputPath, { allowFinalSymlink: true });
  if (entry.relativePath === ".") {
    throw new ServerFilesError(400, "The process root folder cannot be deleted.");
  }
  await rm(entry.absolutePath, { recursive: true, force: false });
}

export async function getServerFileDownload(server: ManagedServer, inputPath: string) {
  const root = await resolveServerRoot(server);
  const file = await resolveExistingEntry(root, inputPath);
  if (!file.stats.isFile()) {
    throw new ServerFilesError(400, "Only regular files can be downloaded.");
  }
  return { absolutePath: file.absolutePath, fileName: path.basename(file.absolutePath) };
}

export type ServerFilesArchive = {
  directoryPath: string;
  filePath: string;
  fileName: string;
};

export async function createServerFilesArchive(
  server: ManagedServer,
  inputPaths: string[],
): Promise<ServerFilesArchive> {
  if (inputPaths.length === 0 || inputPaths.length > MAX_ARCHIVE_SELECTIONS) {
    throw new ServerFilesError(400, `Select between 1 and ${MAX_ARCHIVE_SELECTIONS} items.`);
  }

  const normalizedPaths = [...new Set(
    inputPaths.map((inputPath) => displayPath(normalizeRelativePath(inputPath))),
  )];
  if (normalizedPaths.includes("")) {
    throw new ServerFilesError(400, "The process root folder cannot be archived.");
  }

  const root = await resolveServerRoot(server);
  const entries = await Promise.all(
    normalizedPaths.map((inputPath) => resolveExistingEntry(root, inputPath)),
  );
  if (entries.some((entry) => !entry.stats.isFile() && !entry.stats.isDirectory())) {
    throw new ServerFilesError(400, "Only files and folders can be added to an archive.");
  }

  const directoryPath = await mkdtemp(path.join(tmpdir(), "nodewatch-server-files-"));
  const filePath = path.join(directoryPath, "selected-files.zip");
  try {
    await new Promise<void>((resolve, reject) => {
      const child = spawn(
        "zip",
        ["-r", "-q", "-y", filePath, ...normalizedPaths.map((itemPath) => `./${itemPath}`)],
        { cwd: root, stdio: ["ignore", "ignore", "pipe"] },
      );
      let stderr = "";
      child.stderr?.setEncoding("utf8");
      child.stderr?.on("data", (chunk: string) => {
        if (stderr.length < 4000) stderr += chunk.slice(0, 4000 - stderr.length);
      });
      child.once("error", reject);
      child.once("close", (code, signal) => {
        if (code === 0) {
          resolve();
        } else {
          reject(new Error(`zip exited with code ${code ?? "null"} (${signal ?? "no signal"}): ${stderr.trim()}`));
        }
      });
    });

    const archiveStats = await stat(filePath);
    if (!archiveStats.isFile() || archiveStats.size === 0) {
      throw new Error("zip did not create a valid archive.");
    }
    return { directoryPath, filePath, fileName: "selected-files.zip" };
  } catch (error) {
    await rm(directoryPath, { recursive: true, force: true });
    throw error;
  }
}

export async function removeServerFilesArchive(archive: ServerFilesArchive): Promise<void> {
  await rm(archive.directoryPath, { recursive: true, force: true });
}

// ---------------------------------------------------------------------------
// Download from URL
// ---------------------------------------------------------------------------

export const MAX_URL_DOWNLOAD_BYTES = 500 * 1024 * 1024;
const MAX_REDIRECTS = 5;
const URL_DOWNLOAD_TIMEOUT_MS = 10 * 60 * 1000;

function isPrivateAddress(address: string): boolean {
  if (net.isIPv4(address)) {
    const [a, b] = address.split(".").map(Number);
    return (
      a === 0 || a === 10 || a === 127 ||
      (a === 100 && b >= 64 && b <= 127) ||
      (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) ||
      (a === 192 && b === 168) ||
      (a === 192 && b === 0) ||
      (a === 198 && (b === 18 || b === 19)) ||
      a >= 224
    );
  }
  if (net.isIPv6(address)) {
    const lower = address.toLowerCase();
    if (lower === "::" || lower === "::1") return true;
    const mapped = lower.match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/);
    if (mapped) return isPrivateAddress(mapped[1]);
    return /^f[cd]/.test(lower) || /^fe[89ab]/.test(lower) || lower.startsWith("ff");
  }
  return true;
}

// Validates every resolved address at connect time so DNS rebinding and
// redirects to internal hosts cannot reach private networks.
const safeLookup: net.LookupFunction = (hostname, options, callback) => {
  dns.lookup(hostname, { ...options, all: true }, (error, addresses) => {
    if (error) {
      (callback as (e: NodeJS.ErrnoException | null, a?: string, f?: number) => void)(error);
      return;
    }
    const list = addresses as dns.LookupAddress[];
    if (list.length === 0 || list.some((entry) => isPrivateAddress(entry.address))) {
      (callback as (e: NodeJS.ErrnoException | null) => void)(
        new ServerFilesError(403, "Downloads from private or local network addresses are not allowed."),
      );
      return;
    }
    if ((options as { all?: boolean }).all) {
      (callback as unknown as (e: null, a: dns.LookupAddress[]) => void)(null, list);
    } else {
      (callback as (e: null, a: string, f: number) => void)(null, list[0].address, list[0].family);
    }
  });
};

function fetchStream(
  url: URL,
  redirectsLeft: number,
): Promise<{ response: http.IncomingMessage; finalUrl: URL }> {
  return new Promise((resolve, reject) => {
    if (url.protocol !== "http:" && url.protocol !== "https:") {
      reject(new ServerFilesError(400, "Only http and https URLs are supported."));
      return;
    }
    if (net.isIP(url.hostname.replace(/^\[|\]$/g, "")) && isPrivateAddress(url.hostname.replace(/^\[|\]$/g, ""))) {
      reject(new ServerFilesError(403, "Downloads from private or local network addresses are not allowed."));
      return;
    }
    const client: typeof http = url.protocol === "https:" ? (https as unknown as typeof http) : http;
    const request = client.get(
      url,
      { lookup: safeLookup, headers: { "User-Agent": "nodewatch-downloader", Accept: "*/*" } },
      (response) => {
        const status = response.statusCode ?? 0;
        if (status >= 300 && status < 400 && response.headers.location) {
          response.resume();
          if (redirectsLeft <= 0) {
            reject(new ServerFilesError(400, "Too many redirects."));
            return;
          }
          let next: URL;
          try {
            next = new URL(response.headers.location, url);
          } catch {
            reject(new ServerFilesError(400, "Invalid redirect URL."));
            return;
          }
          fetchStream(next, redirectsLeft - 1).then(resolve, reject);
          return;
        }
        if (status < 200 || status >= 300) {
          response.resume();
          reject(new ServerFilesError(400, `The remote server responded with HTTP ${status}.`));
          return;
        }
        resolve({ response, finalUrl: url });
      },
    );
    request.setTimeout(URL_DOWNLOAD_TIMEOUT_MS, () => request.destroy(new ServerFilesError(400, "The download timed out.")));
    request.on("error", (error) => {
      if (error instanceof ServerFilesError) reject(error);
      else if ((error as NodeJS.ErrnoException).cause instanceof ServerFilesError) reject((error as NodeJS.ErrnoException).cause);
      else reject(new ServerFilesError(400, `Could not download the URL: ${error.message}`));
    });
  });
}

function fileNameFromDownload(response: http.IncomingMessage, finalUrl: URL): string {
  const disposition = response.headers["content-disposition"];
  if (typeof disposition === "string") {
    const star = disposition.match(/filename\*\s*=\s*(?:UTF-8'')?([^;]+)/i);
    const plain = disposition.match(/filename\s*=\s*"?([^";]+)"?/i);
    const raw = star?.[1] ?? plain?.[1];
    if (raw) {
      try {
        return path.basename(decodeURIComponent(raw.trim()));
      } catch {
        return path.basename(raw.trim());
      }
    }
  }
  const last = finalUrl.pathname.split("/").filter(Boolean).pop();
  if (last) {
    try {
      return decodeURIComponent(last);
    } catch {
      return last;
    }
  }
  return "download";
}

export async function downloadServerFileFromUrl(
  server: ManagedServer,
  rawUrl: string,
  directoryPath: string | undefined,
  fileNameOverride?: string,
) {
  let url: URL;
  try {
    url = new URL(rawUrl.trim());
  } catch {
    throw new ServerFilesError(400, "Enter a valid http(s) URL.");
  }
  const root = await resolveServerRoot(server);
  const directory = await resolveExistingEntry(root, directoryPath);
  if (!directory.stats.isDirectory()) {
    throw new ServerFilesError(400, "The download destination is not a folder.");
  }

  const { response, finalUrl } = await fetchStream(url, MAX_REDIRECTS);
  const declared = Number(response.headers["content-length"] ?? 0);
  if (declared > MAX_URL_DOWNLOAD_BYTES) {
    response.destroy();
    throw new ServerFilesError(413, "The file exceeds the 500 MiB download limit.");
  }

  const fileName = fileNameOverride?.trim() || fileNameFromDownload(response, finalUrl);
  if (!fileName || fileName === "." || fileName === ".." || /[\/\\\0-\x1f\x7f]/.test(fileName)) {
    response.destroy();
    throw new ServerFilesError(400, "Could not determine a safe file name from the URL.");
  }
  const relativePath = directory.relativePath === "." ? fileName : path.join(directory.relativePath, fileName);
  let target: { absolutePath: string; relativePath: string };
  try {
    target = await resolveNewEntry(root, relativePath);
  } catch (error) {
    response.destroy();
    throw error;
  }

  let handle;
  try {
    handle = await open(
      target.absolutePath,
      fsConstants.O_WRONLY | fsConstants.O_CREAT | fsConstants.O_EXCL | fsConstants.O_NOFOLLOW,
      0o644,
    );
  } catch (error) {
    response.destroy();
    throw error;
  }

  let received = 0;
  try {
    const output = handle.createWriteStream();
    response.on("data", (chunk: Buffer) => {
      received += chunk.length;
      if (received > MAX_URL_DOWNLOAD_BYTES) {
        response.destroy(new ServerFilesError(413, "The file exceeds the 500 MiB download limit."));
      }
    });
    await pipeline(response, output);
  } catch (error) {
    await handle.close().catch(() => undefined);
    await unlink(target.absolutePath).catch(() => undefined);
    if (error instanceof ServerFilesError) throw error;
    throw new ServerFilesError(400, `The download failed: ${(error as Error).message}`);
  }
  await handle.close().catch(() => undefined);

  const stats = await lstat(target.absolutePath);
  return toEntry(fileName, target.relativePath, stats);
}

// ---------------------------------------------------------------------------
// ZIP extraction
// ---------------------------------------------------------------------------

const MAX_EXTRACT_FILES = 20000;
const MAX_EXTRACT_BYTES = 2 * 1024 * 1024 * 1024;

export async function extractServerZipArchive(server: ManagedServer, inputPath: string) {
  const root = await resolveServerRoot(server);
  const archive = await resolveExistingEntry(root, inputPath);
  if (!archive.stats.isFile() || !/\.zip$/i.test(archive.absolutePath)) {
    throw new ServerFilesError(400, "Select a .zip file to extract.");
  }

  // Extract straight into the folder that holds the archive (no extra folder).
  const targetRelative = path.dirname(archive.relativePath);
  const target = await resolveExistingEntry(root, targetRelative === "." ? "" : targetRelative);
  const extractRoot = await realpath(target.absolutePath);
  const archiveReal = await realpath(archive.absolutePath);
  const createdFiles: string[] = [];

  let files = 0;
  let bytes = 0;

  try {
    await new Promise<void>((resolve, reject) => {
      yauzl.open(archive.absolutePath, { lazyEntries: true, autoClose: true }, (openError, zip) => {
        if (openError || !zip) {
          reject(new ServerFilesError(400, "The file is not a valid ZIP archive."));
          return;
        }
        const fail = (error: unknown) => {
          zip.close();
          reject(error);
        };
        zip.on("error", fail);
        zip.on("end", () => resolve());
        zip.on("entry", (entry: yauzl.Entry) => {
          void (async () => {
            const name = entry.fileName.replace(/\\/g, "/");
            if (name.includes("\0") || name.startsWith("/") || /^[a-zA-Z]:/.test(name) || name.split("/").includes("..")) {
              throw new ServerFilesError(400, `Unsafe path in archive: ${name}`);
            }
            const destination = path.resolve(extractRoot, name);
            if (destination !== extractRoot && !pathIsInside(extractRoot, destination)) {
              throw new ServerFilesError(400, `Unsafe path in archive: ${name}`);
            }
            const unixMode = (entry.externalFileAttributes >>> 16) & 0xffff;
            const fileType = unixMode & 0o170000;
            if (fileType === 0o120000) {
              // Symbolic links are skipped for safety.
              zip.readEntry();
              return;
            }
            if (name.endsWith("/")) {
              await mkdir(destination, { recursive: true, mode: 0o755 });
              zip.readEntry();
              return;
            }
            files += 1;
            if (files > MAX_EXTRACT_FILES) {
              throw new ServerFilesError(413, "The archive contains too many files.");
            }
            if (bytes + entry.uncompressedSize > MAX_EXTRACT_BYTES) {
              throw new ServerFilesError(413, "The archive is too large to extract.");
            }
            await mkdir(path.dirname(destination), { recursive: true, mode: 0o755 });
            const canonicalParent = await realpath(path.dirname(destination));
            if (!pathIsInside(extractRoot, canonicalParent)) {
              throw new ServerFilesError(400, `Unsafe path in archive: ${name}`);
            }
            if (path.join(canonicalParent, path.basename(destination)) === archiveReal) {
              zip.readEntry();
              return;
            }
            const existing = await lstat(destination).catch(() => null);
            if (existing) {
              if (!existing.isFile()) {
                throw new ServerFilesError(409, `Cannot overwrite "${name}" because it is not a regular file.`);
              }
              await unlink(destination);
            }
            const mode = (unixMode & 0o777) || 0o644;
            zip.openReadStream(entry, (streamError, readStream) => {
              if (streamError || !readStream) {
                fail(streamError ?? new Error("Could not read archive entry."));
                return;
              }
              readStream.on("data", (chunk: Buffer) => {
                bytes += chunk.length;
                if (bytes > MAX_EXTRACT_BYTES) {
                  readStream.destroy(new ServerFilesError(413, "The archive is too large to extract."));
                }
              });
              const output = createWriteStream(destination, {
                flags: "wx",
                mode: mode | 0o600,
              });
              createdFiles.push(destination);
              pipeline(readStream, output).then(
                () => chmod(destination, (mode | 0o600) & 0o755).then(() => zip.readEntry(), fail),
                fail,
              );
            });
          })().catch(fail);
        });
        zip.readEntry();
      });
    });
  } catch (error) {
    await Promise.all(createdFiles.map((file) => unlink(file).catch(() => undefined)));
    throw error;
  }

  return { directory: displayPath(target.relativePath), extractedFiles: files, extractedBytes: bytes };
}

// ---------------------------------------------------------------------------
// chmod
// ---------------------------------------------------------------------------

export async function setServerFilePermissions(server: ManagedServer, inputPath: string, mode: string) {
  if (!/^[0-7]{3,4}$/.test(mode)) {
    throw new ServerFilesError(400, "Permission mode must be 3 or 4 octal digits (for example 755).");
  }
  const numeric = parseInt(mode, 8);
  if (numeric & 0o7000) {
    throw new ServerFilesError(400, "setuid, setgid and sticky bits are not allowed.");
  }
  const root = await resolveServerRoot(server);
  const entry = await resolveExistingEntry(root, inputPath);
  if (entry.stats.isSymbolicLink()) {
    throw new ServerFilesError(400, "Permissions cannot be changed on symbolic links.");
  }
  await chmod(entry.absolutePath, numeric);
  const stats = await lstat(entry.absolutePath);
  return toEntry(path.basename(entry.absolutePath) || "", entry.relativePath, stats);
}

export function mapServerFilesError(error: unknown): ServerFilesError | undefined {
  return toFileError(error);
}
