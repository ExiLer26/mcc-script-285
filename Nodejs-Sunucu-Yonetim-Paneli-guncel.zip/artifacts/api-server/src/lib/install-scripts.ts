import { spawn, type ChildProcess } from "node:child_process";
import { randomUUID } from "node:crypto";
import { eq, sql } from "drizzle-orm";
import { activityTable, db, installScriptsTable, serversTable, type InstallScript, type ManagedServer } from "@workspace/db";
import { logger } from "./logger";
import { buildChildEnv } from "./process-manager";
import {
  createServerFolder,
  createServerTextFile,
  deleteServerEntry,
  downloadServerFileFromUrl,
  extractServerZipArchive,
  listServerDirectory,
  mapServerFilesError,
  moveServerEntry,
  saveServerTextFile,
  ServerFilesError,
  setServerFilePermissions,
} from "./server-files";

/* ------------------------------------------------------------------ */
/* Types and validation                                                */
/* ------------------------------------------------------------------ */

export type StepType =
  | "download" | "unzip" | "chmod" | "mkdir" | "writeFile" | "delete" | "move" | "moveContents" | "command" | "setStartCommand";

export type ScriptStep = {
  type: StepType;
  ignoreErrors?: boolean;
  url?: string;
  directory?: string;
  fileName?: string;
  path?: string;
  deleteArchive?: boolean;
  overwrite?: boolean;
  removeEmptyFolder?: boolean;
  mode?: string;
  content?: string;
  from?: string;
  to?: string;
  command?: string;
  timeoutSeconds?: number;
};

export type ScriptVariable = { key: string; label: string; defaultValue: string; group?: string[] };

type StepSpec = { required: (keyof ScriptStep)[]; optional: (keyof ScriptStep)[]; bools?: (keyof ScriptStep)[]; numbers?: (keyof ScriptStep)[] };

const STEP_SPECS: Record<StepType, StepSpec> = {
  download: { required: ["url"], optional: ["directory", "fileName"] },
  unzip: { required: ["path"], optional: [], bools: ["deleteArchive"] },
  chmod: { required: ["path", "mode"], optional: [] },
  mkdir: { required: ["path"], optional: [] },
  writeFile: { required: ["path"], optional: ["content"] },
  delete: { required: ["path"], optional: [] },
  move: { required: ["from", "to"], optional: [] },
  moveContents: { required: ["from"], optional: ["to"], bools: ["overwrite", "removeEmptyFolder"] },
  command: { required: ["command"], optional: [], numbers: ["timeoutSeconds"] },
  setStartCommand: { required: ["command"], optional: [] },
};

const MAX_STEPS = 50;
const MAX_VARIABLES = 20;
const RESERVED_VARIABLES = ["server_name", "server_dir", "port", "__proto__", "constructor", "prototype"];
const PLACEHOLDER_PATTERN = /\{\{([^{}\r\n]+?)\}\}/g;
const SIMPLE_NAME_PATTERN = /^[A-Za-z_][A-Za-z0-9_]*$/;
export const MAX_VARIABLE_WORDS = 10;
export const MAX_VARIABLE_NAME_LENGTH = 64;

// Variable names can be several words and use any characters except { } and control characters.
// A name may also be typed as a placeholder, e.g. "{{name1}}" is stored as "name1".
export function normalizeVariableKey(raw: string): string {
  const collapsed = raw.replace(/\s+/g, " ").trim();
  const wrapped = collapsed.match(/^\{\{\s*([^{}]+?)\s*\}\}$/);
  return wrapped ? wrapped[1].replace(/\s+/g, " ").trim() : collapsed;
}

export type ScriptInput = { name: string; description: string; variables: ScriptVariable[]; steps: ScriptStep[] };

export function parseScriptInput(body: unknown): { ok: true; value: ScriptInput } | { ok: false; error: string } {
  if (!body || typeof body !== "object") return { ok: false, error: "Invalid script." };
  const input = body as Record<string, unknown>;
  const name = typeof input.name === "string" ? input.name.trim() : "";
  if (!name || name.length > 80) return { ok: false, error: "Script name must be 1-80 characters." };
  const description = typeof input.description === "string" ? input.description.trim().slice(0, 500) : "";

  const rawVariables = Array.isArray(input.variables) ? input.variables : [];
  if (rawVariables.length > MAX_VARIABLES) return { ok: false, error: `A script can have up to ${MAX_VARIABLES} variables.` };
  const variables: ScriptVariable[] = [];
  const usedNames = new Set<string>();
  const nameProblem = (key: string): string | null => {
    if (!key) return "Every variable needs a name.";
    if (key.length > MAX_VARIABLE_NAME_LENGTH) return `Variable names can be up to ${MAX_VARIABLE_NAME_LENGTH} characters ("${key.slice(0, 20)}…").`;
    if (key.split(" ").length > MAX_VARIABLE_WORDS) return `Variable names can have up to ${MAX_VARIABLE_WORDS} words ("${key.slice(0, 20)}…").`;
    // eslint-disable-next-line no-control-regex
    if (/[{}\u0000-\u001f\u007f]/.test(key)) return `The variable name "${key}" cannot contain { } or control characters.`;
    const lowered = key.toLowerCase();
    if (RESERVED_VARIABLES.includes(lowered) || usedNames.has(lowered)) return `The variable name "${key}" is reserved or duplicated.`;
    return null;
  };
  for (const raw of rawVariables) {
    const item = (raw ?? {}) as Record<string, unknown>;
    const label = typeof item.label === "string" ? item.label.trim().slice(0, 80) : "";
    const defaultValue = typeof item.defaultValue === "string" ? item.defaultValue.slice(0, 500) : "";
    if (/[\r\n]/.test(defaultValue)) return { ok: false, error: "A default value must be one line." };

    // One input box that fills several names: "{{a}}/{{b}}" asks for "valueA valueB".
    if (Array.isArray(item.group) && item.group.length >= 2) {
      if (item.group.length > MAX_VARIABLE_WORDS) return { ok: false, error: `A group can hold up to ${MAX_VARIABLE_WORDS} names.` };
      const group: string[] = [];
      for (const rawName of item.group) {
        const name = typeof rawName === "string" ? normalizeVariableKey(rawName) : "";
        const problem = nameProblem(name);
        if (problem) return { ok: false, error: problem };
        usedNames.add(name.toLowerCase());
        group.push(name);
      }
      variables.push({ key: group.join("/"), label: label || group.join(", "), defaultValue, group });
      continue;
    }

    const key = typeof item.key === "string" ? normalizeVariableKey(item.key) : "";
    const problem = nameProblem(key);
    if (problem) return { ok: false, error: problem };
    usedNames.add(key.toLowerCase());
    variables.push({ key, label: label || key, defaultValue });
  }

  const rawSteps = Array.isArray(input.steps) ? input.steps : [];
  if (!rawSteps.length) return { ok: false, error: "Add at least one step." };
  if (rawSteps.length > MAX_STEPS) return { ok: false, error: `A script can have up to ${MAX_STEPS} steps.` };
  const steps: ScriptStep[] = [];
  for (const [index, raw] of rawSteps.entries()) {
    const item = (raw ?? {}) as Record<string, unknown>;
    const type = item.type as StepType;
    const spec = STEP_SPECS[type];
    if (!spec) return { ok: false, error: `Step ${index + 1}: unknown step type.` };
    const step: ScriptStep = { type };
    for (const key of [...spec.required, ...spec.optional]) {
      const value = item[key];
      const text = typeof value === "string" ? (key === "content" ? value : value.trim()) : "";
      const limit = key === "content" ? 20_000 : 2_000;
      if (text.length > limit) return { ok: false, error: `Step ${index + 1}: "${key}" is too long.` };
      if (spec.required.includes(key) && !text) return { ok: false, error: `Step ${index + 1} (${type}): "${key}" is required.` };
      if (text && (key === "command" || key === "url") && /[\r\n]/.test(text)) return { ok: false, error: `Step ${index + 1}: "${key}" must be one line.` };
      if (text || key === "content") (step as Record<string, unknown>)[key] = text;
    }
    for (const key of spec.bools ?? []) if (item[key] === true) (step as Record<string, unknown>)[key] = true;
    for (const key of spec.numbers ?? []) {
      const value = Number(item[key]);
      if (item[key] !== undefined && item[key] !== "" && (!Number.isInteger(value) || value < 1 || value > 3600)) {
        return { ok: false, error: `Step ${index + 1}: timeout must be 1-3600 seconds.` };
      }
      if (item[key] !== undefined && item[key] !== "") (step as Record<string, unknown>)[key] = value;
    }
    if (item.ignoreErrors === true) step.ignoreErrors = true;
    steps.push(step);
  }
  return { ok: true, value: { name, description, variables, steps } };
}

let ensureTablePromise: Promise<void> | null = null;

export function ensureScriptsTable(): Promise<void> {
  if (!ensureTablePromise) {
    ensureTablePromise = db
      .execute(sql`
        CREATE TABLE IF NOT EXISTS install_scripts (
          id serial PRIMARY KEY,
          name text NOT NULL,
          description text NOT NULL DEFAULT '',
          variables text NOT NULL DEFAULT '[]',
          steps text NOT NULL DEFAULT '[]',
          run_count integer NOT NULL DEFAULT 0,
          created_at timestamptz NOT NULL DEFAULT now(),
          updated_at timestamptz NOT NULL DEFAULT now()
        )
      `)
      .then(() => undefined)
      .catch((error) => {
        ensureTablePromise = null;
        throw error;
      });
  }
  return ensureTablePromise;
}

function safeJson<T>(value: string, fallback: T): T {
  try {
    return JSON.parse(value) as T;
  } catch {
    return fallback;
  }
}

export function formatScript(script: InstallScript) {
  return {
    id: script.id,
    name: script.name,
    description: script.description,
    variables: safeJson<ScriptVariable[]>(script.variables, []),
    steps: safeJson<ScriptStep[]>(script.steps, []),
    runCount: script.runCount,
    createdAt: script.createdAt.toISOString(),
    updatedAt: script.updatedAt.toISOString(),
  };
}

/* ------------------------------------------------------------------ */
/* Variable substitution                                               */
/* ------------------------------------------------------------------ */

// "a b  c d" with 3 names -> ["a", "b", "c d"]: values are separated by a space, comma or ;
// and the last name takes whatever is left, so it may contain spaces.
export function splitGroupValue(value: string, count: number): string[] | null {
  const parts: string[] = [];
  let rest = value.trim();
  for (let index = 0; index < count - 1; index += 1) {
    const match = rest.match(/^([^\s,;]+)[\s,;]+([\s\S]*)$/);
    if (!match) return null;
    parts.push(match[1]);
    rest = match[2].trim();
  }
  if (!rest) return null;
  parts.push(rest);
  return parts;
}

export function substituteStep(step: ScriptStep, values: Map<string, string>): { step: ScriptStep; unknown: string[] } {
  const unknown = new Set<string>();
  const replace = (text: string) =>
    text.replace(PLACEHOLDER_PATTERN, (match, inner: string) => {
      const key = normalizeVariableKey(inner);
      const value = values.get(key);
      if (value !== undefined) return value;
      // Only plain names are reported as typos; other {{ }} text is left untouched.
      if (SIMPLE_NAME_PATTERN.test(key)) unknown.add(key);
      return match;
    });
  const result: Record<string, unknown> = { ...step };
  for (const [key, value] of Object.entries(step)) {
    if (typeof value === "string") result[key] = replace(value);
  }
  return { step: result as ScriptStep, unknown: [...unknown] };
}

function describeStep(step: ScriptStep): string {
  switch (step.type) {
    case "download": return `Download ${step.url}${step.fileName ? ` as ${step.fileName}` : ""}`;
    case "unzip": return `Unzip ${step.path}`;
    case "chmod": return `chmod ${step.mode} ${step.path}`;
    case "mkdir": return `Create folder ${step.path}`;
    case "writeFile": return `Write file ${step.path}`;
    case "delete": return `Delete ${step.path}`;
    case "move": return `Move ${step.from} → ${step.to}`;
    case "moveContents": return `Move contents of ${step.from} → ${step.to || "the server folder"}`;
    case "command": return `Run: ${step.command}`;
    case "setStartCommand": return `Set start command: ${step.command}`;
  }
}

/* ------------------------------------------------------------------ */
/* Job runner                                                          */
/* ------------------------------------------------------------------ */

export type StepStatus = "pending" | "running" | "success" | "failed" | "skipped";
export type JobStatus = "running" | "success" | "failed" | "cancelled";

type Job = {
  id: string;
  scriptId: number;
  scriptName: string;
  serverId: number;
  serverName: string;
  status: JobStatus;
  startedAt: string;
  finishedAt: string | null;
  steps: { index: number; type: StepType; label: string; status: StepStatus; message: string | null }[];
  log: string[];
  logDropped: number;
  cancelRequested: boolean;
  child: ChildProcess | null;
};

const jobs = new Map<string, Job>();
const MAX_LOG_LINES = 5000;
const MAX_JOBS = 30;

function appendLog(job: Job, line: string): void {
  job.log.push(line);
  if (job.log.length > MAX_LOG_LINES) {
    const overflow = job.log.length - MAX_LOG_LINES;
    job.log.splice(0, overflow);
    job.logDropped += overflow;
  }
}

export function getActiveJobForServer(serverId: number): Job | undefined {
  return [...jobs.values()].find((job) => job.serverId === serverId && job.status === "running");
}

export function getJobView(jobId: string, since: number) {
  const job = jobs.get(jobId);
  if (!job) return null;
  const start = Math.max(0, since - job.logDropped);
  return {
    id: job.id,
    scriptId: job.scriptId,
    scriptName: job.scriptName,
    serverId: job.serverId,
    serverName: job.serverName,
    status: job.status,
    startedAt: job.startedAt,
    finishedAt: job.finishedAt,
    steps: job.steps,
    log: job.log.slice(start),
    logTotal: job.logDropped + job.log.length,
  };
}

export function cancelJob(jobId: string): boolean {
  const job = jobs.get(jobId);
  if (!job || job.status !== "running") return false;
  job.cancelRequested = true;
  appendLog(job, "Cancelling…");
  if (job.child?.pid) {
    try {
      process.kill(-job.child.pid, "SIGKILL");
    } catch {
      job.child.kill("SIGKILL");
    }
  }
  return true;
}

function runShellCommand(job: Job, server: ManagedServer, command: string, timeoutSeconds: number): Promise<void> {
  return new Promise((resolve, reject) => {
    const child = spawn(command, {
      cwd: server.directory,
      env: buildChildEnv(server.directory, server.port),
      shell: true,
      detached: true,
      stdio: ["ignore", "pipe", "pipe"],
    });
    job.child = child;
    let timedOut = false;
    const timer = setTimeout(() => {
      timedOut = true;
      try {
        if (child.pid) process.kill(-child.pid, "SIGKILL");
      } catch {
        child.kill("SIGKILL");
      }
    }, timeoutSeconds * 1000);

    const pipe = (stream: NodeJS.ReadableStream | null) => {
      let carry = "";
      stream?.on("data", (chunk: Buffer) => {
        carry += chunk.toString("utf8");
        const parts = carry.split(/\r?\n/);
        carry = parts.pop() ?? "";
        for (const line of parts) appendLog(job, `  ${line}`);
      });
      stream?.on("end", () => { if (carry) appendLog(job, `  ${carry}`); });
    };
    pipe(child.stdout);
    pipe(child.stderr);

    child.on("error", (error) => { clearTimeout(timer); job.child = null; reject(error); });
    child.on("close", (code, signal) => {
      clearTimeout(timer);
      job.child = null;
      if (job.cancelRequested) reject(new Error("Cancelled"));
      else if (timedOut) reject(new Error(`The command timed out after ${timeoutSeconds} seconds.`));
      else if (code !== 0) reject(new Error(`The command exited with ${signal ? `signal ${signal}` : `code ${code}`}.`));
      else resolve();
    });
  });
}

async function executeStep(job: Job, server: ManagedServer, step: ScriptStep): Promise<string> {
  switch (step.type) {
    case "download": {
      const entry = await downloadServerFileFromUrl(server, step.url ?? "", step.directory || undefined, step.fileName || undefined);
      return `Saved ${entry.path} (${(Number(entry.size) / 1024).toFixed(1)} KB)`;
    }
    case "unzip": {
      const result = await extractServerZipArchive(server, step.path ?? "");
      if (step.deleteArchive) await deleteServerEntry(server, step.path ?? "");
      return `Extracted ${result.extractedFiles} file(s) into ${result.directory || "the server folder"}${step.deleteArchive ? " and removed the archive" : ""}`;
    }
    case "chmod": {
      const entry = await setServerFilePermissions(server, step.path ?? "", step.mode ?? "");
      return `Permissions of ${entry.path} set to ${step.mode}`;
    }
    case "mkdir": {
      try {
        const entry = await createServerFolder(server, step.path ?? "");
        return `Created ${entry.path}`;
      } catch (error) {
        const known = mapServerFilesError(error);
        if (known?.status === 409) return `${step.path} already exists`;
        throw error;
      }
    }
    case "writeFile": {
      try {
        const file = await createServerTextFile(server, step.path ?? "", step.content ?? "");
        return `Created ${file.path}`;
      } catch (error) {
        const known = mapServerFilesError(error);
        if (known?.status !== 409) throw error;
        const file = await saveServerTextFile(server, step.path ?? "", step.content ?? "");
        return `Overwrote ${file.path}`;
      }
    }
    case "delete": {
      try {
        await deleteServerEntry(server, step.path ?? "");
        return `Deleted ${step.path}`;
      } catch (error) {
        const known = mapServerFilesError(error);
        if (known?.status === 404) return `${step.path} was not found (skipped)`;
        throw error;
      }
    }
    case "move": {
      const result = await moveServerEntry(server, step.from ?? "", step.to ?? "");
      return `Moved ${result.sourcePath} → ${result.destinationPath}`;
    }
    case "moveContents": {
      const clean = (value: string) => value.replace(/\\/g, "/").split("/").filter((part) => part && part !== ".").join("/");
      const source = clean(step.from ?? "");
      const target = clean(step.to ?? "");
      if (!source) throw new ServerFilesError(400, "Choose the folder whose contents should be moved.");
      if (target === source || target.startsWith(`${source}/`)) {
        throw new ServerFilesError(400, "The destination cannot be the source folder or a folder inside it.");
      }
      const listing = await listServerDirectory(server, source);
      let moved = 0;
      let replaced = 0;
      let skipped = 0;
      for (const entry of listing.entries) {
        if (entry.kind === "link") { skipped += 1; continue; }
        const destination = target ? `${target}/${entry.name}` : entry.name;
        if (destination === source) {
          throw new ServerFilesError(409, `"${entry.name}" inside the folder has the same name as the folder itself. Rename it first.`);
        }
        try {
          await moveServerEntry(server, entry.path, destination);
          moved += 1;
        } catch (error) {
          const known = mapServerFilesError(error);
          if (known?.status !== 409) throw error;
          if (!step.overwrite) { skipped += 1; continue; }
          await deleteServerEntry(server, destination);
          await moveServerEntry(server, entry.path, destination);
          moved += 1;
          replaced += 1;
        }
      }
      let removed = false;
      if (step.removeEmptyFolder && skipped === 0) {
        await deleteServerEntry(server, source);
        removed = true;
      }
      return `Moved ${moved} item(s) into ${target || "the server folder"}${replaced ? ` (replaced ${replaced})` : ""}${skipped ? `, skipped ${skipped}` : ""}${removed ? ", removed the empty folder" : ""}`;
    }
    case "command": {
      await runShellCommand(job, server, step.command ?? "", step.timeoutSeconds ?? 600);
      return "Command finished";
    }
    case "setStartCommand": {
      await db.update(serversTable).set({ command: step.command ?? "", updatedAt: new Date() }).where(eq(serversTable.id, server.id));
      return "Start command updated (applies the next time the server starts)";
    }
  }
}

export function startScriptJob(script: InstallScript, server: ManagedServer, steps: ScriptStep[]): string {
  const job: Job = {
    id: randomUUID(),
    scriptId: script.id,
    scriptName: script.name,
    serverId: server.id,
    serverName: server.name,
    status: "running",
    startedAt: new Date().toISOString(),
    finishedAt: null,
    steps: steps.map((step, index) => ({ index, type: step.type, label: describeStep(step), status: "pending", message: null })),
    log: [],
    logDropped: 0,
    cancelRequested: false,
    child: null,
  };
  jobs.set(job.id, job);
  if (jobs.size > MAX_JOBS) {
    for (const [id, old] of jobs) {
      if (old.status !== "running") { jobs.delete(id); if (jobs.size <= MAX_JOBS) break; }
    }
  }
  void runJob(job, script, server, steps);
  return job.id;
}

async function runJob(job: Job, script: InstallScript, server: ManagedServer, steps: ScriptStep[]): Promise<void> {
  appendLog(job, `Running "${script.name}" on ${server.name}`);
  let failed = false;
  for (const [index, step] of steps.entries()) {
    const view = job.steps[index];
    if (job.cancelRequested || failed) {
      view.status = "skipped";
      continue;
    }
    view.status = "running";
    appendLog(job, `▶ Step ${index + 1}/${steps.length}: ${view.label}`);
    try {
      const [fresh] = await db.select().from(serversTable).where(eq(serversTable.id, server.id)).limit(1);
      if (!fresh) throw new Error("The server no longer exists.");
      view.message = await executeStep(job, fresh, step);
      view.status = "success";
      appendLog(job, `✔ ${view.message}`);
    } catch (error) {
      const known = error instanceof ServerFilesError ? error : mapServerFilesError(error);
      view.message = known?.message ?? (error instanceof Error ? error.message : "The step failed.");
      view.status = "failed";
      appendLog(job, `✖ ${view.message}`);
      if (!step.ignoreErrors && !job.cancelRequested) failed = true;
      else if (job.cancelRequested) failed = true;
    }
  }
  job.status = job.cancelRequested ? "cancelled" : failed ? "failed" : "success";
  job.finishedAt = new Date().toISOString();
  appendLog(job, job.status === "success" ? "Finished successfully." : job.status === "cancelled" ? "Cancelled." : "Stopped because a step failed.");
  try {
    await db.update(installScriptsTable).set({ runCount: sql`${installScriptsTable.runCount} + 1` }).where(eq(installScriptsTable.id, script.id));
    await db.insert(activityTable).values({
      message: `Script "${script.name}" ${job.status === "success" ? "finished" : job.status} on ${server.name}`,
      kind: job.status === "success" ? "success" : job.status === "cancelled" ? "info" : "error",
    });
  } catch (error) {
    logger.warn({ err: error }, "Could not record script run");
  }
}
