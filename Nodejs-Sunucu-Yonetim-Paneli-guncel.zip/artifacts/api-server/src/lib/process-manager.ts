import { readFileSync } from "node:fs";
import path from "node:path";
import { spawn, type ChildProcess } from "node:child_process";
import { logger } from "./logger";

type ManagedProcess = {
  child: ChildProcess;
  lines: string[];
  startedAt: number;
  stopRequested: boolean;
};

const processes = new Map<number, ManagedProcess>();

function pushLine(id: number, line: string): void {
  const processState = processes.get(id);
  if (!processState || !line.trim()) return;
  processState.lines.push(line.trimEnd());
  if (processState.lines.length > 500) processState.lines.splice(0, processState.lines.length - 500);
}

export function getManagedProcess(id: number): ManagedProcess | undefined {
  return processes.get(id);
}

export function getProcessLines(id: number): string[] {
  return [...(processes.get(id)?.lines ?? [])];
}

export function clearProcessLogLines(id: number): void {
  const processState = processes.get(id);
  if (processState) processState.lines.length = 0;
}

export type ProcessInputOptions = {
  lineEnding?: string;
  encoding?: BufferEncoding;
};

export function sendManagedProcessInput(id: number, input: string, options: ProcessInputOptions = {}): void {
  const processState = processes.get(id);
  if (!processState || processState.child.exitCode !== null) {
    throw new Error("The managed server is not running.");
  }
  if (/[\r\n]/.test(input)) {
    throw new Error("Send one console command at a time.");
  }
  const command = input.trim();
  if (!command) {
    throw new Error("Enter a console command.");
  }
  const stdin = processState.child.stdin;
  if (!stdin || stdin.destroyed || !stdin.writable) {
    throw new Error("The server process does not accept console input.");
  }
  stdin.write(Buffer.from(`${command}${options.lineEnding ?? "\n"}`, options.encoding ?? "utf8"));
  pushLine(id, `> ${command}`);
}

export function isMinecraftConsoleClientCommand(command: string): boolean {
  const tokens = command.trim().match(/"[^"]*"|'[^']*'|\S+/g);
  if (!tokens) return false;
  let index = 0;
  while (index < tokens.length && /^(?:mono|dotnet|exec)$/i.test(tokens[index])) index += 1;
  const executable = tokens[index]?.replace(/^["']|["']$/g, "");
  if (!executable) return false;
  const baseName = executable.split(/[\\/]/).pop() ?? "";
  // mc.exe, MinecraftClient, MinecraftClient-<build>-linux-arm, MinecraftClient.dll, mcc ...
  return /^(?:mc\.exe|minecraftclient(?:[-_.].*)?|mcc(?:[-_.].*)?)$/i.test(baseName);
}

function withMccBasicIo(command: string): string {
  const normalizedCommand = command.trim();
  if (/[;&|\r\n]/.test(command) || !isMinecraftConsoleClientCommand(normalizedCommand)) {
    return command;
  }
  if (/\bBasicIO(?:-NoColor)?(?:\s|$)/i.test(normalizedCommand)) {
    return command;
  }
  return `${normalizedCommand} BasicIO`;
}

// Managed apps must not inherit the panel's own settings: the panel's PORT would
// collide with the API, and DATABASE_URL is a secret that belongs to the panel only.
const PANEL_ONLY_ENV_KEYS = ["PORT", "DATABASE_URL", "BASE_PATH", "LOG_LEVEL", "NODE_ENV", "API_PROXY_TARGET"];

function parseDotEnv(content: string): Record<string, string> {
  const result: Record<string, string> = {};
  for (const rawLine of content.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith("#")) continue;
    const match = line.match(/^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
    if (!match) continue;
    let value = match[2].trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    } else {
      value = value.replace(/\s+#.*$/, "");
    }
    result[match[1]] = value;
  }
  return result;
}

// Each managed server gets its own environment: the panel's settings are removed,
// variables from the server folder's own `.env` are applied, and the configured
// Port (if any) is exported as PORT.
export function buildChildEnv(directory: string, port?: number | null): NodeJS.ProcessEnv {
  const env: NodeJS.ProcessEnv = { ...process.env };
  for (const key of PANEL_ONLY_ENV_KEYS) delete env[key];
  try {
    Object.assign(env, parseDotEnv(readFileSync(path.join(directory, ".env"), "utf8")));
  } catch {
    // No .env file in the server folder.
  }
  if (port) env.PORT = String(port);
  return env;
}

function attachOutput(id: number, stream: NodeJS.ReadableStream | null, prefix: string, encoding: string): void {
  if (!stream) return;
  let decoder: TextDecoder;
  try {
    decoder = new TextDecoder(encoding);
  } catch {
    decoder = new TextDecoder("utf-8");
  }
  let carry = "";
  let flushTimer: NodeJS.Timeout | null = null;
  const flush = () => {
    if (flushTimer) clearTimeout(flushTimer);
    flushTimer = null;
    if (carry) pushLine(id, `${prefix}${carry}`);
    carry = "";
  };
  stream.on("data", (chunk: Buffer) => {
    if (flushTimer) clearTimeout(flushTimer);
    carry += decoder.decode(chunk, { stream: true });
    const parts = carry.split(/\r?\n/);
    carry = parts.pop() ?? "";
    for (const line of parts) pushLine(id, `${prefix}${line}`);
    // Prompts without a trailing newline are shown after a short pause.
    if (carry) flushTimer = setTimeout(flush, 150);
  });
  stream.on("end", () => {
    carry += decoder.decode();
    flush();
  });
}

export function startManagedProcess(
  id: number,
  command: string,
  directory: string,
  onExit: (code: number | null, signal: NodeJS.Signals | null, unexpected: boolean) => void,
  port?: number | null,
  outputEncoding = "utf-8",
): ChildProcess {
  const existing = processes.get(id);
  if (existing && existing.child.exitCode === null) {
    throw new Error("Server is already running");
  }

  const processCommand = withMccBasicIo(command);
  const child = spawn(processCommand, {
    cwd: directory,
    env: buildChildEnv(directory, port),
    shell: true,
    detached: true,
    stdio: ["pipe", "pipe", "pipe"],
  });
  const state: ManagedProcess = { child, lines: [], startedAt: Date.now(), stopRequested: false };
  processes.set(id, state);
  pushLine(id, `$ ${processCommand}`);
  attachOutput(id, child.stdout, "", outputEncoding);
  attachOutput(id, child.stderr, "[stderr] ", outputEncoding);
  let exitHandled = false;
  const notifyExit = (code: number | null, signal: NodeJS.Signals | null) => {
    if (exitHandled) return;
    exitHandled = true;
    onExit(code, signal, !state.stopRequested);
  };
  child.once("error", (error) => {
    pushLine(id, `[process error] ${error.message}`);
    logger.error({ err: error, serverId: id }, "Managed server process error");
    notifyExit(null, null);
  });
  child.once("exit", (code, signal) => {
    notifyExit(code, signal);
  });
  return child;
}

export type StopOptions = {
  stopCommand?: string;
  lineEnding?: string;
  inputEncoding?: BufferEncoding;
};

const STOP_SIGNALS: Record<string, NodeJS.Signals> = {
  "^C": "SIGINT",
  SIGINT: "SIGINT",
  SIGTERM: "SIGTERM",
  SIGHUP: "SIGHUP",
  SIGQUIT: "SIGQUIT",
};

export async function stopManagedProcess(id: number, options: StopOptions = {}): Promise<void> {
  const processState = processes.get(id);
  if (!processState) {
    processes.delete(id);
    return;
  }
  processState.stopRequested = true;
  const child = processState.child;
  const pid = child.pid;
  const waitForExit = async (timeoutMs: number) => {
    if (pid) await waitForProcessGroupExit(pid, timeoutMs);
    else await waitForProcessExit(child, timeoutMs);
  };
  const stillRunning = () => (pid ? isProcessGroupRunning(pid) : child.exitCode === null);

  const requested = (options.stopCommand ?? "^C").trim() || "^C";
  const signal = STOP_SIGNALS[requested.toUpperCase()];
  if (signal) {
    signalProcessGroup(id, child, signal);
    await waitForExit(5000);
  } else {
    const stdin = child.stdin;
    if (stdin && !stdin.destroyed && stdin.writable) {
      stdin.write(Buffer.from(`${requested}${options.lineEnding ?? "\n"}`, options.inputEncoding ?? "utf8"));
      pushLine(id, `> ${requested}`);
      await waitForExit(20000);
    }
  }
  if (stillRunning()) {
    signalProcessGroup(id, child, "SIGTERM");
    await waitForExit(4000);
  }
  if (stillRunning()) {
    signalProcessGroup(id, child, "SIGKILL");
    await waitForExit(1000);
  }
  processes.delete(id);
}

export async function killManagedProcess(id: number): Promise<void> {
  const processState = processes.get(id);
  if (!processState) {
    processes.delete(id);
    return;
  }
  processState.stopRequested = true;
  const pid = processState.child.pid;
  signalProcessGroup(id, processState.child, "SIGKILL");
  if (pid) await waitForProcessGroupExit(pid, 1000);
  else await waitForProcessExit(processState.child, 1000);
  processes.delete(id);
}

function signalProcessGroup(id: number, child: ChildProcess, signal: NodeJS.Signals): void {
  const pid = child.pid;
  if (!pid) return;
  try {
    // The detached shell is the process-group leader, so this also stops
    // the actual server process and any children it created.
    process.kill(-pid, signal);
  } catch (error) {
    const code = (error as NodeJS.ErrnoException).code;
    if (code !== "ESRCH") {
      try {
        child.kill(signal);
      } catch {
        logger.warn({ serverId: id, pid, signal }, "Could not signal managed process");
      }
    }
  }
}

async function waitForProcessExit(child: ChildProcess, timeoutMs: number): Promise<void> {
  if (child.exitCode !== null) return;
  await new Promise<void>((resolve) => {
    const finish = () => {
      clearTimeout(timeout);
      child.removeListener("exit", finish);
      resolve();
    };
    const timeout = setTimeout(finish, timeoutMs);
    child.once("exit", finish);
  });
}

function isProcessGroupRunning(pid: number): boolean {
  try {
    process.kill(-pid, 0);
    return true;
  } catch (error) {
    return (error as NodeJS.ErrnoException).code !== "ESRCH";
  }
}

async function waitForProcessGroupExit(pid: number, timeoutMs: number): Promise<void> {
  const deadline = Date.now() + timeoutMs;
  while (isProcessGroupRunning(pid) && Date.now() < deadline) {
    await new Promise<void>((resolve) => setTimeout(resolve, 50));
  }
}

export function clearManagedProcess(id: number): void {
  processes.delete(id);
}