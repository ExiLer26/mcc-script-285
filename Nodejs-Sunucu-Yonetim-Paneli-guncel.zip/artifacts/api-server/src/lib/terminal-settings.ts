import { eq, sql } from "drizzle-orm";
import { db, terminalSettingsTable } from "@workspace/db";
import { logger } from "./logger";

export const LINE_ENDINGS = { lf: "\n", crlf: "\r\n", cr: "\r" } as const;
export type LineEnding = keyof typeof LINE_ENDINGS;

export const INPUT_ENCODINGS = ["utf8", "latin1", "ascii", "utf16le"] as const;
export type InputEncoding = (typeof INPUT_ENCODINGS)[number];

// WHATWG labels understood by TextDecoder.
export const OUTPUT_ENCODINGS = [
  "utf-8",
  "utf-16le",
  "windows-1252",
  "windows-1254",
  "iso-8859-15",
  "windows-1251",
  "koi8-r",
  "gbk",
  "gb18030",
  "big5",
  "shift_jis",
  "euc-jp",
  "euc-kr",
] as const;

export type TerminalSettings = {
  emulated: boolean;
  colors: boolean;
  lineEnding: LineEnding;
  stopCommand: string;
  inputEncoding: InputEncoding;
  outputEncoding: string;
};

export const DEFAULT_TERMINAL_SETTINGS: TerminalSettings = {
  emulated: true,
  colors: true,
  lineEnding: "lf",
  stopCommand: "^C",
  inputEncoding: "utf8",
  outputEncoding: "utf-8",
};

export function parseTerminalSettingsInput(
  body: unknown,
): { ok: true; value: TerminalSettings } | { ok: false; error: string } {
  if (!body || typeof body !== "object") return { ok: false, error: "Invalid terminal settings." };
  const input = body as Record<string, unknown>;
  if (typeof input.emulated !== "boolean") return { ok: false, error: "emulated must be true or false." };
  if (typeof input.colors !== "boolean") return { ok: false, error: "colors must be true or false." };
  if (typeof input.lineEnding !== "string" || !(input.lineEnding in LINE_ENDINGS)) {
    return { ok: false, error: "Unsupported command line ending." };
  }
  const stopCommand = typeof input.stopCommand === "string" ? input.stopCommand.trim() : "";
  if (!stopCommand || stopCommand.length > 120 || /[\r\n]/.test(stopCommand)) {
    return { ok: false, error: "The stop command must be one line, 1-120 characters." };
  }
  if (typeof input.inputEncoding !== "string" || !(INPUT_ENCODINGS as readonly string[]).includes(input.inputEncoding)) {
    return { ok: false, error: "Unsupported input encoding." };
  }
  if (typeof input.outputEncoding !== "string" || !(OUTPUT_ENCODINGS as readonly string[]).includes(input.outputEncoding)) {
    return { ok: false, error: "Unsupported output encoding." };
  }
  return {
    ok: true,
    value: {
      emulated: input.emulated,
      colors: input.colors,
      lineEnding: input.lineEnding as LineEnding,
      stopCommand,
      inputEncoding: input.inputEncoding as InputEncoding,
      outputEncoding: input.outputEncoding,
    },
  };
}

// Creates the settings table on demand so no manual database push is needed.
let ensureTablePromise: Promise<void> | null = null;

export function ensureTerminalSettingsTable(): Promise<void> {
  if (!ensureTablePromise) {
    ensureTablePromise = db
      .execute(sql`
        CREATE TABLE IF NOT EXISTS server_terminal_settings (
          server_id integer PRIMARY KEY REFERENCES managed_servers(id) ON DELETE CASCADE,
          emulated boolean NOT NULL DEFAULT true,
          colors boolean NOT NULL DEFAULT true,
          line_ending text NOT NULL DEFAULT 'lf',
          stop_command text NOT NULL DEFAULT '^C',
          input_encoding text NOT NULL DEFAULT 'utf8',
          output_encoding text NOT NULL DEFAULT 'utf-8',
          updated_at timestamptz NOT NULL DEFAULT now()
        )
      `)
      .then(() => undefined)
      .catch((error) => {
        ensureTablePromise = null;
        throw error;
      });
  }
  return ensureTablePromise;
}

// Falls back to defaults when the settings table has not been created yet
// (run the database push once after updating).
export async function getTerminalSettings(serverId: number): Promise<TerminalSettings> {
  try {
    await ensureTerminalSettingsTable();
    const [row] = await db
      .select()
      .from(terminalSettingsTable)
      .where(eq(terminalSettingsTable.serverId, serverId))
      .limit(1);
    if (!row) return { ...DEFAULT_TERMINAL_SETTINGS };
    return {
      emulated: row.emulated,
      colors: row.colors,
      lineEnding: row.lineEnding in LINE_ENDINGS ? (row.lineEnding as LineEnding) : "lf",
      stopCommand: row.stopCommand || "^C",
      inputEncoding: (INPUT_ENCODINGS as readonly string[]).includes(row.inputEncoding) ? (row.inputEncoding as InputEncoding) : "utf8",
      outputEncoding: (OUTPUT_ENCODINGS as readonly string[]).includes(row.outputEncoding) ? row.outputEncoding : "utf-8",
    };
  } catch (error) {
    logger.warn({ err: error, serverId }, "Could not load terminal settings; using defaults");
    return { ...DEFAULT_TERMINAL_SETTINGS };
  }
}

export async function saveTerminalSettings(serverId: number, settings: TerminalSettings): Promise<void> {
  await ensureTerminalSettingsTable();
  await db
    .insert(terminalSettingsTable)
    .values({ serverId, ...settings })
    .onConflictDoUpdate({
      target: terminalSettingsTable.serverId,
      set: { ...settings, updatedAt: new Date() },
    });
}

export async function getStopOptions(serverId: number) {
  const settings = await getTerminalSettings(serverId);
  return {
    stopCommand: settings.stopCommand,
    lineEnding: LINE_ENDINGS[settings.lineEnding],
    inputEncoding: settings.inputEncoding,
  };
}
