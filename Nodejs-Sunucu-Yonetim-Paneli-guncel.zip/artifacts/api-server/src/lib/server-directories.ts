import { randomUUID } from "node:crypto";
import { lstat, mkdir, realpath, rename, rm, stat } from "node:fs/promises";
import path from "node:path";

export class ServerDirectoryConflictError extends Error {
  constructor() {
    super("A server folder with this name already exists. Choose a different server name.");
    this.name = "ServerDirectoryConflictError";
  }
}

export type StagedServerDirectory = {
  originalPath: string;
  stagedPath: string;
};

function getServersRootPath(): string {
  return path.resolve(process.cwd(), "servers");
}

function safeServerFolderName(name: string): string {
  const slug = name
    .trim()
    .normalize("NFKD")
    .replace(/\p{Diacritic}/gu, "")
    .toLowerCase()
    .replace(/[^a-z0-9._-]+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^[.-]+|[.-]+$/g, "");
  return slug || `server-${randomUUID().slice(0, 8)}`;
}

async function ensureServersRoot(): Promise<string> {
  const rootPath = getServersRootPath();
  await mkdir(rootPath, { recursive: true });
  const rootStats = await lstat(rootPath);
  if (!rootStats.isDirectory() || rootStats.isSymbolicLink()) {
    throw new Error("The managed servers path must be a real directory.");
  }
  return realpath(rootPath);
}

export async function createManagedServerDirectory(name: string): Promise<string> {
  const root = await ensureServersRoot();
  const serverPath = path.join(root, safeServerFolderName(name));
  try {
    await mkdir(serverPath, { mode: 0o755 });
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "EEXIST") {
      throw new ServerDirectoryConflictError();
    }
    throw error;
  }
  return serverPath;
}

export async function stageManagedServerDirectoryDeletion(
  configuredPath: string,
): Promise<StagedServerDirectory | null> {
  const rootPath = getServersRootPath();
  const candidate = path.resolve(configuredPath);
  if (path.dirname(candidate) !== rootPath) return null;

  let root: string;
  try {
    root = await realpath(rootPath);
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return null;
    throw error;
  }

  let stats;
  try {
    stats = await lstat(candidate);
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return null;
    throw error;
  }
  if (!stats.isDirectory() || stats.isSymbolicLink()) {
    throw new Error("The managed server path is not a regular directory.");
  }

  const canonical = await realpath(candidate);
  if (path.dirname(canonical) !== root) {
    throw new Error("The managed server folder is outside its storage root.");
  }

  const stagedPath = path.join(root, `.deleting-${randomUUID()}`);
  await rename(canonical, stagedPath);
  return { originalPath: canonical, stagedPath };
}

export async function restoreManagedServerDirectory(
  staged: StagedServerDirectory,
): Promise<void> {
  await rename(staged.stagedPath, staged.originalPath);
}

export async function removeStagedManagedServerDirectory(
  staged: StagedServerDirectory,
): Promise<void> {
  await rm(staged.stagedPath, { recursive: true, force: true });
}

/* ------------------------------------------------------------------ */
/* Folders chosen manually                                             */
/* ------------------------------------------------------------------ */

export class ServerDirectoryInvalidError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ServerDirectoryInvalidError";
  }
}

// System folders that can never be used as a server folder.
const PROTECTED_FOLDERS = ["/", "/bin", "/boot", "/dev", "/etc", "/home", "/lib", "/lib64", "/opt", "/proc", "/root", "/run", "/sbin", "/srv", "/sys", "/tmp", "/usr", "/var"];

function isInside(parent: string, child: string): boolean {
  const relative = path.relative(parent, child);
  return relative === "" || (!relative.startsWith("..") && !path.isAbsolute(relative));
}

function checkManualDirectory(candidate: string): void {
  if (PROTECTED_FOLDERS.includes(candidate)) {
    throw new ServerDirectoryInvalidError(`"${candidate}" is a system folder. Choose a folder inside it, for example ${candidate === "/" ? "" : candidate}/my-server`.replace("  ", " "));
  }
  const servers = getServersRootPath();
  if (candidate === servers || path.dirname(candidate) === servers) {
    throw new ServerDirectoryInvalidError("Folders directly inside the panel's servers folder are created automatically. Choose Automatic, or pick another location.");
  }
  // The panel's own files (.env with the database password, its code) must never become a server folder.
  if (isInside(candidate, process.cwd())) {
    throw new ServerDirectoryInvalidError("This folder contains the panel itself. Choose a different folder.");
  }
}

export function isManagedServerDirectory(configuredPath: string): boolean {
  return path.dirname(path.resolve(configuredPath)) === getServersRootPath();
}

// Validates a folder typed by the administrator and creates it when it does not exist yet.
export async function prepareManualServerDirectory(input: string): Promise<{ directory: string; created: boolean }> {
  const trimmed = input.trim();
  if (!trimmed) throw new ServerDirectoryInvalidError("Enter the folder path.");
  if (trimmed.length > 1000 || trimmed.includes("\0")) throw new ServerDirectoryInvalidError("This folder path is not valid.");
  if (!path.isAbsolute(trimmed)) {
    throw new ServerDirectoryInvalidError("Use a full path that starts with / (for example /home/me/my-server).");
  }
  const resolved = path.resolve(trimmed);
  checkManualDirectory(resolved);

  let created = false;
  try {
    const stats = await stat(resolved);
    if (!stats.isDirectory()) throw new ServerDirectoryInvalidError("This path exists but is not a folder.");
  } catch (error) {
    if (error instanceof ServerDirectoryInvalidError) throw error;
    if ((error as NodeJS.ErrnoException).code !== "ENOENT") {
      throw new ServerDirectoryInvalidError(`This folder cannot be used: ${(error as Error).message}`);
    }
    try {
      await mkdir(resolved, { recursive: true, mode: 0o755 });
      created = true;
    } catch (mkdirError) {
      throw new ServerDirectoryInvalidError(`The folder could not be created: ${(mkdirError as Error).message}`);
    }
  }

  // Resolve links so a symlink cannot point the server at a protected place.
  const real = await realpath(resolved);
  try {
    checkManualDirectory(real);
  } catch (error) {
    if (created) await rm(resolved, { recursive: true, force: true }).catch(() => undefined);
    throw error;
  }
  return { directory: real, created };
}
