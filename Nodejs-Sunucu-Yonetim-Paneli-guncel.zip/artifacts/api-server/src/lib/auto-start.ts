import { asc, eq } from "drizzle-orm";
import { db, serversTable, type ManagedServer } from "@workspace/db";
import { logger } from "./logger";
import { startManagedServerProcess } from "./server-lifecycle";

const autoStartTimers = new Map<number, NodeJS.Timeout>();

export function cancelScheduledAutoStart(id: number): void {
  const timer = autoStartTimers.get(id);
  if (timer) clearTimeout(timer);
  autoStartTimers.delete(id);
}

function scheduleServerAutoStart(server: ManagedServer): void {
  cancelScheduledAutoStart(server.id);
  const timer = setTimeout(() => {
    autoStartTimers.delete(server.id);
    void (async () => {
      const [current] = await db.select()
        .from(serversTable)
        .where(eq(serversTable.id, server.id))
        .limit(1);
      if (!current?.autoStart) return;
      try {
        await startManagedServerProcess(current);
      } catch (error) {
        logger.error({ err: error, serverId: server.id }, "Could not auto-start managed process");
      }
    })().catch((error) => {
      logger.error({ err: error, serverId: server.id }, "Could not load auto-start process configuration");
    });
  }, server.autoStartDelaySeconds * 1000);
  timer.unref();
  autoStartTimers.set(server.id, timer);
}

async function scheduleConfiguredProcesses(): Promise<void> {
  try {
    const servers = await db.select()
      .from(serversTable)
      .where(eq(serversTable.autoStart, true))
      .orderBy(asc(serversTable.createdAt), asc(serversTable.id));

    for (const server of servers) {
      scheduleServerAutoStart(server);
    }
    logger.info({ count: servers.length }, "Scheduled managed-process auto-start");
  } catch (error) {
    logger.error({ err: error }, "Could not load auto-start process configuration");
  }
}

export function scheduleManagedProcessAutoStart(): void {
  const timer = setTimeout(() => {
    void scheduleConfiguredProcesses();
  }, 0);
  timer.unref();
}
