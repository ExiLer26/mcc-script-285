import crypto from "node:crypto";
import { and, eq, gt, sql } from "drizzle-orm";
import { db, adminsTable, panelUsersTable, sessionsTable, userSessionsTable, type Admin, type PanelUser } from "@workspace/db";
import { normalizePermissions, type UserAccess } from "./permissions";

export const SESSION_COOKIE = "server_control_session";
const SESSION_TTL_MS = 1000 * 60 * 60 * 24 * 14;

export function hashPassword(password: string, salt: string): string {
  return crypto.scryptSync(password, salt, 64).toString("hex");
}

export function createPasswordRecord(password: string): { hash: string; salt: string } {
  const salt = crypto.randomBytes(16).toString("hex");
  return { salt, hash: hashPassword(password, salt) };
}

export function verifyPassword(password: string, salt: string, expectedHash: string): boolean {
  const actual = Buffer.from(hashPassword(password, salt), "hex");
  const expected = Buffer.from(expectedHash, "hex");
  return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
}

export function publicAdmin(admin: Admin) {
  return {
    id: admin.id,
    username: admin.username,
    displayName: admin.displayName,
    createdAt: admin.createdAt.toISOString(),
  };
}

export async function createSession(adminId: number): Promise<string> {
  const token = crypto.randomBytes(32).toString("base64url");
  const tokenHash = crypto.createHash("sha256").update(token).digest("hex");
  await db.insert(sessionsTable).values({
    adminId,
    tokenHash,
    expiresAt: new Date(Date.now() + SESSION_TTL_MS),
  });
  return token;
}

export async function getSessionAdmin(token?: string): Promise<Admin | null> {
  if (!token) return null;
  const tokenHash = crypto.createHash("sha256").update(token).digest("hex");
  const [row] = await db
    .select({ admin: adminsTable })
    .from(sessionsTable)
    .innerJoin(adminsTable, eq(sessionsTable.adminId, adminsTable.id))
    .where(and(eq(sessionsTable.tokenHash, tokenHash), gt(sessionsTable.expiresAt, new Date())));
  return row?.admin ?? null;
}

export async function deleteSession(token?: string): Promise<void> {
  if (!token) return;
  const tokenHash = crypto.createHash("sha256").update(token).digest("hex");
  await db.delete(sessionsTable).where(eq(sessionsTable.tokenHash, tokenHash));
  try {
    await ensureUserTables();
    await db.delete(userSessionsTable).where(eq(userSessionsTable.tokenHash, tokenHash));
  } catch {
    // The user tables are unavailable; there is nothing to delete.
  }
}

/* ------------------------------------------------------------------ */
/* Limited users ("New User" in Settings)                              */
/* ------------------------------------------------------------------ */

let ensureUserTablesPromise: Promise<void> | null = null;

// Creates the user tables on demand so no manual database push is needed.
export function ensureUserTables(): Promise<void> {
  if (!ensureUserTablesPromise) {
    ensureUserTablesPromise = db
      .execute(sql`
        CREATE TABLE IF NOT EXISTS panel_users (
          id serial PRIMARY KEY,
          username text NOT NULL UNIQUE,
          display_name text NOT NULL,
          password_hash text NOT NULL,
          password_salt text NOT NULL,
          permissions text NOT NULL DEFAULT '[]',
          all_servers boolean NOT NULL DEFAULT false,
          server_ids text NOT NULL DEFAULT '[]',
          disabled boolean NOT NULL DEFAULT false,
          created_at timestamptz NOT NULL DEFAULT now()
        )
      `)
      .then(() => db.execute(sql`
        CREATE TABLE IF NOT EXISTS user_sessions (
          id serial PRIMARY KEY,
          user_id integer NOT NULL REFERENCES panel_users(id) ON DELETE CASCADE,
          token_hash text NOT NULL UNIQUE,
          expires_at timestamptz NOT NULL,
          created_at timestamptz NOT NULL DEFAULT now()
        )
      `))
      .then(() => undefined)
      .catch((error) => {
        ensureUserTablesPromise = null;
        throw error;
      });
  }
  return ensureUserTablesPromise;
}

function parseJsonArray(value: string): unknown[] {
  try {
    const parsed: unknown = JSON.parse(value);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function toUserAccess(user: PanelUser): UserAccess {
  return {
    permissions: normalizePermissions(parseJsonArray(user.permissions)),
    allServers: user.allServers,
    serverIds: parseJsonArray(user.serverIds).filter((id): id is number => typeof id === "number" && Number.isInteger(id)),
  };
}

export function publicUser(user: PanelUser) {
  return {
    id: user.id,
    username: user.username,
    displayName: user.displayName,
    createdAt: user.createdAt.toISOString(),
  };
}

export async function createUserSession(userId: number): Promise<string> {
  await ensureUserTables();
  const token = crypto.randomBytes(32).toString("base64url");
  const tokenHash = crypto.createHash("sha256").update(token).digest("hex");
  await db.insert(userSessionsTable).values({
    userId,
    tokenHash,
    expiresAt: new Date(Date.now() + SESSION_TTL_MS),
  });
  return token;
}

export type Principal =
  | { kind: "admin"; admin: Admin }
  | { kind: "user"; user: PanelUser; access: UserAccess };

export async function getSessionPrincipal(token?: string): Promise<Principal | null> {
  if (!token) return null;
  const admin = await getSessionAdmin(token);
  if (admin) return { kind: "admin", admin };
  try {
    await ensureUserTables();
    const tokenHash = crypto.createHash("sha256").update(token).digest("hex");
    const [row] = await db
      .select({ user: panelUsersTable })
      .from(userSessionsTable)
      .innerJoin(panelUsersTable, eq(userSessionsTable.userId, panelUsersTable.id))
      .where(and(eq(userSessionsTable.tokenHash, tokenHash), gt(userSessionsTable.expiresAt, new Date()), eq(panelUsersTable.disabled, false)));
    return row ? { kind: "user", user: row.user, access: toUserAccess(row.user) } : null;
  } catch {
    return null;
  }
}
