import { and, eq, isNotNull, lte, sql } from "drizzle-orm";
import { db, serversTable, serverSchedulesTable, type ServerSchedule } from "@workspace/db";
import { logger } from "./logger";
import { sendManagedProcessInput } from "./process-manager";
import { getTerminalSettings, LINE_ENDINGS } from "./terminal-settings";

export type ScheduleType = "interval" | "periodic" | "specific";
export type IntervalConfig = { hours: number; minutes: number; seconds: number };
export type PeriodicConfig = { days: number[]; time: string; utcOffsetMinutes: number };
export type SpecificConfig = { runAt: string };
export type ScheduleConfig = IntervalConfig | PeriodicConfig | SpecificConfig;

export const MAX_TASKS_PER_SERVER = 50;

let ensureTablePromise: Promise<void> | null = null;

// Creates the table on demand so no manual database push is needed.
export function ensureSchedulesTable(): Promise<void> {
  if (!ensureTablePromise) {
    ensureTablePromise = db
      .execute(sql`
        CREATE TABLE IF NOT EXISTS server_schedules (
          id serial PRIMARY KEY,
          server_id integer NOT NULL REFERENCES managed_servers(id) ON DELETE CASCADE,
          name text NOT NULL,
          task_type text NOT NULL,
          config text NOT NULL,
          command text NOT NULL,
          enabled boolean NOT NULL DEFAULT true,
          next_run_at timestamptz,
          last_run_at timestamptz,
          last_status text,
          run_count integer NOT NULL DEFAULT 0,
          created_at timestamptz NOT NULL DEFAULT now()
        )
      `)
      .then(() => undefined)
      .catch((error) => {
        ensureTablePromise = null;
        throw error;
      });
  }
  return ensureTablePromise;
}

/* ------------------------------ validation ------------------------------ */

export type ScheduleInput = {
  name: string;
  taskType: ScheduleType;
  config: ScheduleConfig;
  command: string;
};

function isInt(value: unknown, min: number, max: number): value is number {
  return typeof value === "number" && Number.isInteger(value) && value >= min && value <= max;
}

export function parseScheduleInput(
  body: unknown,
  now = new Date(),
): { ok: true; value: ScheduleInput } | { ok: false; error: string } {
  if (!body || typeof body !== "object") return { ok: false, error: "Invalid task." };
  const input = body as Record<string, unknown>;
  const name = typeof input.name === "string" ? input.name.trim() : "";
  if (!name || name.length > 60) return { ok: false, error: "Task name must be 1-60 characters." };
  const command = typeof input.command === "string" ? input.command.trim() : "";
  if (!command || command.length > 500 || /[\r\n]/.test(command)) {
    return { ok: false, error: "Add a one-line command to send (up to 500 characters)." };
  }
  const config = (input.config ?? {}) as Record<string, unknown>;

  if (input.taskType === "interval") {
    if (!isInt(config.hours, 0, 8760) || !isInt(config.minutes, 0, 59) || !isInt(config.seconds, 0, 59)) {
      return { ok: false, error: "Interval must be hours (0-8760), minutes (0-59) and seconds (0-59)." };
    }
    if (config.hours * 3600 + config.minutes * 60 + config.seconds < 1) {
      return { ok: false, error: "The interval must be at least 1 second." };
    }
    return { ok: true, value: { name, command, taskType: "interval", config: { hours: config.hours, minutes: config.minutes, seconds: config.seconds } } };
  }

  if (input.taskType === "periodic") {
    const days = Array.isArray(config.days) ? config.days : [];
    const uniqueDays = [...new Set(days)];
    if (!uniqueDays.length || !uniqueDays.every((day) => isInt(day, 0, 6))) {
      return { ok: false, error: "Choose at least one day of the week." };
    }
    if (typeof config.time !== "string" || !/^([01]\d|2[0-3]):([0-5]\d):([0-5]\d)$/.test(config.time)) {
      return { ok: false, error: "Time must look like 14:30:00." };
    }
    if (!isInt(config.utcOffsetMinutes, -840, 840)) return { ok: false, error: "Invalid time zone offset." };
    return { ok: true, value: { name, command, taskType: "periodic", config: { days: (uniqueDays as number[]).sort(), time: config.time, utcOffsetMinutes: config.utcOffsetMinutes } } };
  }

  if (input.taskType === "specific") {
    const runAt = typeof config.runAt === "string" ? new Date(config.runAt) : null;
    if (!runAt || Number.isNaN(runAt.getTime())) return { ok: false, error: "Choose a valid date and time." };
    if (runAt.getTime() <= now.getTime()) return { ok: false, error: "Choose a time in the future." };
    return { ok: true, value: { name, command, taskType: "specific", config: { runAt: runAt.toISOString() } } };
  }

  return { ok: false, error: "Unknown task type." };
}

/* ----------------------------- next run time ---------------------------- */

export function computeNextRun(type: ScheduleType, config: ScheduleConfig, from: Date): Date | null {
  if (type === "interval") {
    const c = config as IntervalConfig;
    return new Date(from.getTime() + (c.hours * 3600 + c.minutes * 60 + c.seconds) * 1000);
  }
  if (type === "periodic") {
    const c = config as PeriodicConfig;
    const offsetMs = c.utcOffsetMinutes * 60_000;
    const [h, m, s] = c.time.split(":").map(Number);
    const local = new Date(from.getTime() + offsetMs);
    for (let add = 0; add <= 7; add += 1) {
      const day = new Date(Date.UTC(local.getUTCFullYear(), local.getUTCMonth(), local.getUTCDate() + add, h, m, s));
      if (!c.days.includes(day.getUTCDay())) continue;
      const instant = new Date(day.getTime() - offsetMs);
      if (instant.getTime() > from.getTime()) return instant;
    }
    return null;
  }
  const c = config as SpecificConfig;
  const runAt = new Date(c.runAt);
  return runAt.getTime() > from.getTime() ? runAt : null;
}

export function parseStoredConfig(task: ServerSchedule): ScheduleConfig {
  try {
    return JSON.parse(task.config) as ScheduleConfig;
  } catch {
    return {} as ScheduleConfig;
  }
}

export function formatSchedule(task: ServerSchedule) {
  return {
    id: task.id,
    serverId: task.serverId,
    name: task.name,
    type: task.taskType as ScheduleType,
    config: parseStoredConfig(task),
    command: task.command,
    enabled: task.enabled,
    nextRunAt: task.nextRunAt ? task.nextRunAt.toISOString() : null,
    lastRunAt: task.lastRunAt ? task.lastRunAt.toISOString() : null,
    lastStatus: task.lastStatus,
    runCount: task.runCount,
    createdAt: task.createdAt.toISOString(),
  };
}

/* ------------------------------- execution ------------------------------ */

export async function executeScheduledCommand(task: ServerSchedule): Promise<string> {
  const [server] = await db.select({ id: serversTable.id }).from(serversTable).where(eq(serversTable.id, task.serverId)).limit(1);
  if (!server) return "Skipped: server not found";
  try {
    const settings = await getTerminalSettings(server.id);
    sendManagedProcessInput(server.id, task.command, {
      lineEnding: LINE_ENDINGS[settings.lineEnding],
      encoding: settings.inputEncoding,
    });
    return "Command sent";
  } catch (error) {
    return `Skipped: ${error instanceof Error ? error.message : "could not send the command"}`;
  }
}

let tickRunning = false;
let lastTickWarning = 0;

async function tick(): Promise<void> {
  if (tickRunning) return;
  tickRunning = true;
  try {
    const now = new Date();
    const due = await db
      .select()
      .from(serverSchedulesTable)
      .where(and(eq(serverSchedulesTable.enabled, true), isNotNull(serverSchedulesTable.nextRunAt), lte(serverSchedulesTable.nextRunAt, now)))
      .limit(50);
    for (const task of due) {
      const status = await executeScheduledCommand(task);
      const type = task.taskType as ScheduleType;
      const config = parseStoredConfig(task);
      let nextRunAt: Date | null = null;
      let enabled = true;
      if (type === "interval") {
        const step = (config as IntervalConfig);
        const ms = (step.hours * 3600 + step.minutes * 60 + step.seconds) * 1000;
        nextRunAt = new Date((task.nextRunAt ?? now).getTime() + ms);
        if (nextRunAt.getTime() <= now.getTime()) nextRunAt = new Date(now.getTime() + ms);
      } else if (type === "periodic") {
        nextRunAt = computeNextRun(type, config, now);
      } else {
        enabled = false;
      }
      await db
        .update(serverSchedulesTable)
        .set({ lastRunAt: now, lastStatus: status, runCount: sql`${serverSchedulesTable.runCount} + 1`, nextRunAt, enabled })
        .where(eq(serverSchedulesTable.id, task.id));
    }
  } catch (error) {
    if (Date.now() - lastTickWarning > 30_000) {
      lastTickWarning = Date.now();
      logger.warn({ err: error }, "Scheduler tick failed");
    }
  } finally {
    tickRunning = false;
  }
}

// After the API was offline: do not fire a burst of missed runs.
async function normalizeOverdueTasks(): Promise<void> {
  const now = new Date();
  const overdue = await db
    .select()
    .from(serverSchedulesTable)
    .where(and(eq(serverSchedulesTable.enabled, true), isNotNull(serverSchedulesTable.nextRunAt), lte(serverSchedulesTable.nextRunAt, new Date(now.getTime() - 5_000))));
  for (const task of overdue) {
    const type = task.taskType as ScheduleType;
    const config = parseStoredConfig(task);
    if (type === "specific") {
      if (now.getTime() - (task.nextRunAt?.getTime() ?? 0) > 60_000) {
        await db.update(serverSchedulesTable).set({ enabled: false, nextRunAt: null, lastStatus: "Missed (the panel was offline)" }).where(eq(serverSchedulesTable.id, task.id));
      }
    } else {
      await db.update(serverSchedulesTable).set({ nextRunAt: computeNextRun(type, config, now) }).where(eq(serverSchedulesTable.id, task.id));
    }
  }
}

export function startScheduler(): void {
  const boot = async () => {
    try {
      await ensureSchedulesTable();
      await normalizeOverdueTasks();
      setInterval(() => { void tick(); }, 1000);
      logger.info("Task scheduler started");
    } catch (error) {
      logger.warn({ err: error }, "Task scheduler could not start; retrying in 10 seconds");
      setTimeout(() => { void boot(); }, 10_000);
    }
  };
  void boot();
}
