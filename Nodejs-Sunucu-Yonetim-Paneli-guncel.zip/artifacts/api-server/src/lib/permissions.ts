// What a limited (non-admin) user can be allowed to do on the servers they can access.
export const PERMISSIONS = [
  "power",
  "kill",
  "console_view",
  "console_send",
  "files_view",
  "files_edit",
  "schedules",
  "startup",
  "settings",
  "scripts",
  "scripts_edit",
] as const;

export type Permission = (typeof PERMISSIONS)[number];

export type UserAccess = {
  permissions: Permission[];
  allServers: boolean;
  serverIds: number[];
};

// Scheduled tasks type commands into the terminal, so they need the right to send commands;
// sending commands needs seeing the terminal, and editing files needs seeing them.
export function normalizePermissions(input: unknown): Permission[] {
  const requested = new Set<string>(Array.isArray(input) ? input.filter((item): item is string => typeof item === "string") : []);
  if (requested.has("schedules")) requested.add("console_send");
  if (requested.has("scripts_edit")) requested.add("scripts");
  if (requested.has("console_send")) requested.add("console_view");
  if (requested.has("files_edit")) requested.add("files_view");
  return PERMISSIONS.filter((permission) => requested.has(permission));
}

// `scope` says where the server id of a request comes from, so that a user can only reach servers
// they were given: "path" = the first number in the URL, "body" = the serverId in the JSON body.
type Rule = { methods: string[] | "*"; pattern: RegExp; permission?: Permission; anyUser?: boolean; scope?: "path" | "body" };

// Every other path (dashboard, console page, activity, user management, creating or deleting
// servers ...) is administrator-only: limited users are denied by default.
const RULES: Rule[] = [
  { methods: ["GET"], pattern: /^\/auth\/(me|access)$/, anyUser: true },
  { methods: ["GET"], pattern: /^\/servers$/, anyUser: true },
  { methods: ["GET"], pattern: /^\/servers\/(\d+)$/, anyUser: true, scope: "path" },
  { methods: ["POST"], pattern: /^\/servers\/(\d+)\/(start|stop|restart)$/, permission: "power", scope: "path" },
  { methods: ["POST"], pattern: /^\/servers\/(\d+)\/kill$/, permission: "kill", scope: "path" },
  { methods: ["GET"], pattern: /^\/servers\/(\d+)\/logs$/, permission: "console_view", scope: "path" },
  { methods: ["DELETE"], pattern: /^\/servers\/(\d+)\/logs$/, permission: "console_send", scope: "path" },
  { methods: ["POST"], pattern: /^\/servers\/(\d+)\/console$/, permission: "console_send", scope: "path" },
  { methods: ["GET"], pattern: /^\/servers\/(\d+)\/files(\/content|\/download)?$/, permission: "files_view", scope: "path" },
  { methods: ["POST"], pattern: /^\/servers\/(\d+)\/files\/archive$/, permission: "files_view", scope: "path" },
  { methods: "*", pattern: /^\/servers\/(\d+)\/files(\/.*)?$/, permission: "files_edit", scope: "path" },
  { methods: ["GET"], pattern: /^\/servers\/(\d+)\/terminal-settings$/, permission: "console_view", scope: "path" },
  { methods: ["PUT"], pattern: /^\/servers\/(\d+)\/terminal-settings$/, permission: "settings", scope: "path" },
  { methods: "*", pattern: /^\/servers\/(\d+)\/schedules(\/.*)?$/, permission: "schedules", scope: "path" },
  // Scripts page: viewing and running (on the user's own servers), or managing the scripts themselves.
  { methods: ["GET"], pattern: /^\/scripts$/, permission: "scripts" },
  { methods: ["POST"], pattern: /^\/scripts$/, permission: "scripts_edit" },
  { methods: ["PUT", "DELETE"], pattern: /^\/scripts\/\d+$/, permission: "scripts_edit" },
  { methods: ["POST"], pattern: /^\/scripts\/\d+\/run$/, permission: "scripts", scope: "body" },
  { methods: ["GET"], pattern: /^\/script-runs\/[A-Za-z0-9-]+$/, permission: "scripts" },
  { methods: ["POST"], pattern: /^\/script-runs\/[A-Za-z0-9-]+\/cancel$/, permission: "scripts" },
];

export function canAccessServer(access: UserAccess, serverId: number): boolean {
  return access.allServers || access.serverIds.includes(serverId);
}

const STARTUP_KEYS = new Set(["autoStart", "autoStartDelaySeconds", "crashStart", "crashStartDelaySeconds"]);
const CONSOLE_KEYS = new Set(["logRefreshIntervalSeconds"]);
const PATCH_SERVER = /^\/servers\/(\d+)$/;

function has(access: UserAccess, permission: Permission): boolean {
  return access.permissions.includes(permission);
}

// Returns null when the request is allowed, otherwise the reason it is refused.
export function authorizeUserRequest(access: UserAccess, method: string, rawPath: string, body: unknown): string | null {
  const path = rawPath.length > 1 ? rawPath.replace(/\/+$/, "") : rawPath;
  const upper = method.toUpperCase();

  let serverId: number | null = null;
  let allowed = false;

  const patchMatch = upper === "PATCH" ? PATCH_SERVER.exec(path) : null;
  if (patchMatch) {
    serverId = Number(patchMatch[1]);
    const keys = body && typeof body === "object" ? Object.keys(body as Record<string, unknown>) : [];
    const needed = new Set<Permission>();
    for (const key of keys) {
      needed.add(STARTUP_KEYS.has(key) ? "startup" : CONSOLE_KEYS.has(key) ? "console_view" : "settings");
    }
    if (!needed.size) needed.add("settings");
    if ([...needed].every((permission) => has(access, permission))) allowed = true;
    else return "You do not have permission to change these settings.";
  } else {
    for (const rule of RULES) {
      if (rule.methods !== "*" && !rule.methods.includes(upper)) continue;
      const match = rule.pattern.exec(path);
      if (!match) continue;
      if (rule.scope === "path" && match[1] && /^\d+$/.test(match[1])) serverId = Number(match[1]);
      if (rule.scope === "body") {
        const fromBody = Number((body as { serverId?: unknown } | null)?.serverId);
        if (!Number.isInteger(fromBody) || fromBody < 1) return "Choose a server to run the script on.";
        serverId = fromBody;
      }
      if (rule.anyUser || (rule.permission && has(access, rule.permission))) allowed = true;
      else return "You do not have permission to do this.";
      break;
    }
  }

  if (!allowed) return "This area is only available to administrators.";
  if (serverId !== null && !canAccessServer(access, serverId)) {
    return "You do not have access to this server.";
  }
  return null;
}
