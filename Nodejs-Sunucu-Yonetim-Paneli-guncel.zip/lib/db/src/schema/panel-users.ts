import { boolean, integer, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";

// Limited accounts created by an administrator (the "New User" section in Settings).
export const panelUsersTable = pgTable("panel_users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  displayName: text("display_name").notNull(),
  passwordHash: text("password_hash").notNull(),
  passwordSalt: text("password_salt").notNull(),
  permissions: text("permissions").notNull().default("[]"),
  allServers: boolean("all_servers").notNull().default(false),
  serverIds: text("server_ids").notNull().default("[]"),
  disabled: boolean("disabled").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const userSessionsTable = pgTable("user_sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => panelUsersTable.id, { onDelete: "cascade" }),
  tokenHash: text("token_hash").notNull().unique(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type PanelUser = typeof panelUsersTable.$inferSelect;
