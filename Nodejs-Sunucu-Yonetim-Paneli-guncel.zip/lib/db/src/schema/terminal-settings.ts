import { boolean, integer, pgTable, text, timestamp } from "drizzle-orm/pg-core";
import { serversTable } from "./servers";

export const terminalSettingsTable = pgTable("server_terminal_settings", {
  serverId: integer("server_id")
    .primaryKey()
    .references(() => serversTable.id, { onDelete: "cascade" }),
  emulated: boolean("emulated").notNull().default(true),
  colors: boolean("colors").notNull().default(true),
  lineEnding: text("line_ending").notNull().default("lf"),
  stopCommand: text("stop_command").notNull().default("^C"),
  inputEncoding: text("input_encoding").notNull().default("utf8"),
  outputEncoding: text("output_encoding").notNull().default("utf-8"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export type TerminalSettingsRow = typeof terminalSettingsTable.$inferSelect;
