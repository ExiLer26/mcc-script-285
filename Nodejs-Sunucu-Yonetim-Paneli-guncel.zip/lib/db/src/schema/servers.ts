import { boolean, integer, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";

export const serversTable = pgTable("managed_servers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull().default(""),
  directory: text("directory").notNull(),
  command: text("command").notNull(),
  port: integer("port"),
  autoStart: boolean("auto_start").notNull().default(false),
  autoStartDelaySeconds: integer("auto_start_delay_seconds").notNull().default(5),
  crashStart: boolean("crash_start").notNull().default(false),
  crashStartDelaySeconds: integer("crash_start_delay_seconds").notNull().default(5),
  logRefreshIntervalSeconds: integer("log_refresh_interval_seconds").notNull().default(10),
  status: text("status").notNull().default("offline"),
  pid: integer("pid"),
  lastStartedAt: timestamp("last_started_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export type ManagedServer = typeof serversTable.$inferSelect;