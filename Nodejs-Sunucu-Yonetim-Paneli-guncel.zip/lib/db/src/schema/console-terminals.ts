import { integer, pgTable, timestamp } from "drizzle-orm/pg-core";
import { serversTable } from "./servers";

export const consoleTerminalsTable = pgTable("console_terminals", {
  serverId: integer("server_id")
    .primaryKey()
    .references(() => serversTable.id, { onDelete: "cascade" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
