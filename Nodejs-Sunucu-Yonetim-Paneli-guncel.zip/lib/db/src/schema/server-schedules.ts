import { boolean, integer, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";
import { serversTable } from "./servers";

export const serverSchedulesTable = pgTable("server_schedules", {
  id: serial("id").primaryKey(),
  serverId: integer("server_id")
    .notNull()
    .references(() => serversTable.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  taskType: text("task_type").notNull(),
  config: text("config").notNull(),
  command: text("command").notNull(),
  enabled: boolean("enabled").notNull().default(true),
  nextRunAt: timestamp("next_run_at", { withTimezone: true }),
  lastRunAt: timestamp("last_run_at", { withTimezone: true }),
  lastStatus: text("last_status"),
  runCount: integer("run_count").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type ServerSchedule = typeof serverSchedulesTable.$inferSelect;
