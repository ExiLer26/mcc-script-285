import { integer, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";

export const installScriptsTable = pgTable("install_scripts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull().default(""),
  variables: text("variables").notNull().default("[]"),
  steps: text("steps").notNull().default("[]"),
  runCount: integer("run_count").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export type InstallScript = typeof installScriptsTable.$inferSelect;
