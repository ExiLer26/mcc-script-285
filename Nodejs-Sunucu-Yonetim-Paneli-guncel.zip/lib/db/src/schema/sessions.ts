import { pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";
import { adminsTable } from "./admins";

export const sessionsTable = pgTable("sessions", {
  id: serial("id").primaryKey(),
  adminId: serial("admin_id").notNull().references(() => adminsTable.id, { onDelete: "cascade" }),
  tokenHash: text("token_hash").notNull().unique(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});